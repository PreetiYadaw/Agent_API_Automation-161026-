# QA Pariksha AI — full code (16 Oct 2026)

Document test case generation, API test case generation (two-section input), API
testing through the EIS encrypted gateway, the Desktop Agent, and the Two-section
Builder tool. `CHANGES.md` lists every change made during this work (Updates 1–7).

```
qa-pariksha/
├── backend/                      FastAPI (Python) — port 1000
│   ├── main.py                   entry point (Desktop Agent router registered)
│   ├── requirements.txt          sqlmodel pinned to 0.0.44 (see "SQLModel" below)
│   ├── .env.example              copy to .env and fill in
│   ├── files/                    put the EIS key files here (not included)
│   └── api/
│       ├── model.py
│       ├── config/               config, database, security, sso_security, storage
│       ├── endpoints/v1/
│       │   ├── generate_tests_api.py   document TCs, API TC generate / run / evaluate
│       │   ├── agent_api.py            Desktop Agent: prepare / decode EIS batches
│       │   ├── user_management_api.py, user_activity_api.py, upload_api.py, sso_auth_api.py
│       └── utils/
│           ├── two_section_utils.py    two-section input: checks, key paths, one change per case
│           ├── api_testcase_utils.py   API TC generation (AI writes invalid values), RRN, evaluation
│           ├── eis_request_tests.py    EIS request-level test cases (envelope + unexpected fields)
│           ├── eis_api_utils.py        EIS AES-GCM + RSA calls (prepare / decode / call)
│           └── executors.py, rag_utils.py, azure_utility.py, feature_file_utils.py, …
├── frontend/                     React + Vite + MUI — http://localhost:3000
│   └── src/App.tsx, main.tsx, components/   (AdminPanel.tsx NOT included — see below)
├── desktop-agent/                Electron app (runs EIS calls from the tester's PC)
├── tools/two_section_builder/    Streamlit: convert old input files / API docs → two-section JSON
├── samples/                      two-section input samples (flat EIS, EIS Channel, HEADERS/BODY)
└── CHANGES.md
```

## Add these yourself (not in the zip)

| File | Why |
|---|---|
| `frontend/src/components/AdminPanel.tsx` | Never shared with me. **Copy yours in** — the frontend won't build without it. |
| `backend/.env` | Secrets. Create it from `.env.example`. |
| `backend/files/private_key.cer`, `backend/files/ENC_EIS_UAT.cer` | EIS keys. |
| `backend/db/database.db` | Copy your existing database to keep users and activity. |
| `backend/rag_knowledge_base/` | Your ChromaDB folder, if you have ingested documents. |

## Setup (Windows)

```bat
:: Backend
cd backend
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
copy .env.example .env          &:: then edit .env
python main.py                  &:: → http://localhost:1000

:: Frontend (new terminal)
cd frontend
npm install
npm run dev                     &:: → http://localhost:3000

:: Desktop Agent (optional) — see desktop-agent\README.md
cd desktop-agent
npm install
npm run dev
```

## Things to know

- **Open the web app at `http://localhost:3000`**, not at the machine's IP. The login cookie belongs to the host in `API_BASE` (`http://localhost:1000/...`, top of `App.tsx`). Opening the page by IP gives "Could not validate credentials". For other machines or UAT, serve the frontend and backend under the same host name, over https.
- **SQLModel is pinned to 0.0.44.** SQLModel 0.0.45 and later reject timezone-less datetimes ("Datetime values must have timezone information") and break create-user, login attempts and activity logging. Install from `requirements.txt` exactly; afterwards run `pip freeze > requirements.lock.txt` to lock everything.
- **Desktop Agent hosts:** `EIS_ALLOWED_HOSTS` in `.env` lists the EIS hosts the server will sign for (UAT and pre-prod are pre-filled in `.env.example`). Restart the backend after changing it, then sign in to the agent again.
- **Input files:** API test generation needs the **two-section format** (`payload` + `validations`). Convert old files with `tools/two_section_builder` (Convert mode). Samples are in `samples/`.

## Where each part came from

- **Backend files and `main.py`:** your latest shared code. That's the combined code file, plus the individual files you uploaded for those not in it.
- **On top of that:** every change made since: two-section input, prompt (categories B–J, D/E), JSON-mode generation, run-time RRN handling, opening saved test cases, batch run/evaluate, and EIS request-level test cases.
- **Unchanged from your code:** login, SSO, users, RAG and document generation.
- **`main.py`:** two lines added to register the Desktop Agent router.
- **`backend/api/utils/executors.py`:** reconstructed earlier (never shared). Keep your own if you have it.
