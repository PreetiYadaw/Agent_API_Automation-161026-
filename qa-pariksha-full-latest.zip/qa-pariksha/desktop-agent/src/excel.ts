// src/excel.ts — same workbook format as the QA Pariksha web app, so an .xlsx
// edited in one can be re-uploaded in the other.
import * as XLSX from 'xlsx';
import type { GenerateResult, Testcase } from './agent.d';

// Set only on EIS request-level test cases: which part of the final EIS request is
// broken on purpose at run time (e.g. DIGI_SIGN_MISSING).
export const REQUEST_CHANGE_COLUMN = 'EIS_Request_Change';

export const API_TC_COLUMNS = [
  'Function Description', 'Test Case ID', 'Test Case Description',
  'Test Case Type', 'API_URL', 'API_METHOD', 'Test Data', REQUEST_CHANGE_COLUMN,
  'Encrypted_Payload', 'Encrypted_Response', 'Actual_Response',
  'Pass_Fail', 'Remarks',
];
export const EDITABLE_API_TC_COLUMNS = API_TC_COLUMNS.slice(0, 8);

const EXCEL_CELL_LIMIT = 32000; // Excel's hard limit is 32,767 characters per cell

export const asText = (v: any, pretty = true): string => {
  if (v === undefined || v === null) return '';
  if (typeof v === 'object') return JSON.stringify(v, null, pretty ? 2 : 0);
  return String(v);
};

const cell = (v: any, pretty = true) => {
  const s = asText(v, pretty);
  return s.length > EXCEL_CELL_LIMIT ? s.slice(0, EXCEL_CELL_LIMIT) + ' …[truncated: Excel cell limit]' : s;
};

const colWidths = (rows: Record<string, any>[], cols: string[]) =>
  cols.map(h => ({ wch: Math.min(Math.max(h.length, ...rows.map(r => String(r[h] ?? '').length)) + 2, 100) }));

const toBase64 = (wb: XLSX.WorkBook) => XLSX.write(wb, { type: 'base64', bookType: 'xlsx' }) as string;

// ── "Details" sheet — same as the web app, so a saved file re-opens with nothing to guess ──
export const DETAILS_SHEET = 'Details';
const NON_DATA_SHEETS = new Set(['Read Me First', DETAILS_SHEET]);
const RESULT_ONLY_COLUMNS = ['Encrypted_Payload', 'Encrypted_Response', 'Actual_Response', 'Pass_Fail', 'Remarks'];

export interface SavedFileMeta {
  api_name?: string; api_url?: string; method?: string; api_type?: string;
  generated_reference_number?: string | null; baseline_source_id?: string | null;
}
const DETAILS_FIELDS: [keyof SavedFileMeta, string][] = [
  ['api_name', 'API Name'], ['api_url', 'API URL'], ['method', 'Method'], ['api_type', 'API Type'],
  ['generated_reference_number', 'Generated Reference Number'], ['baseline_source_id', 'Baseline SOURCE_ID'],
];

function appendDetailsSheet(wb: XLSX.WorkBook, result?: GenerateResult | null) {
  if (!result) return;
  const rows = [
    ...DETAILS_FIELDS.map(([k, label]) => ({ Field: label, Value: (result as any)[k] ?? '' })),
    { Field: 'Saved On', Value: new Date().toISOString() },
    { Field: 'Note', Value: 'Read by "Open existing test cases" — leave this sheet unchanged.' },
  ];
  const ws = XLSX.utils.json_to_sheet(rows);
  ws['!cols'] = [{ wch: 28 }, { wch: 90 }];
  XLSX.utils.book_append_sheet(wb, ws, DETAILS_SHEET);
}

function readDetailsSheet(wb: XLSX.WorkBook): SavedFileMeta {
  const ws = wb.Sheets[DETAILS_SHEET];
  if (!ws) return {};
  const meta: SavedFileMeta = {};
  (XLSX.utils.sheet_to_json(ws, { defval: '' }) as any[]).forEach(r => {
    const f = DETAILS_FIELDS.find(([, label]) => label === String(r.Field ?? '').trim());
    const v = String(r.Value ?? '').trim();
    if (f && v) (meta as any)[f[0]] = v;
  });
  return meta;
}

export function buildEditableWorkbook(testcases: Testcase[], apiUrl: string, method: string, details?: GenerateResult | null): string {
  const rows = testcases.map(tc => {
    const row: Record<string, any> = {};
    EDITABLE_API_TC_COLUMNS.forEach(c => {
      if (c === 'Test Data') row[c] = cell(tc['Test Data']);
      else if (c === 'API_URL') row[c] = tc['API_URL'] || apiUrl || '';
      else if (c === 'API_METHOD') row[c] = tc['API_METHOD'] || method || '';
      else row[c] = tc[c] ?? '';
    });
    return row;
  });
  const ws = XLSX.utils.json_to_sheet(rows, { header: EDITABLE_API_TC_COLUMNS });
  ws['!cols'] = colWidths(rows, EDITABLE_API_TC_COLUMNS);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'API Test Cases');
  const readMe = [
    'One row per test case. Edit values below, save, then re-upload this file with "Upload edited" in the app.',
    "1. Don't rename, remove, or reorder columns — the app matches them by header name.",
    '2. "Test Data" must stay valid JSON after your edit (matching quotes/braces) — it is re-parsed on upload.',
    '3. If you change a value inside "Test Data" (the payload), also update "Test Case Description" for that row.',
    '4. Leave "Test Case ID" unchanged unless you mean to — it is used to match results back to each row.',
  ].map(t => ({ 'Read this before editing': t }));
  const wsInfo = XLSX.utils.json_to_sheet(readMe);
  wsInfo['!cols'] = [{ wch: 110 }];
  XLSX.utils.book_append_sheet(wb, wsInfo, 'Read Me First');
  appendDetailsSheet(wb, details);
  return toBase64(wb);
}

export function buildReportWorkbook(testcases: Testcase[], columns: string[], apiUrl: string, method: string, details?: GenerateResult | null): string {
  const rows = testcases.map(tc => {
    const row: Record<string, any> = {};
    columns.forEach(c => {
      if (c === 'API_URL') row[c] = tc['API_URL'] || apiUrl || '';
      else if (c === 'API_METHOD') row[c] = tc['API_METHOD'] || method || '';
      else row[c] = cell(tc[c], c !== 'Encrypted_Payload' && c !== 'Encrypted_Response');
    });
    return row;
  });
  const ws = XLSX.utils.json_to_sheet(rows, { header: columns });
  ws['!cols'] = colWidths(rows, columns);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'API Test Cases');
  appendDetailsSheet(wb, details);
  return toBase64(wb);
}

const isObj = (v: any): v is Record<string, any> => v !== null && typeof v === 'object' && !Array.isArray(v);

/** Unique IDs, Test Data parsed to an object, old run results removed. */
function normaliseSavedRows(rows: any[], label: (i: number) => string): Testcase[] {
  if (rows.length === 0) throw new Error('The file has no test case rows.');
  const missing = ['Test Case ID', 'Test Case Description', 'Test Case Type', 'Test Data'].filter(c => !(c in rows[0]));
  if (missing.length) throw new Error(`Missing column(s): ${missing.join(', ')}. Use a file downloaded from QA Pariksha.`);
  const seen = new Set<string>();
  return rows.map((r, idx) => {
    const id = String(r['Test Case ID'] ?? '').trim();
    if (!id) throw new Error(`${label(idx)}: "Test Case ID" is empty.`);
    if (seen.has(id)) throw new Error(`${label(idx)}: duplicate Test Case ID "${id}" — IDs must be unique (results are matched by ID).`);
    seen.add(id);
    let testData: any = r['Test Data'];
    if (typeof testData === 'string') {
      if (!testData.trim()) throw new Error(`${label(idx)} (Test Case ID: ${id}) — "Test Data" is empty.`);
      try { testData = JSON.parse(testData); }
      catch { throw new Error(`${label(idx)} (Test Case ID: ${id}) — "Test Data" is not valid JSON. Fix it and re-upload.`); }
    }
    if (!isObj(testData)) throw new Error(`${label(idx)} (Test Case ID: ${id}) — "Test Data" must be a JSON object.`);
    const clean: Testcase = { ...r, 'Test Case ID': id, 'Test Data': testData };
    RESULT_ONLY_COLUMNS.forEach(c => { delete clean[c]; });
    return clean;
  });
}

/** Reads a saved .xlsx / .xls / .json test-case file (web app or agent). Throws a readable Error. */
export function parseSavedFile(fileName: string, data: ArrayBuffer): { rows: Testcase[]; meta: SavedFileMeta } {
  const name = fileName.toLowerCase();
  if (name.endsWith('.json')) {
    let doc: any;
    try { doc = JSON.parse(new TextDecoder('utf-8').decode(data)); }
    catch (e: any) { throw new Error(`Not valid JSON — ${e.message}`); }
    if (Array.isArray(doc)) return { rows: normaliseSavedRows(doc, i => `Test case ${i + 1}`), meta: {} };
    if (!isObj(doc)) throw new Error('The JSON file must be a QA Pariksha test-case download.');
    if ('validations' in doc && 'payload' in doc && !('combined_testcases' in doc)) {
      throw new Error('This is an input spec (payload + validations). Choose "Generate from JSON spec" for it.');
    }
    let list: any = doc.combined_testcases;
    if (typeof list === 'string') { try { list = JSON.parse(list); } catch { list = null; } }
    if (!Array.isArray(list)) throw new Error('No "combined_testcases" list found — use the JSON downloaded from QA Pariksha.');
    return {
      rows: normaliseSavedRows(list, i => `Test case ${i + 1}`),
      meta: {
        api_name: doc.api_name || doc.document_name, api_url: doc.api_url, method: doc.method, api_type: doc.api_type,
        generated_reference_number: doc.generated_reference_number ?? null, baseline_source_id: doc.baseline_source_id ?? null,
      },
    };
  }
  if (name.endsWith('.xlsx') || name.endsWith('.xls')) {
    const wb = XLSX.read(data, { type: 'array' });
    const sheetName = wb.SheetNames.includes('API Test Cases')
      ? 'API Test Cases' : (wb.SheetNames.find(n => !NON_DATA_SHEETS.has(n)) || wb.SheetNames[0]);
    const rows: any[] = XLSX.utils.sheet_to_json(wb.Sheets[sheetName], { defval: '' });
    return { rows: normaliseSavedRows(rows, i => `Row ${i + 2}`), meta: readDetailsSheet(wb) };
  }
  throw new Error('Please choose an .xlsx, .xls or .json file.');
}

const twoChar = (v: any): string | null => {
  const s = String(v ?? '').trim().toUpperCase();
  return s.length === 2 ? s : null;
};

/** Baseline SOURCE_ID: Details/JSON → generated RRN → the "correct payload" row → most common. */
export function inferBaselineSourceId(rows: Testcase[], meta: SavedFileMeta): string | null {
  if (twoChar(meta.baseline_source_id)) return twoChar(meta.baseline_source_id);
  const g = String(meta.generated_reference_number || '').trim();
  if (/^SBI[A-Za-z0-9]{2}\d{20}$/.test(g)) return g.slice(3, 5).toUpperCase();
  const base = rows.find(r => r['Test Case Type'] === 'Positive' && /correct payload/i.test(String(r['Test Case Description'] || '')));
  if (base && twoChar(base['Test Data']?.SOURCE_ID)) return twoChar(base['Test Data'].SOURCE_ID);
  const counts = new Map<string, number>();
  rows.forEach(r => { const s = twoChar(r['Test Data']?.SOURCE_ID); if (s) counts.set(s, (counts.get(s) || 0) + 1); });
  let best: string | null = null, n = 0;
  counts.forEach((c, s) => { if (c > n) { best = s; n = c; } });
  return best;
}

const API_TYPE_VALUES = ['EIS', 'EIS_CHANNEL', 'EIS_MICROSERVICES'];

/** The result object the Results panel needs, built from a saved file. */
export function buildResultFromSavedFile(rows: Testcase[], meta: SavedFileMeta, fileName: string, apiTypeHint: string): GenerateResult {
  const apiUrl = String(meta.api_url || rows.find(r => r['API_URL'])?.['API_URL'] || '').trim();
  const noUrl = rows.filter(r => !String(r['API_URL'] || '').trim()).map(r => r['Test Case ID']);
  if (!apiUrl && noUrl.length) throw new Error(`"API_URL" is empty for ${noUrl.length} test case(s) (e.g. ${noUrl[0]}).`);
  const wrapped = rows.some(r => isObj(r['Test Data']) && 'EIS_PAYLOAD' in r['Test Data']);
  const apiType = (meta.api_type && API_TYPE_VALUES.includes(meta.api_type)) ? meta.api_type
    : wrapped ? (apiTypeHint !== 'EIS' ? apiTypeHint : 'EIS_CHANNEL') : 'EIS';
  const positive = rows.filter(r => r['Test Case Type'] === 'Positive').length;
  return {
    api_name: meta.api_name || String(rows.find(r => r['Function Description'])?.['Function Description'] || '') || fileName.replace(/\.[^.]+$/, ''),
    api_url: apiUrl,
    method: String(meta.method || rows.find(r => r['API_METHOD'])?.['API_METHOD'] || 'POST').toUpperCase(),
    api_type: apiType,
    generated_reference_number: meta.generated_reference_number || null,
    baseline_source_id: inferBaselineSourceId(rows, meta),
    loaded_from_file: fileName,
    combined_testcases: rows,
    summary: { total_testcase_count: rows.length, positive_count: positive, negative_count: rows.length - positive },
  };
}

/** Parses an edited workbook (kept for existing callers). Throws a readable Error on any problem. */
export function parseEditedWorkbook(data: ArrayBuffer): Testcase[] {
  return parseSavedFile('edited.xlsx', data).rows;
}
