import React, { useRef, useState } from 'react';
import {
  Alert, Box, Button, Checkbox, CircularProgress, Divider, FormControl, FormControlLabel, IconButton, InputLabel,
  MenuItem, Paper, Select, TextField, Tooltip, Typography,
} from '@mui/material';
import { Clear, CloudUploadOutlined, AutoAwesome, DataObject } from '@mui/icons-material';
import { PayloadTree, setIn } from './PayloadTree';
import { isPlainObject, findOldFormat, readValidations, type ValidationRule } from '../twoSection';

// Two-section input file: payload = the real request, validations = field key → rule.
export interface ApiSpec {
  api_name: string; api_url: string; method: string;
  payload: Record<string, any>;
  validations: Record<string, ValidationRule>;
}

export const API_TYPES = [
  { value: 'EIS', label: 'EIS' },
  { value: 'EIS_CHANNEL', label: 'EIS Channel' },
  { value: 'EIS_MICROSERVICES', label: 'EIS Microservices' },
];

export function parseSpec(text: string): ApiSpec {
  let raw: any;
  try { raw = JSON.parse(text); } catch (e: any) { throw new Error(`Not valid JSON — ${e.message}`); }
  if (!isPlainObject(raw)) throw new Error('The file must contain a JSON object.');
  if (!raw.api_url || typeof raw.api_url !== 'string') throw new Error('Missing "api_url".');
  if (!isPlainObject(raw.payload) || Object.keys(raw.payload).length === 0) throw new Error('"payload" must be a non-empty object.');
  const oldAt = findOldFormat(raw.payload);
  if (oldAt) throw new Error(`This file is in the old {value, required, validation} format (found at "${oldAt}"). Convert it with the Two-section Builder and choose the result.`);
  if (!isPlainObject(raw.validations) || Object.keys(raw.validations).length === 0) throw new Error('"validations" must be a non-empty object — one entry per field to test.');
  return {
    api_name: String(raw.api_name || 'Unnamed API'),
    api_url: raw.api_url.trim(),
    method: String(raw.method || 'POST').toUpperCase(),
    payload: raw.payload,
    validations: raw.validations,
  };
}

export const SpecPanel: React.FC<{
  spec: ApiSpec | null;
  fileName: string;
  onSpec: (s: ApiSpec | null, fileName: string) => void;
  apiType: string;
  onApiType: (t: string) => void;
  prompt: string;
  onPrompt: (p: string) => void;
  generating: boolean;
  onGenerate: () => void;
  locked: boolean;
  /** Opens saved test cases (.xlsx / .json); resolves to an error message, or null when loaded. */
  onOpenExisting: (f: File) => Promise<string | null>;
  includeRequestTests: boolean;
  onIncludeRequestTests: (v: boolean) => void;
}> = ({ spec, fileName, onSpec, apiType, onApiType, prompt, onPrompt, generating, onGenerate, locked, onOpenExisting,
        includeRequestTests, onIncludeRequestTests }) => {
  const [error, setError] = useState('');
  const [dragOver, setDragOver] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  // Where the test cases come from: a JSON spec (generate) or a saved file (run again).
  const [source, setSource] = useState<'spec' | 'existing'>('spec');
  const [existingError, setExistingError] = useState('');
  const [existingName, setExistingName] = useState('');
  const [opening, setOpening] = useState(false);
  const existingRef = useRef<HTMLInputElement>(null);

  const openExisting = async (f: File | undefined) => {
    if (!f) return;
    setExistingError(''); setExistingName(''); setOpening(true);
    const err = await onOpenExisting(f);
    setOpening(false);
    if (err) setExistingError(err); else setExistingName(f.name);
  };
  const rules = spec ? readValidations(spec.payload, spec.validations) : { byPath: {}, problems: [] as string[] };

  const readFile = (f: File | undefined) => {
    setError('');
    if (!f) return;
    if (!f.name.toLowerCase().endsWith('.json')) { setError('Please choose a .json file.'); return; }
    const reader = new FileReader();
    reader.onerror = () => setError('Could not read the file.');
    reader.onload = () => {
      try { onSpec(parseSpec(String(reader.result || '')), f.name); }
      catch (e: any) { setError(e.message); }
    };
    reader.readAsText(f);
  };

  const sourceChooser = (
    <Box sx={{ display: 'flex', gap: 1 }}>
      {([['spec', 'Generate from JSON spec'], ['existing', 'Open existing test cases']] as const).map(([value, label]) => (
        <Button key={value} fullWidth size="small" disabled={locked || generating}
                variant={source === value ? 'contained' : 'outlined'} onClick={() => setSource(value)}
                sx={{ textTransform: 'none', fontWeight: 600 }}>
          {label}
        </Button>
      ))}
    </Box>
  );

  if (source === 'existing') {
    return (
      <Paper elevation={0} sx={{ border: '1px solid #d6e8f0', p: 2, display: 'flex', flexDirection: 'column', gap: 1.5, height: '100%', overflow: 'hidden' }}>
        <Typography variant="subtitle2" sx={{ fontWeight: 700, color: 'secondary.main' }}>1 · TEST CASES</Typography>
        {sourceChooser}
        <input ref={existingRef} type="file" accept=".xlsx,.xls,.json" hidden
               onChange={e => { const f = e.target.files?.[0]; e.target.value = ''; openExisting(f); }} />
        <Box
          onClick={() => !locked && existingRef.current?.click()}
          onDragOver={e => { e.preventDefault(); setDragOver(true); }}
          onDragLeave={() => setDragOver(false)}
          onDrop={e => { e.preventDefault(); setDragOver(false); if (!locked) openExisting(e.dataTransfer.files?.[0]); }}
          sx={{
            border: '2px dashed', borderColor: dragOver ? 'primary.main' : '#b9dcea', borderRadius: 2,
            p: 3, textAlign: 'center', cursor: locked ? 'default' : 'pointer', bgcolor: dragOver ? '#e6f6fb' : '#fafdff',
          }}>
          {opening ? <CircularProgress size={32} /> : <CloudUploadOutlined sx={{ fontSize: 40, color: 'primary.main' }} />}
          <Typography variant="body2" sx={{ fontWeight: 600, mt: 1 }}>Choose or drop saved test cases</Typography>
          <Typography variant="caption" color="text.secondary">Editable Excel, results Excel or JSON — from this agent or the web app</Typography>
        </Box>
        {existingError && <Alert severity="error" onClose={() => setExistingError('')}>{existingError}</Alert>}
        {existingName && !existingError && <Alert severity="success">{existingName} loaded — use Run on the right.</Alert>}
        <Typography variant="caption" color="text.secondary">
          Old responses and verdicts in the file are ignored, and every run uses fresh REQUEST_REFERENCE_NUMBERs.
        </Typography>
      </Paper>
    );
  }

  return (
    <Paper elevation={0} sx={{ border: '1px solid #d6e8f0', p: 2, display: 'flex', flexDirection: 'column', gap: 1.5, height: '100%', overflow: 'hidden' }}>
      <Typography variant="subtitle2" sx={{ fontWeight: 700, color: 'secondary.main' }}>1 · INPUT JSON</Typography>
      {sourceChooser}

      <input ref={inputRef} type="file" accept=".json,application/json" hidden
             onChange={e => { const f = e.target.files?.[0]; e.target.value = ''; readFile(f); }} />

      {!spec ? (
        <Box
          onClick={() => inputRef.current?.click()}
          onDragOver={e => { e.preventDefault(); setDragOver(true); }}
          onDragLeave={() => setDragOver(false)}
          onDrop={e => { e.preventDefault(); setDragOver(false); readFile(e.dataTransfer.files?.[0]); }}
          sx={{
            border: '2px dashed', borderColor: dragOver ? 'primary.main' : '#b9dcea', borderRadius: 2,
            p: 3, textAlign: 'center', cursor: 'pointer', bgcolor: dragOver ? '#e6f6fb' : '#fafdff',
          }}>
          <CloudUploadOutlined sx={{ fontSize: 40, color: 'primary.main' }} />
          <Typography variant="body2" sx={{ fontWeight: 600, mt: 1 }}>Choose or drop the input JSON</Typography>
          <Typography variant="caption" color="text.secondary">{'{ api_name, api_url, method, payload, validations }'}</Typography>
        </Box>
      ) : (
        <Box sx={{ border: '1px solid #cdeefa', borderRadius: 2, p: 1.25, bgcolor: '#f7fcfe' }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            <DataObject color="primary" fontSize="small" />
            <Typography variant="body2" sx={{ fontWeight: 700, flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{spec.api_name}</Typography>
            <Tooltip title="Choose another file"><span><IconButton size="small" disabled={locked} onClick={() => inputRef.current?.click()}><CloudUploadOutlined fontSize="small" /></IconButton></span></Tooltip>
            <Tooltip title="Clear"><span><IconButton size="small" disabled={locked} onClick={() => { setError(''); onSpec(null, ''); }} sx={{ color: 'error.main' }}><Clear fontSize="small" /></IconButton></span></Tooltip>
          </Box>
          <Typography variant="caption" color="text.secondary" sx={{ display: 'block', wordBreak: 'break-all' }}>{spec.method} · {spec.api_url}</Typography>
          <Typography variant="caption" color="text.secondary">{fileName} · {Object.keys(spec.payload).length} top-level field(s) · {Object.keys(rules.byPath).length} to test</Typography>
        </Box>
      )}
      {error && <Alert severity="error" onClose={() => setError('')}>{error}</Alert>}
      {rules.problems.length > 0 && (
        <Alert severity="error">{rules.problems.map((p, i) => <div key={i}>• {p}</div>)}</Alert>
      )}

      {spec && (
        <Box sx={{ flex: 1, minHeight: 120, overflowY: 'auto', pr: 0.5 }}>
          <PayloadTree node={spec.payload} path={[]} depth={0} rules={rules.byPath}
                       onChange={(p, v) => onSpec({ ...spec, payload: setIn(spec.payload, p, v) }, fileName)} />
        </Box>
      )}

      <Divider />
      <FormControl size="small" fullWidth>
        <InputLabel>API type</InputLabel>
        <Select label="API type" value={apiType} onChange={e => onApiType(e.target.value)} disabled={locked}>
          {API_TYPES.map(t => <MenuItem key={t.value} value={t.value}>{t.label}</MenuItem>)}
        </Select>
      </FormControl>
      <TextField size="small" label="Additional instructions (optional)" multiline minRows={2} maxRows={4}
                 value={prompt} onChange={e => onPrompt(e.target.value)} disabled={locked} />
      <Tooltip placement="right" title={'Also tests the final encrypted request sent to EIS: DIGI_SIGN, REQUEST encryption, AccessToken, ' +
        'REQUEST_REFERENCE_NUMBER (missing, malformed, duplicate, not starting with SBI, channel not matching SOURCE_ID), ' +
        'Content-Type, HTTP method — plus an unexpected field QA_EXTRA_FIELD at every payload level, which must be rejected ' +
        'with "UNEXPECTED FIELD QA_EXTRA_FIELD". All negative.'}>
        <FormControlLabel disabled={locked} sx={{ ml: -0.5 }}
          control={<Checkbox size="small" checked={includeRequestTests} onChange={e => onIncludeRequestTests(e.target.checked)} />}
          label={<Typography variant="body2">Include EIS request-level test cases</Typography>} />
      </Tooltip>
      <Button variant="contained" size="large" startIcon={generating ? <CircularProgress size={18} sx={{ color: '#fff' }} /> : <AutoAwesome />}
              disabled={!spec || rules.problems.length > 0 || generating || locked} onClick={onGenerate}>
        {generating ? 'Generating test cases…' : 'Generate test cases'}
      </Button>
    </Paper>
  );
};
