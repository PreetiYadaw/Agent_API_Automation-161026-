import React from 'react';
import { Box, Chip, TextField, Typography } from '@mui/material';
import { isPlainObject, type FieldRule } from '../twoSection';

// Renders the two-section "payload" (the real request) with real values:
//   object                → section header, recurse (envelope, EIS_PAYLOAD, HEADERS / BODY …)
//   array of objects      → row count + first row, recurse (changes in test cases go to the first row)
//   primitive / other     → editable text field
// Fields that have a "validations" entry show their rule (mandatory/optional, valid values, rule text).
export { isPlainObject };

export const setIn = (obj: any, path: string[], value: any): any => {
  if (path.length === 0) return value;
  const [head, ...rest] = path;
  if (Array.isArray(obj)) {
    const arr = [...obj];
    arr[Number(head)] = setIn(arr[Number(head)], rest, value);
    return arr;
  }
  const base = isPlainObject(obj) ? obj : {};
  return { ...base, [head]: setIn(base[head], rest, value) };
};

// Keep the original JSON type when editing in a text box: 120 stays a number.
const coerceLikeOriginal = (original: any, input: string): any => {
  if (typeof original === 'number') {
    const n = Number(input);
    return input.trim() !== '' && Number.isFinite(n) ? n : input;
  }
  if (typeof original === 'boolean') {
    if (input.toLowerCase() === 'true') return true;
    if (input.toLowerCase() === 'false') return false;
  }
  return input;
};

const Primitive: React.FC<{ value: any; onChange: (v: any) => void }> = ({ value, onChange }) => (
  <TextField
    variant="standard" size="small" fullWidth
    value={value === null || value === undefined ? '' : String(value)}
    onChange={e => onChange(coerceLikeOriginal(value, e.target.value))}
    slotProps={{ htmlInput: { style: { fontSize: '0.8rem' } } }}
    sx={{ mt: 0.25 }}
  />
);

const show = (x: any) => (isPlainObject(x) || Array.isArray(x) ? JSON.stringify(x) : String(x));

const RuleInfo: React.FC<{ rule?: FieldRule }> = ({ rule }) => !rule ? null : (
  <>
    {rule.validValues.length > 0 && (
      <Typography variant="caption" color="text.secondary" sx={{ display: 'block', wordBreak: 'break-all' }}>
        Valid values: {rule.validValues.map(show).join(' | ')}
      </Typography>
    )}
    {rule.validation && (
      <Typography variant="caption" color="text.secondary" sx={{ display: 'block' }}>Rule: {rule.validation}</Typography>
    )}
  </>
);

const RuleChips: React.FC<{ rule?: FieldRule }> = ({ rule }) => !rule ? null : (
  <>
    {rule.required
      ? <Chip label="mandatory" size="small" sx={{ height: 16, fontSize: '0.6rem' }} />
      : <Chip label="optional" size="small" variant="outlined" sx={{ height: 16, fontSize: '0.6rem' }} />}
    {rule.validValues.length > 0 && <Chip label={`${rule.validValues.length} valid values`} size="small" color="info" sx={{ height: 16, fontSize: '0.6rem' }} />}
  </>
);

export const PayloadTree: React.FC<{
  node: Record<string, any>;
  path: string[];            // real path into the payload (array rows as "0")
  rulePath?: string[];       // the same path in validations form (array rows as "name[]")
  depth: number;
  rules: Record<string, FieldRule>;
  onChange: (path: string[], value: any) => void;
}> = ({ node, path, rulePath, depth, rules, onChange }) => (
  <Box sx={depth > 0 ? { pl: 1.25, ml: 0.5, mt: 0.75, borderLeft: '2px solid #cdeefa' } : undefined}>
    {Object.entries(node || {}).map(([key, entry]) => {
      const p = [...path, key];
      const rp = [...(rulePath || path), key];
      const rule = rules[rp.join('.')];
      const label = (
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.75, flexWrap: 'wrap' }}>
          <Typography variant="caption" sx={{ fontWeight: 700, color: isPlainObject(entry) || Array.isArray(entry) ? '#0b7fa3' : undefined }}>{key}</Typography>
          {isPlainObject(entry) && <Chip label={`${Object.keys(entry).length} item(s)`} size="small" variant="outlined" sx={{ height: 16, fontSize: '0.6rem' }} />}
          <RuleChips rule={rule} />
        </Box>
      );
      if (isPlainObject(entry)) {
        return (
          <Box key={key} sx={{ mb: 1.1 }}>
            {label}
            <RuleInfo rule={rule} />
            <PayloadTree node={entry} path={p} rulePath={rp} depth={depth + 1} rules={rules} onChange={onChange} />
          </Box>
        );
      }
      if (Array.isArray(entry) && entry.length > 0 && entry.every(isPlainObject)) {
        const rowRulePath = [...(rulePath || path), `${key}[]`];
        return (
          <Box key={key} sx={{ mb: 1.1 }}>
            {label}
            <Typography variant="caption" color="text.secondary" sx={{ display: 'block' }}>
              {entry.length} row(s) — row 1 shown; test-case changes are made in row 1
            </Typography>
            <RuleInfo rule={rule} />
            <PayloadTree node={entry[0]} path={[...p, '0']} rulePath={rowRulePath} depth={depth + 1} rules={rules} onChange={onChange} />
          </Box>
        );
      }
      return (
        <Box key={key} sx={{ mb: 1.1 }}>
          {label}
          {Array.isArray(entry)
            ? <Typography variant="caption" color="text.secondary" sx={{ display: 'block', wordBreak: 'break-all' }}>Value: {show(entry)}</Typography>
            : <Primitive value={entry} onChange={v => onChange(p, v)} />}
          <RuleInfo rule={rule} />
        </Box>
      );
    })}
  </Box>
);
