import React, { useMemo, useRef, useState } from 'react';
import {
  Alert, Box, Button, Checkbox, Chip, Dialog, DialogContent, DialogTitle, IconButton, LinearProgress,
  Paper, Step, StepLabel, Stepper, Table, TableBody, TableCell, TableContainer, TableHead,
  TablePagination, TableRow, Tooltip, Typography,
} from '@mui/material';
import { PlayArrow, Stop, FactCheck, Download, UploadFile, Close, EditNote, Undo } from '@mui/icons-material';
import type { GenerateResult, RunProgress, Testcase } from '../agent.d';
import { API_TC_COLUMNS, REQUEST_CHANGE_COLUMN, asText } from '../excel';

const WIDTH: Record<string, number> = {
  'Function Description': 150, 'Test Case ID': 105, 'Test Case Description': 260, 'Test Case Type': 95,
  'API_URL': 200, 'API_METHOD': 85, 'Test Data': 280, 'Encrypted_Payload': 220, 'Encrypted_Response': 220,
  'Actual_Response': 320, 'Pass_Fail': 85, 'Remarks': 240, [REQUEST_CHANGE_COLUMN]: 180,
};
const CODE_COLS = new Set(['Test Data', 'Encrypted_Payload', 'Encrypted_Response', 'Actual_Response']);
const SELECT_COL_WIDTH = 44;
const idOf = (tc: Testcase) => String(tc?.['Test Case ID'] ?? '');
const isErrorText = (v: any) => /^(ERROR|GATEWAY ERROR)/.test(String(v ?? ''));

// Quick-select helpers for picking the next batch (rows carry their merged results).
const QUICK_SELECT: { label: string; pick: (tc: Testcase) => boolean }[] = [
  { label: 'All', pick: () => true },
  { label: 'Not run yet', pick: tc => tc.Actual_Response === undefined },
  { label: 'Failed', pick: tc => tc.Pass_Fail === 'Fail' },
  { label: 'Errors', pick: tc => isErrorText(tc.Actual_Response) },
  { label: 'Positive', pick: tc => tc['Test Case Type'] === 'Positive' },
  { label: 'Negative', pick: tc => tc['Test Case Type'] === 'Negative' },
];

export const ResultsPanel: React.FC<{
  result: GenerateResult | null;
  rows: Testcase[];
  hasRun: boolean;
  hasEvaluated: boolean;
  usingUploaded: boolean;
  evalSummary: { pass_count: number; fail_count: number } | null;
  runCount: number;
  evalCount: number;
  selected: Set<string>;
  onSelectionChange: (s: Set<string>) => void;
  onRunSelected: () => void;
  onEvaluateSelected: () => void;
  running: boolean;
  evaluating: boolean;
  progress: RunProgress | null;
  error: string;
  onClearError: () => void;
  onRun: () => void;
  onCancel: () => void;
  onEvaluate: () => void;
  onDownloadEditable: () => void;
  onUploadEdited: (f: File) => void;
  onDiscardUpload: () => void;
  onDownloadReport: () => void;
}> = (p) => {
  const [page, setPage] = useState(0);
  const [perPage, setPerPage] = useState(25);
  const [detail, setDetail] = useState<Testcase | null>(null);
  const xlsxRef = useRef<HTMLInputElement>(null);

  const hasRequestChanges = p.rows.some(tc => String(tc[REQUEST_CHANGE_COLUMN] || '').trim());
  const columns = useMemo(() => API_TC_COLUMNS.filter(c => {
    if (c === REQUEST_CHANGE_COLUMN) return hasRequestChanges;
    if (c === 'Actual_Response' || c === 'Encrypted_Payload' || c === 'Encrypted_Response') return p.hasRun;
    if (c === 'Pass_Fail' || c === 'Remarks') return p.hasEvaluated;
    return true;
  }), [p.hasRun, p.hasEvaluated, hasRequestChanges]);

  if (!p.result) {
    return (
      <Paper elevation={0} sx={{ border: '1px solid #d6e8f0', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', p: 4 }}>
        <Box sx={{ textAlign: 'center', maxWidth: 460 }}>
          <Typography variant="h6" sx={{ fontWeight: 700, color: 'secondary.main' }}>Generate → Run → Evaluate</Typography>
          <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
            Upload the input JSON on the left, choose the API type and generate test cases.
            Runs go to the EIS gateway directly from this computer; keys stay on the QA Pariksha server.
          </Typography>
        </Box>
      </Paper>
    );
  }

  const busy = p.running || p.evaluating;
  const activeStep = p.hasEvaluated ? 3 : p.hasRun ? 2 : 1;
  const pos = p.rows.filter(r => r['Test Case Type'] === 'Positive').length;
  const pct = p.progress && p.progress.total ? Math.round((p.progress.done / p.progress.total) * 100) : 0;
  const selectedCount = p.rows.filter(tc => p.selected.has(idOf(tc))).length;
  const selectedRunCount = p.rows.filter(tc => p.selected.has(idOf(tc)) && tc.Actual_Response !== undefined).length;
  const pageRows = p.rows.slice(page * perPage, page * perPage + perPage);
  const pageIds = pageRows.map(idOf);
  const toggle = (id: string) => { const n = new Set(p.selected); if (n.has(id)) n.delete(id); else n.add(id); p.onSelectionChange(n); };

  return (
    <Paper elevation={0} sx={{ border: '1px solid #d6e8f0', height: '100%', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      <Box sx={{ p: 2, pb: 1 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, flexWrap: 'wrap' }}>
          <Box sx={{ flex: 1, minWidth: 260 }}>
            <Typography variant="subtitle1" sx={{ fontWeight: 700, lineHeight: 1.2 }}>{p.result.api_name}</Typography>
            <Typography variant="caption" color="text.secondary" sx={{ wordBreak: 'break-all' }}>{p.result.method} · {p.result.api_url} · {p.result.api_type}</Typography>
            {p.result.loaded_from_file && (
              <Typography variant="caption" color="text.secondary" sx={{ display: 'block' }}>Loaded from file: <strong>{p.result.loaded_from_file}</strong></Typography>
            )}
            {p.result.baseline_source_id ? (
              <Typography variant="caption" color="text.secondary" sx={{ display: 'block' }}>
                Baseline SOURCE_ID: <strong>{p.result.baseline_source_id}</strong> — every run gets fresh REQUEST_REFERENCE_NUMBERs built from it.
              </Typography>
            ) : p.result.loaded_from_file && (
              <Alert severity="warning" sx={{ mt: 1, py: 0 }}>
                <Typography variant="caption">The baseline SOURCE_ID could not be found in this file — each test case's own SOURCE_ID is used for its RRN, so cases with an invalid SOURCE_ID may not reach EIS.</Typography>
              </Alert>
            )}
            {Array.isArray(p.result.warnings) && p.result.warnings.length > 0 && (
              <Alert severity="warning" sx={{ mt: 1, py: 0 }}>
                <Typography variant="caption" sx={{ display: 'block', fontWeight: 600 }}>
                  {p.result.warnings.length} field(s) got no invalid-value test cases — everything else was generated:
                </Typography>
                {p.result.warnings.map((w, i) => <Typography key={i} variant="caption" sx={{ display: 'block' }}>• {w}</Typography>)}
              </Alert>
            )}
          </Box>
          <Stepper activeStep={activeStep} sx={{ minWidth: 340 }}>
            {['Generate', 'Run on EIS', 'Evaluate'].map(l => <Step key={l}><StepLabel>{l}</StepLabel></Step>)}
          </Stepper>
        </Box>

        <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap', mt: 1.5, alignItems: 'center' }}>
          <Chip size="small" label={`${p.rows.length} test cases`} />
          <Chip size="small" color="success" variant="outlined" label={`${pos} positive`} />
          <Chip size="small" color="warning" variant="outlined" label={`${p.rows.length - pos} negative`} />
          {p.usingUploaded && <Chip size="small" color="info" icon={<EditNote />} label="Using edited Excel"
                                    onDelete={busy ? undefined : p.onDiscardUpload} deleteIcon={<Tooltip title="Back to generated"><Undo /></Tooltip>} />}
          {p.hasRun && <Chip size="small" color="info" variant="outlined" label={`Run ${p.runCount}/${p.rows.length}`} />}
          {p.hasEvaluated && <Chip size="small" variant="outlined" label={`Evaluated ${p.evalCount}`} />}
          {p.evalSummary && <>
            <Chip size="small" color="success" label={`Pass ${p.evalSummary.pass_count}`} />
            <Chip size="small" color="error" label={`Fail ${p.evalSummary.fail_count}`} />
          </>}
          <Box sx={{ flex: 1 }} />
          {!p.hasRun && <>
            <Button size="small" variant="outlined" startIcon={<Download />} onClick={p.onDownloadEditable} disabled={busy}>Download for editing</Button>
            <input ref={xlsxRef} type="file" hidden accept=".xlsx,.xls,.json"
                   onChange={e => { const f = e.target.files?.[0]; e.target.value = ''; if (f) p.onUploadEdited(f); }} />
            <Button size="small" variant="outlined" startIcon={<UploadFile />} onClick={() => xlsxRef.current?.click()} disabled={busy}>Upload edited</Button>
          </>}
          {p.running
            ? <Button size="small" variant="contained" color="error" startIcon={<Stop />} onClick={p.onCancel}>Cancel run</Button>
            : <Button size="small" variant="contained" startIcon={<PlayArrow />} onClick={p.onRun} disabled={busy}>
                {p.hasRun ? 'Run all again' : 'Run all on EIS'}
              </Button>}
          {p.hasRun && <Button size="small" variant="contained" color="secondary" startIcon={<FactCheck />} onClick={p.onEvaluate} disabled={busy}>
            {p.evaluating ? 'Evaluating…' : p.hasEvaluated ? 'Evaluate all again' : 'Evaluate all (pass / fail)'}
          </Button>}
          {p.hasRun && <Button size="small" variant="outlined" startIcon={<Download />} onClick={p.onDownloadReport} disabled={busy}>Download report</Button>}
        </Box>

        {/* ── Batch selection: tick test cases, then run / evaluate just those ── */}
        <Box sx={{ display: 'flex', gap: 0.5, flexWrap: 'wrap', mt: 1.5, alignItems: 'center', p: 1, border: '1px solid #e3eef3', borderRadius: 1, bgcolor: '#f7fcfe' }}>
          <Typography variant="body2" sx={{ fontWeight: 600, mr: 1 }}>Selected: {selectedCount} of {p.rows.length}</Typography>
          <Typography variant="caption" color="text.secondary">Select:</Typography>
          {QUICK_SELECT.map(q => (
            <Button key={q.label} size="small" disabled={busy} sx={{ textTransform: 'none', minWidth: 0, px: 1 }}
                    onClick={() => p.onSelectionChange(new Set(p.rows.filter(q.pick).map(idOf)))}>{q.label}</Button>
          ))}
          <Button size="small" color="inherit" disabled={busy || p.selected.size === 0} sx={{ textTransform: 'none', minWidth: 0, px: 1 }}
                  onClick={() => p.onSelectionChange(new Set())}>None</Button>
          <Box sx={{ flex: 1 }} />
          <Button size="small" variant="contained" startIcon={<PlayArrow />} disabled={busy || selectedCount === 0}
                  onClick={p.onRunSelected} sx={{ textTransform: 'none' }}>Run selected ({selectedCount})</Button>
          <Button size="small" variant="outlined" color="secondary" startIcon={<FactCheck />} disabled={busy || selectedRunCount === 0}
                  onClick={p.onEvaluateSelected} sx={{ textTransform: 'none' }}>Evaluate selected ({selectedRunCount})</Button>
        </Box>

        {p.running && p.progress && (
          <Box sx={{ mt: 1.5 }}>
            <LinearProgress variant="determinate" value={pct} />
            <Typography variant="caption" color="text.secondary">{p.progress.phase} — {p.progress.done} / {p.progress.total}</Typography>
          </Box>
        )}
        {p.evaluating && <LinearProgress sx={{ mt: 1.5 }} />}
        {p.error && <Alert severity="error" sx={{ mt: 1.5 }} onClose={p.onClearError}>{p.error}</Alert>}
      </Box>

      <TableContainer sx={{ flex: 1, borderTop: '1px solid #e3eef3' }}>
        <Table stickyHeader size="small" sx={{ tableLayout: 'fixed', minWidth: SELECT_COL_WIDTH + columns.reduce((s, c) => s + (WIDTH[c] || 160), 0) }}>
          <TableHead>
            <TableRow>
              <TableCell padding="checkbox" sx={{ width: SELECT_COL_WIDTH, bgcolor: '#eef8fc' }}>
                <Tooltip title="Select / clear this page">
                  <Checkbox size="small" disabled={busy || pageIds.length === 0}
                    checked={pageIds.length > 0 && pageIds.every(id => p.selected.has(id))}
                    indeterminate={pageIds.some(id => p.selected.has(id)) && !pageIds.every(id => p.selected.has(id))}
                    onChange={e => {
                      const n = new Set(p.selected);
                      pageIds.forEach(id => { if (e.target.checked) n.add(id); else n.delete(id); });
                      p.onSelectionChange(n);
                    }} />
                </Tooltip>
              </TableCell>
              {columns.map(c => (
                <TableCell key={c} sx={{ width: WIDTH[c] || 160, fontWeight: 700, bgcolor: '#eef8fc', fontSize: '0.75rem' }}>{c.replace(/_/g, ' ')}</TableCell>
              ))}
            </TableRow>
          </TableHead>
          <TableBody>
            {pageRows.map((tc, i) => (
              <TableRow key={`${tc['Test Case ID']}-${i}`} hover selected={p.selected.has(idOf(tc))}
                        onClick={() => setDetail(tc)} sx={{ cursor: 'pointer', verticalAlign: 'top' }}>
                <TableCell padding="checkbox" onClick={e => e.stopPropagation()}>
                  <Checkbox size="small" disabled={busy} checked={p.selected.has(idOf(tc))} onChange={() => toggle(idOf(tc))} />
                </TableCell>
                {columns.map(c => {
                  const v = c === 'API_URL' ? (tc[c] || p.result!.api_url) : c === 'API_METHOD' ? (tc[c] || p.result!.method) : tc[c];
                  if (c === 'Pass_Fail' && v) return <TableCell key={c}><Chip size="small" label={v} color={v === 'Pass' ? 'success' : 'error'} /></TableCell>;
                  const text = asText(v, c !== 'Encrypted_Payload' && c !== 'Encrypted_Response');
                  return (
                    <TableCell key={c} sx={{ fontSize: '0.75rem' }}>
                      {CODE_COLS.has(c)
                        ? <Box component="pre" sx={{ m: 0, maxHeight: 110, overflow: 'hidden', whiteSpace: 'pre-wrap', wordBreak: 'break-all', fontFamily: 'Consolas, monospace', fontSize: '0.7rem', color: text.startsWith('ERROR') || text.startsWith('GATEWAY ERROR') ? 'error.main' : 'inherit' }}>
                            {text.length > 600 ? text.slice(0, 600) + ' …' : text || '—'}
                          </Box>
                        : <Box sx={{ display: '-webkit-box', WebkitLineClamp: 5, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>{text || '—'}</Box>}
                    </TableCell>
                  );
                })}
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
      <TablePagination component="div" count={p.rows.length} page={Math.min(page, Math.max(0, Math.ceil(p.rows.length / perPage) - 1))}
                       onPageChange={(_, n) => setPage(n)} rowsPerPage={perPage}
                       onRowsPerPageChange={e => { setPerPage(parseInt(e.target.value, 10)); setPage(0); }}
                       rowsPerPageOptions={[10, 25, 50, 100]} />

      <Dialog open={!!detail} onClose={() => setDetail(null)} maxWidth="md" fullWidth>
        {detail && <>
          <DialogTitle sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            <Box sx={{ flex: 1 }}>{detail['Test Case ID']} · {detail['Test Case Type']}</Box>
            {detail['Pass_Fail'] && <Chip label={detail['Pass_Fail']} color={detail['Pass_Fail'] === 'Pass' ? 'success' : 'error'} />}
            <IconButton onClick={() => setDetail(null)}><Close /></IconButton>
          </DialogTitle>
          <DialogContent dividers>
            <Typography variant="body2" sx={{ mb: 1.5 }}>{detail['Test Case Description']}</Typography>
            {detail['Remarks'] && <Alert severity={detail['Pass_Fail'] === 'Pass' ? 'success' : 'warning'} sx={{ mb: 1.5 }}>{detail['Remarks']}</Alert>}
            {['Test Data', 'Actual_Response', 'Encrypted_Payload', 'Encrypted_Response'].filter(k => detail[k] !== undefined).map(k => (
              <Box key={k} sx={{ mb: 1.5 }}>
                <Typography variant="caption" sx={{ fontWeight: 700 }}>{k.replace(/_/g, ' ')}</Typography>
                <Box component="pre" sx={{ m: 0, mt: 0.5, p: 1.25, bgcolor: '#f6f8fa', border: '1px solid #e3e8ee', borderRadius: 1, maxHeight: 260, overflow: 'auto', whiteSpace: 'pre-wrap', wordBreak: 'break-all', fontFamily: 'Consolas, monospace', fontSize: '0.75rem' }}>
                  {asText(detail[k]) || '—'}
                </Box>
              </Box>
            ))}
          </DialogContent>
        </>}
      </Dialog>
    </Paper>
  );
};
