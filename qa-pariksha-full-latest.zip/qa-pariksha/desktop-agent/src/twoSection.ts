// src/twoSection.ts — two-section input file helpers for the Desktop Agent.
// Same path rules as the backend (api/utils/two_section_utils.py), the web app and
// the Two-section Builder: a validations key is a field name, or the shortest unique
// path; "name[]" = inside the rows of an array of objects; an exact full path wins.
export const isPlainObject = (v: any): v is Record<string, any> =>
  v !== null && typeof v === 'object' && !Array.isArray(v);

export type ValidationRule = string | { required?: boolean; validation?: string; valid_values?: any[] };

export interface FieldRule { key: string; path: string; required: boolean; validation: string; validValues: any[] }

export const payloadPaths = (node: any, segs: string[] = []): string[][] => {
  const out: string[][] = [];
  if (!isPlainObject(node)) return out;
  Object.entries(node).forEach(([k, v]) => {
    const p = [...segs, k];
    out.push(p);
    if (isPlainObject(v)) out.push(...payloadPaths(v, p));
    else if (Array.isArray(v) && v.length > 0 && v.every(isPlainObject)) {
      const row = [...segs, `${k}[]`];
      const seen = new Set<string>();
      v.forEach(item => payloadPaths(item, row).forEach(sp => {
        const t = sp.join('.');
        if (!seen.has(t)) { seen.add(t); out.push(sp); }
      }));
    }
  });
  return out;
};

export const resolveKey = (key: string, all: string[][]): string[][] => {
  const ks = key.trim().split('.').filter(Boolean);
  if (!ks.length) return [];
  const exact = all.filter(p => p.length === ks.length && p.every((s, i) => s === ks[i]));
  if (exact.length) return exact;
  return all.filter(p => p.length >= ks.length && ks.every((s, i) => p[p.length - ks.length + i] === s));
};

const RULE_RE = /^\s*(mandatory|optional)\b[\s.:,;\-–]*([\s\S]*)$/i;

/** Rules keyed by resolved path text, plus every problem found in "validations". */
export const readValidations = (payload: Record<string, any>, validations: Record<string, ValidationRule>):
  { byPath: Record<string, FieldRule>; problems: string[] } => {
  const all = payloadPaths(payload);
  const byPath: Record<string, FieldRule> = {};
  const problems: string[] = [];
  Object.entries(validations || {}).forEach(([key, raw]) => {
    const hits = resolveKey(key, all);
    if (!hits.length) { problems.push(`validations key "${key}" does not match any field in "payload".`); return; }
    if (hits.length > 1) { problems.push(`validations key "${key}" matches ${hits.length} fields — use a longer path.`); return; }
    let required = true, validation = '', validValues: any[] = [];
    if (typeof raw === 'string') {
      const m = raw.match(RULE_RE);
      if (!m) { problems.push(`validations["${key}"]: the rule must start with "Mandatory." or "Optional.".`); return; }
      required = m[1].toLowerCase() === 'mandatory'; validation = m[2].trim();
    } else if (isPlainObject(raw)) {
      required = raw.required !== false; validation = String(raw.validation || '').trim();
      validValues = Array.isArray(raw.valid_values) ? raw.valid_values : [];
    } else { problems.push(`validations["${key}"] must be a text rule or an object.`); return; }
    const path = hits[0].join('.');
    byPath[path] = { key, path, required, validation, validValues };
  });
  return { byPath, problems };
};

/** Path of the first {value, required/validation} object left in the payload (old format). */
export const findOldFormat = (node: any, segs: string[] = []): string | null => {
  if (isPlainObject(node)) {
    const keys = Object.keys(node);
    if ('value' in node && ('required' in node || 'validation' in node)
        && keys.every(k => ['value', 'required', 'validation', 'valid_values'].includes(k))) return segs.join('.') || 'payload';
    for (const [k, v] of Object.entries(node)) { const hit = findOldFormat(v, [...segs, k]); if (hit) return hit; }
  } else if (Array.isArray(node)) {
    for (let i = 0; i < node.length; i++) { const hit = findOldFormat(node[i], [...segs, `[${i}]`]); if (hit) return hit; }
  }
  return null;
};
