"""
streamlit_two_section.py — QA Pariksha · Two-section Input JSON Builder (POC)
============================================================================

Builds the NEW two-section input file for QA Pariksha API automation:

    {
      "api_name": "...", "api_url": "...", "method": "POST",
      "payload":     { ...the real, valid request — exact nesting, arrays and types... },
      "validations": { "<key or path>": "<rule>", ... }
    }

Section 1 — "payload"     : the baseline request exactly as the API receives it.
                            Arrays are real arrays; nested objects are real objects.
Section 2 — "validations" : one entry per field to test.
    key   : the field name when it is unique in the payload, otherwise the shortest
            path that makes it unique, e.g. "rpNexesusReq.pan" / "associateCompDTOs.pan".
            Inside arrays "[]" means "in every row", e.g. "related_party_summary[].pan".
            A key always resolves to EXACTLY ONE field of the payload.
    value : a text rule starting with "Mandatory." or "Optional.", e.g.
                "Mandatory. String, exactly 10 characters, PAN format AAAAA9999A"
            or an object when extra valid values must be listed:
                {"required": true, "validation": "Allowed values Y or N",
                 "valid_values": ["Y", "N"]}
            "valid_values" lists EVERY value that is valid for a positive test case
            (the payload's value first). Fields with no entry are sent unchanged and
            never tested (e.g. static headers).

Two ways in
-----------
  A. Convert an existing QA Pariksha input JSON (old {value, required, validation}
     format)  → deterministic conversion in code, no AI call. Handles nested objects,
     arrays of objects and the HEADERS/BODY shape.
  B. Read API documents (PDF / TXT / JSON, 1-3 files) → text + tables extracted,
     Azure OpenAI analyses the API, the two sections are then built IN CODE from
     that analysis (the AI never free-writes the final file).

Every result is checked: every validations key must resolve to exactly one payload
field, envelope fields must exist for EIS Channel / Microservices, SOURCE_ID must be
2 characters, no {value, required, validation} objects may remain in the payload.

Run
---
  pip install streamlit openai python-dotenv pdfplumber pandas httpx
  streamlit run streamlit_two_section.py

.env (same folder) — only needed for way B
------------------------------------------
  AZURE_OPENAI_API_KEY=...
  AZURE_OPENAI_ENDPOINT=https://<resource>.openai.azure.com/
  AZURE_OPENAI_API_VERSION=2024-12-01-preview
  AZURE_OPENAI_DEPLOYMENT=gpt-4.1-mini
  # optional — only for corporate proxies with SSL inspection:
  AZURE_OPENAI_VERIFY_SSL=true
"""
from __future__ import annotations

import copy
import io
import json
import os
import re
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

import httpx
import pandas as pd
import pdfplumber
import streamlit as st
from dotenv import load_dotenv
from openai import AzureOpenAI

load_dotenv()

# ════════════════════════════════════════════════════════════════════════════
# CONFIG
# ════════════════════════════════════════════════════════════════════════════
AZURE_API_KEY     = os.getenv("AZURE_OPENAI_API_KEY", "")
AZURE_ENDPOINT    = os.getenv("AZURE_OPENAI_ENDPOINT", "")
AZURE_API_VERSION = os.getenv("AZURE_OPENAI_API_VERSION", "2024-12-01-preview")
AZURE_DEPLOYMENT  = os.getenv("AZURE_OPENAI_DEPLOYMENT", "gpt-4.1-mini")
AZURE_VERIFY_SSL  = os.getenv("AZURE_OPENAI_VERIFY_SSL", "true").strip().lower() not in ("false", "0", "no")

MAX_FILES           = 3
MAX_FILE_MB         = 25
MAX_CONTEXT_CHARS   = 600_000   # guard: gpt-4.1-mini has a very large context, but keep cost sane
LLM_MAX_OUT_TOKENS  = 32_000
LLM_RETRIES         = 2

API_TYPES = {
    "EIS": "EIS (flat payload)",
    "EIS_CHANNEL": "EIS Channel (SOURCE_ID / DESTINATION / TXN_TYPE / TXN_SUB_TYPE + EIS_PAYLOAD)",
    "EIS_MICROSERVICES": "EIS Microservices (same envelope as EIS Channel)",
}
WRAPPED_TYPES   = {"EIS_CHANNEL", "EIS_MICROSERVICES"}
PARENT_FIELDS   = ["SOURCE_ID", "DESTINATION", "TXN_TYPE", "TXN_SUB_TYPE"]
EIS_PAYLOAD_KEY = "EIS_PAYLOAD"
RRN_KEY         = "REQUEST_REFERENCE_NUMBER"

# Extension → (browser-reported MIME types we accept). application/octet-stream is
# what some browsers/OSes report for unknown types, so it's allowed but the real
# content check below is what actually decides.
ALLOWED_MIME = {
    "pdf":  {"application/pdf", "application/x-pdf", "application/octet-stream"},
    "json": {"application/json", "text/json", "text/plain", "application/octet-stream"},
    "txt":  {"text/plain", "application/octet-stream"},
}


# ════════════════════════════════════════════════════════════════════════════
# DATA CLASSES
# ════════════════════════════════════════════════════════════════════════════
@dataclass
class ExtractedTable:
    page: int                  # 1-based page where the table starts
    pages: List[int]           # all pages the table spans (continuations merged)
    header: List[str]
    rows: List[List[str]]

    def to_markdown(self) -> str:
        cols = self.header or [f"col_{i + 1}" for i in range(len(self.rows[0]) if self.rows else 0)]
        esc = lambda s: str(s).replace("|", "\\|")
        lines = ["| " + " | ".join(esc(c) for c in cols) + " |",
                 "| " + " | ".join("---" for _ in cols) + " |"]
        for r in self.rows:
            r = list(r) + [""] * (len(cols) - len(r))
            lines.append("| " + " | ".join(esc(c) for c in r[:len(cols)]) + " |")
        return "\n".join(lines)

    def to_dataframe(self) -> pd.DataFrame:
        cols, seen = [], {}
        for i, c in enumerate(self.header or [f"col_{i + 1}" for i in range(len(self.rows[0]) if self.rows else 0)]):
            name = c or f"col_{i + 1}"
            seen[name] = seen.get(name, 0) + 1
            cols.append(name if seen[name] == 1 else f"{name}_{seen[name]}")
        rows = [list(r) + [""] * (len(cols) - len(r)) for r in self.rows]
        return pd.DataFrame([r[:len(cols)] for r in rows], columns=cols)


@dataclass
class ExtractedDoc:
    filename: str
    kind: str                                   # pdf | txt | json
    text: str = ""                              # full text in reading order (tables inlined as markdown)
    tables: List[ExtractedTable] = field(default_factory=list)
    json_blocks: List[Any] = field(default_factory=list)   # sample requests / JSON found
    page_count: int = 0
    warnings: List[str] = field(default_factory=list)


# ════════════════════════════════════════════════════════════════════════════
# 1. UPLOAD VALIDATION
# ════════════════════════════════════════════════════════════════════════════
def validate_upload(name: str, reported_mime: str, data: bytes) -> Tuple[bool, str, Optional[str]]:
    """Returns (ok, message, kind). Never trusts the extension alone."""
    ext = name.rsplit(".", 1)[-1].lower() if "." in name else ""
    if ext not in ALLOWED_MIME:
        return False, f"Extension '.{ext}' is not allowed (only .pdf, .json, .txt).", None
    if not data:
        return False, "File is empty.", None
    if len(data) > MAX_FILE_MB * 1024 * 1024:
        return False, f"File is larger than {MAX_FILE_MB} MB.", None

    mime = (reported_mime or "").split(";")[0].strip().lower()
    if mime and mime not in ALLOWED_MIME[ext]:
        return False, f"MIME type '{mime}' does not match a .{ext} file.", None

    # ── content sniffing ────────────────────────────────────────────────────
    if ext == "pdf":
        if not data[:1024].lstrip().startswith(b"%PDF-"):
            return False, "Not a real PDF (missing %PDF- signature).", None
        return True, f"Valid PDF ({mime or 'no MIME reported'})", "pdf"

    if b"\x00" in data[:8192]:
        return False, "Binary content detected — not a text/JSON file.", None
    text = _decode_text(data)
    if text is None:
        return False, "Could not decode as UTF-8 / Windows-1252 text.", None

    if ext == "json":
        try:
            json.loads(text)
            return True, f"Valid JSON ({mime or 'no MIME reported'})", "json"
        except json.JSONDecodeError:
            if _lenient_json(text) is not None:
                return True, "JSON has minor syntax issues (auto-repaired for analysis).", "json"
            return True, "JSON could not be parsed — it will be analysed as plain text.", "json"

    return True, f"Valid text ({mime or 'no MIME reported'})", "txt"


def _decode_text(data: bytes) -> Optional[str]:
    for enc in ("utf-8-sig", "cp1252"):
        try:
            return data.decode(enc)
        except UnicodeDecodeError:
            continue
    return None


# ════════════════════════════════════════════════════════════════════════════
# 2. EXTRACTION
# ════════════════════════════════════════════════════════════════════════════
def _clean_cell(c: Any) -> str:
    return re.sub(r"\s+", " ", str(c)).strip() if c is not None else ""


def _looks_like_header(row: List[str]) -> bool:
    """Header rows are mostly non-empty, short, and non-numeric."""
    cells = [c for c in row if c]
    if len(cells) < max(1, len(row) // 2):
        return False
    return sum(1 for c in cells if not re.fullmatch(r"[\d.,/:\- ]+", c) and len(c) <= 60) >= len(cells) * 0.7


def extract_pdf(data: bytes, filename: str, borderless: bool) -> ExtractedDoc:
    doc = ExtractedDoc(filename=filename, kind="pdf")
    settings = ({"vertical_strategy": "text", "horizontal_strategy": "text"} if borderless
                else {"vertical_strategy": "lines", "horizontal_strategy": "lines"})
    page_lines: List[Tuple[int, List[str]]] = []    # (page_no, lines) — joined after boilerplate removal
    last_table: Optional[ExtractedTable] = None      # candidate for cross-page continuation
    empty_pages = 0

    with pdfplumber.open(io.BytesIO(data)) as pdf:
        doc.page_count = len(pdf.pages)
        for pno, page in enumerate(pdf.pages, start=1):
            try:
                found = page.find_tables(table_settings=settings)
            except Exception as e:                   # malformed page — keep going with text only
                doc.warnings.append(f"Page {pno}: table detection failed ({e}).")
                found = []
            bboxes = [t.bbox for t in found]

            items: List[Tuple[float, str, Any]] = []   # (top, kind, payload) for reading order
            # Text lines that are NOT inside a table (tables are emitted separately)
            try:
                lines = page.extract_text_lines(layout=False, strip=True)
            except Exception:
                lines = []
            for ln in lines:
                cx, cy = (ln["x0"] + ln["x1"]) / 2, (ln["top"] + ln["bottom"]) / 2
                if any(b[0] <= cx <= b[2] and b[1] <= cy <= b[3] for b in bboxes):
                    continue
                items.append((ln["top"], "text", ln["text"]))
            for t in found:
                raw = [[_clean_cell(c) for c in r] for r in (t.extract() or [])]
                raw = [r for r in raw if any(r)]
                if raw:
                    items.append((t.bbox[1], "table", raw))
            items.sort(key=lambda x: x[0])

            if not items:
                empty_pages += 1
                continue

            # A table can continue from the previous page only if it's the first table
            # here and at most a few short lines (running page header) precede it.
            lines_before_first_table = 0
            seen_table_on_page = False
            page_text: List[str] = []
            for _, kind, payload in items:
                if kind == "text":
                    page_text.append(payload)
                    if not seen_table_on_page:
                        lines_before_first_table += 1
                    continue
                rows = payload
                ncols = max(len(r) for r in rows)
                # ── Continuation of a table from the previous page? ─────────
                can_continue = not seen_table_on_page and lines_before_first_table <= 3
                if (can_continue and last_table is not None
                        and last_table.pages[-1] == pno - 1 and ncols == len(last_table.header)):
                    body = rows[1:] if rows[0] == last_table.header else rows   # drop repeated header
                    last_table.rows.extend(body)
                    last_table.pages.append(pno)
                    page_text.append(f"[Table {len(doc.tables)} continues on page {pno} — merged]")
                else:
                    header, body = (rows[0], rows[1:]) if _looks_like_header(rows[0]) else ([], rows)
                    if not header:
                        header = [f"col_{i + 1}" for i in range(ncols)]
                    tbl = ExtractedTable(page=pno, pages=[pno], header=header, rows=body)
                    doc.tables.append(tbl)
                    last_table = tbl
                    page_text.append(f"{{{{TABLE_{len(doc.tables)}}}}}")   # placeholder, filled below
                seen_table_on_page = True
            # Only a table that ENDS a page (ignoring a short running footer) may continue on the next one.
            trailing_text = 0
            for _, kind, _p in reversed(items):
                if kind == "table":
                    break
                trailing_text += 1
            if trailing_text > 3 or not seen_table_on_page:
                last_table = None
            page_lines.append((pno, page_text))

    # ── Remove running headers/footers (e.g. "SBI Confidential…", "Page 3") ────
    # They repeat at the top/bottom of most pages and would otherwise land in the
    # middle of a sample JSON that crosses a page break.
    boiler = _find_boilerplate(page_lines)
    if boiler:
        doc.warnings.append(f"Removed {len(boiler)} repeating header/footer line pattern(s): "
                            + "; ".join(sorted(boiler))[:200])
    parts = []
    for pno, lines in page_lines:
        kept = [ln for ln in lines if _norm_line(ln) not in boiler]
        parts.append(f"\n===== Page {pno} =====\n" + "\n".join(kept))
    text = "\n".join(parts)
    for i, t in enumerate(doc.tables, start=1):   # inline the (merged) tables as markdown
        span = f"pages {t.pages[0]}-{t.pages[-1]}" if len(t.pages) > 1 else f"page {t.page}"
        text = text.replace(f"{{{{TABLE_{i}}}}}", f"\n[TABLE {i} — {span}]\n{t.to_markdown()}\n")
    doc.text = text.strip()

    if empty_pages == doc.page_count:
        doc.warnings.append("No text found — this looks like a scanned PDF. OCR is not part of this POC.")
    elif empty_pages:
        doc.warnings.append(f"{empty_pages} page(s) had no extractable text (images/scans?).")
    doc.json_blocks = find_json_blocks(_join_for_json_scan(doc.text))
    return doc


def _norm_line(line: str) -> str:
    return re.sub(r"\d+", "#", line.strip().lower())


def _find_boilerplate(page_lines: List[Tuple[int, List[str]]]) -> set:
    """Lines that appear in the first/last 2 lines of at least half the pages
    (digits normalised, so 'Page 2' / 'Page 3' match)."""
    if len(page_lines) < 2:
        return set()
    counts: Dict[str, int] = {}
    for _, lines in page_lines:
        edge = {_norm_line(l) for l in (lines[:2] + lines[-2:]) if l and not l.startswith("{{TABLE_")}
        for e in edge:
            counts[e] = counts.get(e, 0) + 1
    need = max(2, (len(page_lines) + 1) // 2)
    return {k for k, c in counts.items() if c >= need and 0 < len(k) <= 120 and not k.startswith(("{", "}", '"'))}


def _join_for_json_scan(text: str) -> str:
    """Page separators can split a sample JSON that spans two pages — remove them."""
    return re.sub(r"\n===== Page \d+ =====\n", "\n", text)


def extract_text_file(data: bytes, filename: str) -> ExtractedDoc:
    text = _decode_text(data) or ""
    return ExtractedDoc(filename=filename, kind="txt", text=text, json_blocks=find_json_blocks(text))


def extract_json_file(data: bytes, filename: str) -> ExtractedDoc:
    text = _decode_text(data) or ""
    doc = ExtractedDoc(filename=filename, kind="json", text=text)
    try:
        doc.json_blocks = [json.loads(text)]
    except json.JSONDecodeError:
        fixed = _lenient_json(text)
        if fixed is not None:
            doc.json_blocks = [fixed]
            doc.warnings.append("JSON had syntax issues (smart quotes / trailing commas) — auto-repaired.")
        else:
            doc.warnings.append("JSON could not be parsed — analysed as plain text.")
            doc.json_blocks = find_json_blocks(text)
    return doc


def _lenient_json(s: str) -> Optional[Any]:
    """Repairs the usual copy-paste damage: smart quotes, trailing commas, comments."""
    t = (s.replace("\u201c", '"').replace("\u201d", '"').replace("\u2018", "'").replace("\u2019", "'")
          .replace("\u00a0", " "))
    t = re.sub(r"//[^\n\"]*$", "", t, flags=re.M)
    t = re.sub(r",\s*([}\]])", r"\1", t)
    try:
        return json.loads(t)
    except Exception:
        return None


def find_json_blocks(text: str, min_keys: int = 2) -> List[Any]:
    """Finds brace-balanced JSON objects inside free text (e.g. the sample request
    at the end of an API document). String-aware, so braces inside values are fine."""
    found, i, n = [], 0, len(text)
    while i < n:
        if text[i] != "{":
            i += 1
            continue
        depth, j, in_str, esc = 0, i, False, False
        while j < n:
            ch = text[j]
            if in_str:
                esc = (ch == "\\" and not esc)
                if ch in ('"', "\u201d") and not esc:
                    in_str = False
            elif ch in ('"', "\u201c"):
                in_str = True
            elif ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    break
            j += 1
        if depth != 0:
            break
        candidate = text[i:j + 1]
        obj = None
        try:
            obj = json.loads(candidate)
        except Exception:
            obj = _lenient_json(candidate)
        if isinstance(obj, dict) and len(obj) >= min_keys:
            found.append(obj)
            i = j + 1              # skip nested objects of a block we already took
        else:
            i += 1
    return found


@st.cache_data(show_spinner=False)
def extract_cached(name: str, kind: str, data: bytes, borderless: bool) -> ExtractedDoc:
    if kind == "pdf":
        return extract_pdf(data, name, borderless)
    if kind == "json":
        return extract_json_file(data, name)
    return extract_text_file(data, name)


# ════════════════════════════════════════════════════════════════════════════
# 3. LLM ANALYSIS (way B only)
# ════════════════════════════════════════════════════════════════════════════
ANALYSIS_SYSTEM_PROMPT = """You are a senior API integration analyst at State Bank of India (SBI).
You are given one or more source documents describing ONE banking API: extracted PDF
text with tables rendered as markdown, plain text notes, and/or JSON samples.
Your job is to understand the API COMPLETELY and describe its REQUEST precisely, so
that an automation tool can build (1) one valid sample request and (2) the validation
rule of every field.

Work in this order (think carefully, but output only the final JSON):

STEP 1 — CONVENTIONS / GLOSSARY
  Find every convention the document defines or uses and record its meaning, e.g.
  "M = Mandatory", "O = Optional", "C = Conditional", "AN = Alphanumeric",
  "N = Numeric", "Length 17 = exact / max length", "(F) = fixed length", date formats
  like "DD/MM/YYYY HH:MM:SS", abbreviations like "CRN", "RRN". Apply them in every
  later step.

STEP 2 — API IDENTITY
  API name/purpose, URL (prefer the UAT/SIT URL if several environments are listed;
  put the others in alternate_urls), HTTP method (default POST if not stated).

STEP 3 — REQUEST FIELD TREE
  Reproduce the COMPLETE request structure exactly as it is sent, preserving nesting
  (e.g. an envelope with SOURCE_ID / DESTINATION / TXN_TYPE / TXN_SUB_TYPE and an
  EIS_PAYLOAD object containing the business fields; or HEADERS + BODY inside it).
  Use the sample request JSON for the STRUCTURE and SAMPLE VALUES; use the field
  tables/text for the RULES (type, length, mandatory, format, allowed values).

  OBJECTS AND ARRAYS
  - An object field has data_type "object" and its fields in "children".
  - An ARRAY OF OBJECTS (a list of rows/records) has data_type "array" and describes
    ONE row in "children" — the fields of a single array element. Do NOT repeat rows.
    Its sample values come from the FIRST row of the sample request.
  - An ARRAY OF PLAIN VALUES (e.g. a list of codes) has data_type "array", no
    children, and its whole sample array in "sample_value" (e.g. ["A1", "B2"]).

  For EVERY field record:
    name            exact key name as it must be sent (case-sensitive)
    data_type       string | integer | number | boolean | date | datetime | object | array
    required        true / false  (apply the M/O/C convention; C → false, and put the
                    condition in validation)
    length          e.g. "exactly 2", "max 17", "1-20" — null if not documented
    format          e.g. "DD/MM/YYYY HH:MM:SS", "alphanumeric", "numeric" — or null
    allowed_values  list of ALL documented permitted values, or []
    sample_value    the value from the sample request if present, otherwise a
                    documented example, otherwise the first allowed value, otherwise
                    null. Keep the EXACT JSON TYPE shown in the sample request: if the
                    sample sends "1" (a string) keep "1"; if it sends 44580.0 keep the
                    number. Account numbers / codes with leading zeros stay STRINGS.
                    null for object fields and arrays of objects.
    validation      ONE concise plain-English rule sentence combining type, length,
                    format, allowed values and conditions, in this style:
                      "String, exactly 2 characters"
                      "Numeric string, max length 17, leading zeros allowed"
                      "Must be in DD/MM/YYYY HH:MM:SS format"
                      "Allowed values: SUCCESS, FAILURE"
                      "Array of related-party rows, at least 1 row"
                    Do NOT start it with "Mandatory"/"Optional" — "required" carries that.
                    Use "" only when the documents state no rule at all.
    description     what the field means (short)
    source          where you found it, e.g. "PDF p.3 Table 2", "sample JSON", "TXT"
    children        object / array-of-objects fields: the nested fields (same shape);
                    else []
  Static request headers that must be sent unchanged (inside EIS_PAYLOAD.HEADERS)
  are fields too — mark them with "is_static_header": true.

STEP 4 — HONESTY
  NEVER invent fields, values or rules that are not supported by the sources.
  If sources conflict, prefer tables over prose for rules, and the sample JSON for
  structure/values — and record the conflict in "conflicts".
  Record anything missing or unclear in "missing_or_ambiguous", and every
  interpretation you had to make in "assumptions".
  Ignore RESPONSE fields for the request tree, but summarise the response / error
  codes briefly in "response_notes".

The selected QA Pariksha API type is given in the user message. It tells you how the
request will be packaged, which helps you decide where fields belong:
  - EIS                : flat request — all business fields at top level, SOURCE_ID at top.
  - EIS_CHANNEL / EIS_MICROSERVICES : envelope {SOURCE_ID, DESTINATION, TXN_TYPE,
    TXN_SUB_TYPE, REQUEST_REFERENCE_NUMBER, EIS_PAYLOAD}, business fields inside
    EIS_PAYLOAD (optionally split into HEADERS + BODY).
Still describe what the DOCUMENT says; if the document clearly uses a different shape
than the selected type, say so in "type_mismatch_note".

OUTPUT — return ONLY one JSON object with exactly these keys:
{
  "api_name": str, "api_description": str, "api_url": str | null,
  "alternate_urls": [str], "method": str,
  "conventions": [{"term": str, "meaning": str, "source": str}],
  "request_fields": [ <field objects as described above> ],
  "response_notes": str,
  "assumptions": [str], "missing_or_ambiguous": [str], "conflicts": [str],
  "type_mismatch_note": str
}"""


def build_analysis_user_message(docs: List[ExtractedDoc], api_type: str, extra: str) -> str:
    parts = [f"Selected QA Pariksha API type: {api_type}\n",
             f"Number of source documents: {len(docs)}\n"]
    for i, d in enumerate(docs, start=1):
        parts.append(f"\n\n########## SOURCE {i}: {d.filename} ({d.kind.upper()}"
                     + (f", {d.page_count} pages, {len(d.tables)} tables" if d.kind == "pdf" else "")
                     + ") ##########\n")
        parts.append(d.text if d.text else "(no text extracted)")
        if d.json_blocks and d.kind != "json":
            parts.append(f"\n\n--- JSON block(s) detected in {d.filename} (parsed) ---")
            for jb in d.json_blocks:
                parts.append(json.dumps(jb, indent=2, ensure_ascii=False))
    if extra.strip():
        parts.append(f"\n\n########## ADDITIONAL INSTRUCTIONS FROM THE USER ##########\n{extra.strip()}")
    parts.append("\n\nAnalyse all sources thoroughly following STEP 1-4 and return the JSON object only.")
    return "\n".join(parts)


def get_client() -> AzureOpenAI:
    return AzureOpenAI(
        api_key=AZURE_API_KEY,
        azure_endpoint=AZURE_ENDPOINT,
        api_version=AZURE_API_VERSION,
        http_client=httpx.Client(verify=AZURE_VERIFY_SSL, timeout=600),
    )


def call_llm_json(system: str, user: str) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    """JSON-mode call with retry. Returns (parsed_json, meta{usage, seconds, finish_reason})."""
    client = get_client()
    last_err: Optional[Exception] = None
    for attempt in range(1, LLM_RETRIES + 2):
        t0 = time.time()
        try:
            resp = client.chat.completions.create(
                model=AZURE_DEPLOYMENT,
                messages=[{"role": "system", "content": system}, {"role": "user", "content": user}],
                temperature=0,
                max_tokens=LLM_MAX_OUT_TOKENS,
                response_format={"type": "json_object"},
            )
            choice = resp.choices[0]
            content = (choice.message.content or "").strip()
            if choice.finish_reason == "length":
                raise ValueError("Model output was cut off (max tokens reached). Try fewer/smaller files.")
            parsed = json.loads(content)
            usage = getattr(resp, "usage", None)
            return parsed, {
                "attempt": attempt,
                "seconds": round(time.time() - t0, 1),
                "finish_reason": choice.finish_reason,
                "prompt_tokens": getattr(usage, "prompt_tokens", None),
                "completion_tokens": getattr(usage, "completion_tokens", None),
            }
        except Exception as e:
            last_err = e
            if attempt <= LLM_RETRIES:
                time.sleep(2 * attempt)
    raise RuntimeError(f"Azure OpenAI call failed after {LLM_RETRIES + 1} attempts: {last_err}")


# ════════════════════════════════════════════════════════════════════════════
# 4. TWO-SECTION MODEL — shared by both ways in
# ════════════════════════════════════════════════════════════════════════════
# A rule is collected while the payload is built:
#   {"segs": ["EIS_PAYLOAD", "related_party_summary[]", "pan"],   # path segments
#    "required": bool, "validation": str, "valid_values": list|None,
#    "kind": "leaf"|"object"|"array", "source": str}
# "name[]" as a segment = "inside every row of array <name>".

def path_text(segs: List[str]) -> str:
    return ".".join(segs)


def payload_paths(node: Any, segs: Optional[List[str]] = None) -> List[Tuple[List[str], str]]:
    """Every addressable field of a payload: [(segments, kind)], containers included."""
    segs = segs or []
    out: List[Tuple[List[str], str]] = []
    if isinstance(node, dict):
        for k, v in node.items():
            p = segs + [str(k)]
            if isinstance(v, dict):
                out.append((p, "object"))
                out += payload_paths(v, p)
            elif isinstance(v, list) and v and all(isinstance(i, dict) for i in v):
                out.append((p, "array"))
                row = p[:-1] + [p[-1] + "[]"]
                seen: Dict[str, Tuple[List[str], str]] = {}
                for item in v:                          # union of keys over all rows
                    for sp, kind in payload_paths(item, row):
                        seen.setdefault(path_text(sp), (sp, kind))
                out += list(seen.values())
            else:
                out.append((p, "array" if isinstance(v, list) else "leaf"))
    return out


def _is_suffix(key_segs: List[str], segs: List[str]) -> bool:
    return len(key_segs) <= len(segs) and segs[len(segs) - len(key_segs):] == key_segs


def resolve_key(key: str, all_paths: List[List[str]]) -> List[List[str]]:
    """Payload paths a validations key points to (a valid key matches exactly one)."""
    ks = [s for s in key.strip().split(".") if s]
    return [p for p in all_paths if ks and _is_suffix(ks, p)]


def shortest_unique_key(segs: List[str], all_paths: List[List[str]]) -> str:
    for n in range(1, len(segs) + 1):
        cand = segs[-n:]
        if sum(1 for p in all_paths if _is_suffix(cand, p)) == 1:
            return path_text(cand)
    return path_text(segs)


def get_at(payload: Any, segs: List[str]) -> Any:
    """Value at a path; "name[]" reads the first row of the array."""
    node = payload
    for s in segs:
        arr = s.endswith("[]")
        k = s[:-2] if arr else s
        if not isinstance(node, dict) or k not in node:
            return None
        node = node[k]
        if arr:
            node = node[0] if isinstance(node, list) and node else None
    return node


def build_validations(payload: Dict[str, Any], rules: List[Dict[str, Any]], style: str) -> Dict[str, Any]:
    """style: "text" → "Mandatory. <rule>" strings (object only when valid_values are needed)
              "object" → every entry as {"required", "validation"[, "valid_values"]}"""
    all_paths = [p for p, _ in payload_paths(payload)]
    out: Dict[str, Any] = {}
    for r in rules:
        key = shortest_unique_key(r["segs"], all_paths)
        text = (r.get("validation") or "").strip()
        vv = r.get("valid_values")
        if style == "object" or vv:
            entry: Dict[str, Any] = {"required": bool(r["required"]), "validation": text}
            if vv:
                entry["valid_values"] = vv
            out[key] = entry
        else:
            out[key] = f"{'Mandatory' if r['required'] else 'Optional'}." + (f" {text}" if text else "")
    return out


# ── Way A: old {value, required, validation} input file → two sections ───────
_SPEC_KEYS = {"value", "required", "validation"}


def _is_field_spec(v: Any) -> bool:
    return isinstance(v, dict) and "value" in v and len(v) >= 2 and set(v) <= _SPEC_KEYS


def _is_spec_map(v: Any) -> bool:
    return isinstance(v, dict) and len(v) > 0 and all(_is_field_spec(x) for x in v.values())


def _is_row_template(v: Any) -> bool:
    """One array row in the old format: a spec map, a {value: spec map} row spec, or an
    object that mixes specs and plain values."""
    if _is_spec_map(v):
        return True
    if _is_field_spec(v) and isinstance(v.get("value"), dict):
        return True
    return isinstance(v, dict) and any(_is_field_spec(x) or _is_spec_map(x) for x in v.values())


def is_old_format(doc: Any) -> bool:
    if not isinstance(doc, dict) or "validations" in doc:
        return False
    p = doc.get("payload")
    return isinstance(p, dict) and len(p) > 0 and sum(1 for v in p.values() if _is_field_spec(v)) >= max(1, len(p) // 2)


def is_two_section(doc: Any) -> bool:
    return isinstance(doc, dict) and isinstance(doc.get("payload"), dict) and isinstance(doc.get("validations"), dict)


def _row_segs(segs: List[str]) -> List[str]:
    return segs[:-1] + [segs[-1] + "[]"]


def convert_old_format(doc: Dict[str, Any], drop_rrn: bool) -> Tuple[Dict[str, Any], List[Dict[str, Any]], List[str]]:
    """Deterministic conversion. Returns (payload, rules, notes)."""
    rules: List[Dict[str, Any]] = []
    notes: List[str] = []

    def add_rule(segs, required, validation, valid_values, kind):
        rules.append({"segs": segs, "required": bool(required), "validation": (validation or "").strip(),
                      "valid_values": valid_values, "kind": kind, "source": "input JSON"})

    def conv_rows(items: List[Any], segs: List[str], collect: bool) -> List[Any]:
        rows = []
        for i, item in enumerate(items):
            if _is_field_spec(item) and isinstance(item.get("value"), dict):
                item = item["value"]                            # {value: {...}} row wrapper
            rows.append(conv_any(item, _row_segs(segs), collect and i == 0))   # rules from row 1 only
        if len(items) > 1:
            notes.append(f"{path_text(segs)}: {len(items)} rows — rules taken from the first row.")
        return rows

    def conv_any(x: Any, segs: List[str], collect: bool) -> Any:
        """x is whatever sits at a field position in the old file."""
        if _is_field_spec(x):
            val = x.get("value")
            if isinstance(val, dict):                           # nested object (or HEADERS/BODY mix)
                if collect:
                    add_rule(segs, x.get("required", True), x.get("validation"), None, "object")
                return {k: conv_any(v, segs + [k], collect) for k, v in val.items()}
            if isinstance(val, list) and val and all(_is_row_template(i) for i in val):
                if collect:                                     # array of objects
                    add_rule(segs, x.get("required", True), x.get("validation"), None, "array")
                return conv_rows(val, segs, collect)
            if isinstance(val, list):                           # list of alternative valid values
                baseline = val[0] if val else None
                if collect:
                    add_rule(segs, x.get("required", True), x.get("validation"),
                             list(val) if len(val) > 1 else None, "leaf")
                return baseline
            if collect:
                add_rule(segs, x.get("required", True), x.get("validation"), None, "leaf")
            return val
        if isinstance(x, list) and x and all(_is_row_template(i) for i in x):
            # raw list directly on the field (no spec wrapper) — array of rows; the row
            # wrapper's required/validation describes the array itself
            first = x[0]
            if collect and _is_field_spec(first):
                add_rule(segs, first.get("required", True), first.get("validation"), None, "array")
                notes.append(f"{path_text(segs)}: array written without a field wrapper — converted.")
            return conv_rows(x, segs, collect)
        if isinstance(x, dict):                                 # container without a spec (e.g. BODY)
            return {k: conv_any(v, segs + [k], collect) for k, v in x.items()}
        return x                                                # static value (e.g. a header) — no rule

    src = dict(doc.get("payload") or {})
    if drop_rrn and RRN_KEY in src:
        src.pop(RRN_KEY)
        notes.append(f"{RRN_KEY} removed — QA Pariksha generates a unique RRN per test case.")
    payload = {k: conv_any(v, [k], True) for k, v in src.items()}
    return payload, rules, notes


# ── Way B: LLM analysis → two sections ─────────────────────────────────────
def _find_ci(fields: List[Dict[str, Any]], name: str) -> Optional[Dict[str, Any]]:
    for f in fields or []:
        if str(f.get("name", "")).strip().lower() == name.lower():
            return f
    return None


def analysis_to_two_section(analysis: Dict[str, Any], api_type: str, use_valid_values: bool,
                            drop_rrn: bool) -> Tuple[Dict[str, Any], List[Dict[str, Any]], List[str]]:
    rules: List[Dict[str, Any]] = []
    notes: List[str] = []
    fields = copy.deepcopy(analysis.get("request_fields") or [])
    if drop_rrn:
        before = len(fields)
        fields = [f for f in fields if str(f.get("name", "")).upper() != RRN_KEY]
        if len(fields) < before:
            notes.append(f"{RRN_KEY} removed — QA Pariksha generates a unique RRN per test case.")

    def leaf_value(f: Dict[str, Any], p: str) -> Any:
        sample = f.get("sample_value")
        allowed = [v for v in (f.get("allowed_values") or []) if v not in (None, "")]
        if sample is not None and sample != "":
            return sample
        if allowed:
            return allowed[0]
        if sample == "":
            return ""
        notes.append(f"{p}: no sample or allowed value in the documents — left empty, please fill in.")
        return ""

    def conv(f: Dict[str, Any], segs: List[str]) -> Any:
        p = path_text(segs)
        dtype = str(f.get("data_type") or "").lower()
        kids = [c for c in (f.get("children") or []) if c.get("name")]
        # a container holding only static headers is itself static (sent as-is, never tested)
        static = bool(f.get("is_static_header")) or (bool(kids) and all(c.get("is_static_header") for c in kids))
        validation = (f.get("validation") or "").strip()
        required = bool(f.get("required", True))

        if kids and dtype == "array":                           # array of objects: one row
            if not static and (validation or required):
                rules.append({"segs": segs, "required": required, "validation": validation,
                              "valid_values": None, "kind": "array", "source": f.get("source") or ""})
            row = {c["name"]: conv(c, _row_segs(segs) + [c["name"]]) for c in kids}
            return [row]
        if kids:                                                # object
            if not static and (validation or required):
                rules.append({"segs": segs, "required": required, "validation": validation,
                              "valid_values": None, "kind": "object", "source": f.get("source") or ""})
            return {c["name"]: conv(c, segs + [c["name"]]) for c in kids}

        value = leaf_value(f, p)
        if dtype == "array" and not isinstance(value, list):
            value = [] if value in ("", None) else [value]
        if static:
            return value                                        # sent unchanged, never tested
        vv = None
        allowed = [v for v in (f.get("allowed_values") or []) if v not in (None, "")]
        if use_valid_values and len(allowed) > 1 and not isinstance(value, list):
            vv = [value] + [a for a in allowed if str(a) != str(value)]
        if validation or required:
            rules.append({"segs": segs, "required": required, "validation": validation,
                          "valid_values": vv, "kind": "array" if isinstance(value, list) else "leaf",
                          "source": f.get("source") or ""})
        return value

    payload: Dict[str, Any] = {}
    if api_type in WRAPPED_TYPES:
        for pf in PARENT_FIELDS:
            node = _find_ci(fields, pf)
            if node is None:                                    # sometimes listed inside EIS_PAYLOAD
                eis = _find_ci(fields, EIS_PAYLOAD_KEY)
                node = _find_ci((eis or {}).get("children") or [], pf)
                if eis and node:
                    eis["children"] = [c for c in eis["children"] if c is not node]
            if node is None:
                notes.append(f"{pf} not found in the documents — added empty; please fill in.")
                node = {"name": pf, "required": True, "sample_value": "", "validation": "String"}
            node = {**node, "required": True, "children": []}   # structurally mandatory
            payload[pf] = conv(node, [pf])
        eis = _find_ci(fields, EIS_PAYLOAD_KEY)
        if eis is None:
            rest = [f for f in fields if str(f.get("name", "")).upper() not in set(PARENT_FIELDS) | {RRN_KEY}]
            notes.append("No EIS_PAYLOAD object in the documents — all business fields were placed inside it.")
            eis = {"name": EIS_PAYLOAD_KEY, "data_type": "object", "children": rest, "required": True}
        eis_children = [c for c in (eis.get("children") or []) if c.get("name")]
        rules.append({"segs": [EIS_PAYLOAD_KEY], "required": True,
                      "validation": (eis.get("validation") or "Object with the business fields").strip(),
                      "valid_values": None, "kind": "object", "source": "envelope"})
        payload[EIS_PAYLOAD_KEY] = {c["name"]: conv(c, [EIS_PAYLOAD_KEY, c["name"]]) for c in eis_children}
    else:
        if _find_ci(fields, EIS_PAYLOAD_KEY) or _find_ci(fields, "DESTINATION"):
            notes.append("The document looks like an EIS Channel/Microservices request "
                         "(EIS_PAYLOAD / DESTINATION found) but EIS was selected — check the API type.")
        for f in fields:
            if f.get("name"):
                payload[f["name"]] = conv(f, [f["name"]])
        if "SOURCE_ID" not in payload:
            notes.append("SOURCE_ID not found — it is mandatory for EIS; added empty, please fill in.")
            payload = {"SOURCE_ID": "", **payload}
            rules.insert(0, {"segs": ["SOURCE_ID"], "required": True, "validation": "String, exactly 2 characters",
                             "valid_values": None, "kind": "leaf", "source": "QA Pariksha rule"})
    return payload, rules, notes


def assemble_two_section(api_name: str, api_url: str, method: str, payload: Dict[str, Any],
                         rules: List[Dict[str, Any]], style: str) -> Dict[str, Any]:
    return {
        "api_name": api_name or "Unnamed API",
        "api_url": api_url or "",
        "method": (method or "POST").upper(),
        "payload": payload,
        "validations": build_validations(payload, rules, style),
    }


# ════════════════════════════════════════════════════════════════════════════
# 5. CHECKS — run on every result, and again on the user's edits
# ════════════════════════════════════════════════════════════════════════════
def _contains_spec(node: Any) -> Optional[str]:
    """Path of the first leftover {value, required, validation} object, if any."""
    def walk(n, p):
        if _is_field_spec(n):
            return p or "(root)"
        if isinstance(n, dict):
            for k, v in n.items():
                r = walk(v, f"{p}.{k}" if p else k)
                if r:
                    return r
        if isinstance(n, list):
            for i, v in enumerate(n):
                r = walk(v, f"{p}[{i}]")
                if r:
                    return r
        return None
    return walk(node, "")


def check_two_section(doc: Any, api_type: str) -> Tuple[List[Tuple[str, str]], List[Dict[str, Any]]]:
    """Returns (issues[(level, message)], field_map rows)."""
    issues: List[Tuple[str, str]] = []
    rows: List[Dict[str, Any]] = []
    if not isinstance(doc, dict):
        return [("error", "The file must be a JSON object.")], rows
    for k in ("api_name", "api_url", "method"):
        if not doc.get(k):
            issues.append(("error" if k == "api_url" else "warning", f"Top-level '{k}' is empty."))
    payload, validations = doc.get("payload"), doc.get("validations")
    if not isinstance(payload, dict) or not payload:
        return issues + [("error", "'payload' must be a non-empty object (Section 1).")], rows
    if not isinstance(validations, dict):
        return issues + [("error", "'validations' must be an object (Section 2).")], rows

    leftover = _contains_spec(payload)
    if leftover:
        issues.append(("error", f"payload.{leftover} still has a {{value, required, validation}} object — "
                                "Section 1 must hold plain values only."))
    if api_type in WRAPPED_TYPES:
        for pf in PARENT_FIELDS + [EIS_PAYLOAD_KEY]:
            if pf not in payload:
                issues.append(("error", f"'{pf}' is mandatory at the top of the payload for {api_type}."))
        if EIS_PAYLOAD_KEY in payload and not isinstance(payload[EIS_PAYLOAD_KEY], dict):
            issues.append(("error", f"{EIS_PAYLOAD_KEY} must be an object."))
    elif "SOURCE_ID" not in payload:
        issues.append(("error", "'SOURCE_ID' is mandatory in the payload."))
    sid = payload.get("SOURCE_ID")
    if isinstance(sid, str) and len(sid.strip()) != 2:
        issues.append(("error", f"SOURCE_ID '{sid}' must be exactly 2 characters (used in the RRN)."))

    paths = payload_paths(payload)
    all_segs = [p for p, _ in paths]
    kind_of = {path_text(p): k for p, k in paths}
    covered: set = set()
    for key, entry in validations.items():
        hits = resolve_key(key, all_segs)
        if not hits:
            issues.append(("error", f"validations['{key}'] matches no field in the payload (typo?)."))
            continue
        if len(hits) > 1:
            issues.append(("error", f"validations['{key}'] matches {len(hits)} fields "
                                    f"({', '.join(path_text(h) for h in hits[:4])}) — use a longer path."))
            continue
        segs = hits[0]
        covered.add(path_text(segs))
        if isinstance(entry, str):
            required = not entry.strip().lower().startswith(("optional", "o.", "o ", "if present"))
            if not entry.strip().lower().startswith(("mandatory", "optional", "m.", "o.", "if present")):
                issues.append(("warning", f"validations['{key}'] doesn't start with 'Mandatory.' or 'Optional.' "
                                          "— it will be treated as mandatory."))
            text, vv = entry, None
        elif isinstance(entry, dict):
            extra = set(entry) - {"required", "validation", "valid_values"}
            if extra:
                issues.append(("warning", f"validations['{key}'] has unknown keys {sorted(extra)} — ignored."))
            required, text, vv = bool(entry.get("required", True)), str(entry.get("validation") or ""), entry.get("valid_values")
            if vv is not None and (not isinstance(vv, list) or len(vv) < 2):
                issues.append(("warning", f"validations['{key}'].valid_values should list 2 or more values."))
            base = get_at(payload, segs)
            if isinstance(vv, list) and vv and not any(str(v) == str(base) for v in vv):
                issues.append(("warning", f"validations['{key}']: the payload value {json.dumps(base)} "
                                          "is not in valid_values."))
        else:
            issues.append(("error", f"validations['{key}'] must be a text rule or an object."))
            continue
        rows.append({"rule key": key, "payload path": path_text(segs), "kind": kind_of.get(path_text(segs)),
                     "baseline value": json.dumps(get_at(payload, segs), ensure_ascii=False)[:120],
                     "required": required, "validation": text,
                     "valid values": ", ".join(map(str, vv)) if isinstance(vv, list) else ""})
    untested = [path_text(p) for p, k in paths if k == "leaf" and path_text(p) not in covered]
    for p in untested:
        rows.append({"rule key": "—", "payload path": p, "kind": "leaf",
                     "baseline value": json.dumps(get_at(payload, p.split(".")), ensure_ascii=False)[:120],
                     "required": None, "validation": "(no rule — sent unchanged, not tested)", "valid values": ""})
    if untested:
        issues.append(("info", f"{len(untested)} field(s) have no rule and will not be tested: "
                               + ", ".join(untested[:8]) + (" …" if len(untested) > 8 else "")))
    return issues, rows


def _leaf_keys(obj: Any) -> set:
    keys = set()
    if isinstance(obj, dict):
        for k, v in obj.items():
            keys.add(k)
            keys |= _leaf_keys(v)
    elif isinstance(obj, list):
        for v in obj:
            keys |= _leaf_keys(v)
    return keys


def coverage_check(docs: List[ExtractedDoc], payload: Dict[str, Any], drop_rrn: bool) -> Dict[str, List[str]]:
    """Keys in the sample request(s) found in the documents vs keys in Section 1."""
    sample_keys: set = set()
    for d in docs:
        for jb in d.json_blocks:
            if is_old_format(jb) or is_two_section(jb):
                continue
            sample_keys |= _leaf_keys(jb)
    if drop_rrn:
        sample_keys.discard(RRN_KEY)
    out_keys = _leaf_keys(payload)
    return {
        "in_sample_not_in_output": sorted(sample_keys - out_keys),
        "in_output_not_in_sample": sorted(out_keys - sample_keys) if sample_keys else [],
    }


def fields_table(fields: List[Dict[str, Any]], parent: str = "") -> List[Dict[str, Any]]:
    rows = []
    for f in fields or []:
        path = f"{parent}.{f.get('name')}" if parent else str(f.get("name"))
        rows.append({
            "field": path, "type": f.get("data_type"), "required": f.get("required"),
            "length": f.get("length"), "format": f.get("format"),
            "allowed_values": ", ".join(map(str, f.get("allowed_values") or [])),
            "sample_value": json.dumps(f.get("sample_value"), ensure_ascii=False) if f.get("sample_value") is not None else "",
            "validation": f.get("validation"), "source": f.get("source"), "description": f.get("description"),
        })
        child_prefix = path + ("[]" if str(f.get("data_type") or "").lower() == "array" else "")
        rows += fields_table(f.get("children") or [], child_prefix)
    return rows


# ════════════════════════════════════════════════════════════════════════════
# UI
# ════════════════════════════════════════════════════════════════════════════
import inspect as _inspect
_FULL = ({"width": "stretch"} if "width" in _inspect.signature(st.button).parameters
         else {"use_container_width": True})

STYLE_OPTIONS = {
    "text": "Text rules — \"Mandatory. …\" / \"Optional. …\" (object only when valid values are listed)",
    "object": "Objects — {required, validation, valid_values} for every field",
}
LEVEL_ICON = {"error": "❌", "warning": "⚠️", "info": "ℹ️"}


def _mask(s: str) -> str:
    return (s[:4] + "…" + s[-4:]) if len(s) > 10 else ("set" if s else "")


def _safe_name(s: str) -> str:
    return re.sub(r"[^A-Za-z0-9_-]+", "_", s or "api")[:60].strip("_") or "api"


def _show_issues(issues: List[Tuple[str, str]]) -> int:
    errors = [m for lvl, m in issues if lvl == "error"]
    if errors:
        st.error("Fix before using in QA Pariksha:\n\n" + "\n".join(f"- {e}" for e in errors))
    others = [(lvl, m) for lvl, m in issues if lvl != "error"]
    if others:
        with st.expander(f"{len(others)} note(s) / warning(s)", expanded=not errors):
            for lvl, m in others:
                st.write(f"{LEVEL_ICON[lvl]} {m}")
    if not errors:
        st.success("No errors — every rule points to exactly one payload field. Ready for QA Pariksha.")
    return len(errors)


def _detect_mode(valid_files: List[Tuple[str, str, bytes]]) -> Tuple[str, Optional[Dict[str, Any]]]:
    """'convert' (old input JSON), 'recheck' (already two-section) or 'ai' (documents)."""
    if len(valid_files) == 1 and valid_files[0][1] == "json":
        text = _decode_text(valid_files[0][2]) or ""
        try:
            doc = json.loads(text)
        except json.JSONDecodeError:
            doc = _lenient_json(text)
        if is_old_format(doc):
            return "convert", doc
        if is_two_section(doc):
            return "recheck", doc
    return "ai", None


def main() -> None:
    st.set_page_config(page_title="QA Pariksha · Two-section Input Builder", page_icon="🧩", layout="wide")
    st.title("🧩 QA Pariksha — Two-section Input JSON Builder")
    st.caption("Section 1 = the real request (payload) · Section 2 = the rule of each field (validations).")

    with st.sidebar:
        st.subheader("Azure OpenAI (documents only)")
        ok_cfg = all([AZURE_API_KEY, AZURE_ENDPOINT, AZURE_DEPLOYMENT])
        st.write(f"Endpoint: `{AZURE_ENDPOINT or '—'}`")
        st.write(f"Deployment: `{AZURE_DEPLOYMENT}` · API `{AZURE_API_VERSION}`")
        st.write(f"Key: `{_mask(AZURE_API_KEY) or 'missing'}` · SSL verify: `{AZURE_VERIFY_SSL}`")
        if not ok_cfg:
            st.warning("No Azure settings — converting an existing input JSON still works.")
        st.divider()
        st.subheader("Options")
        style = st.radio("Section 2 style", list(STYLE_OPTIONS), format_func=lambda k: STYLE_OPTIONS[k])
        use_valid_values = st.checkbox("Allowed values → valid_values", value=True,
                                       help="If a field lists several allowed values (e.g. Y / N), list them all "
                                            "in valid_values so QA Pariksha makes a positive test case for each.")
        drop_rrn = st.checkbox(f"Exclude {RRN_KEY}", value=True,
                               help="QA Pariksha generates a unique RRN for every test case.")
        borderless = st.checkbox("Detect borderless tables (PDF)", value=False,
                                 help="Turn on only if tables without borders are being missed.")

    c1, c2 = st.columns([3, 2])
    with c1:
        uploads = st.file_uploader("Existing input JSON, or API documents (1–3 files: PDF, JSON, TXT)",
                                   type=["pdf", "json", "txt"], accept_multiple_files=True)
    with c2:
        api_type = st.selectbox("API type", list(API_TYPES.keys()), format_func=lambda k: API_TYPES[k])
        extra = st.text_area("Extra instructions for the AI (optional)", height=90,
                             placeholder="e.g. Use the UAT URL. sr_no is sent as a string.")

    valid_files: List[Tuple[str, str, bytes]] = []
    if uploads:
        if len(uploads) > MAX_FILES:
            st.error(f"Please upload at most {MAX_FILES} files (you selected {len(uploads)}).")
            uploads = []
        names_seen, report = set(), []
        for uf in uploads:
            data = uf.getvalue()
            if uf.name in names_seen:
                report.append({"file": uf.name, "status": "❌", "detail": "Duplicate file name — skipped."})
                continue
            names_seen.add(uf.name)
            ok, msg, kind = validate_upload(uf.name, uf.type or "", data)
            report.append({"file": uf.name, "MIME (browser)": uf.type or "—",
                           "size": f"{len(data) / 1024:.1f} KB", "status": "✅" if ok else "❌", "detail": msg})
            if ok:
                valid_files.append((uf.name, kind, data))
        st.dataframe(pd.DataFrame(report), hide_index=True, **_FULL)

    mode, src_doc = _detect_mode(valid_files) if valid_files else ("ai", None)
    if valid_files:
        st.info({
            "convert": "**Existing QA Pariksha input JSON detected** — it will be converted in code (no AI call).",
            "recheck": "**This file is already in the two-section format** — it will be checked and re-formatted.",
            "ai": "**API documents** — Azure OpenAI will analyse them, then the two sections are built in code.",
        }[mode])
    label = {"convert": "🔁 Convert to two-section JSON", "recheck": "🔎 Check two-section JSON",
             "ai": "⚙️ Generate two-section JSON"}[mode]
    can_run = bool(valid_files) and (mode != "ai" or ok_cfg)
    if valid_files and mode == "ai" and not ok_cfg:
        st.error("Analysing documents needs the Azure OpenAI settings in .env.")
    run = st.button(label, type="primary", disabled=not can_run, **_FULL)

    if run:
        for k in ("result", "edited_json"):
            st.session_state.pop(k, None)
        res: Dict[str, Any] = {"mode": mode, "api_type": api_type, "docs": [], "analysis": None,
                               "meta": None, "user_msg": None, "notes": [], "coverage": None, "rules_src": []}
        if mode == "convert":
            payload, rules, notes = convert_old_format(src_doc, drop_rrn)
            res["out"] = assemble_two_section(src_doc.get("api_name"), src_doc.get("api_url"),
                                              src_doc.get("method"), payload, rules, style)
            res["notes"] = notes
        elif mode == "recheck":
            res["out"] = src_doc
        else:
            with st.status("Working…", expanded=True) as status:
                st.write("📄 Extracting text, tables and sample JSON…")
                docs = [extract_cached(n, k, d, borderless) for n, k, d in valid_files]
                total_chars = sum(len(d.text) for d in docs)
                if total_chars > MAX_CONTEXT_CHARS:
                    status.update(label="Documents too large", state="error")
                    st.error(f"Extracted content is {total_chars:,} characters (limit {MAX_CONTEXT_CHARS:,}). "
                             "Upload only the pages describing this API.")
                    st.stop()
                if not any(d.text.strip() or d.json_blocks for d in docs):
                    status.update(label="Nothing to analyse", state="error")
                    st.error("No text could be extracted from the uploaded files.")
                    st.stop()
                st.write(f"🧠 Analysing {total_chars:,} characters with `{AZURE_DEPLOYMENT}`…")
                user_msg = build_analysis_user_message(docs, api_type, extra)
                try:
                    analysis, meta = call_llm_json(ANALYSIS_SYSTEM_PROMPT, user_msg)
                except Exception as e:
                    status.update(label="Azure OpenAI call failed", state="error")
                    st.error(str(e))
                    st.stop()
                st.write("🧱 Building payload + validations…")
                payload, rules, notes = analysis_to_two_section(analysis, api_type, use_valid_values, drop_rrn)
                res.update(docs=docs, analysis=analysis, meta=meta, user_msg=user_msg, notes=notes,
                           out=assemble_two_section(analysis.get("api_name"), analysis.get("api_url"),
                                                    analysis.get("method"), payload, rules, style),
                           coverage=coverage_check(docs, payload, drop_rrn))
                status.update(label="Done", state="complete", expanded=False)
        st.session_state["result"] = res
        st.session_state["edited_json"] = json.dumps(res["out"], indent=2, ensure_ascii=False)

    res = st.session_state.get("result")
    if not res:
        st.info("Upload an existing input JSON (converted without AI) or the API documents, choose the API type "
                "and click the button.")
        return

    # ── Current (possibly edited) document is the source of truth for checks + download ──
    try:
        current = json.loads(st.session_state["edited_json"])
        parse_error = None
    except json.JSONDecodeError as e:
        current, parse_error = None, str(e)
    issues, rows = check_two_section(current, res["api_type"]) if current is not None else ([], [])

    m1, m2, m3, m4 = st.columns(4)
    m1.metric("Mode", {"convert": "Converted", "recheck": "Checked", "ai": "AI analysis"}[res["mode"]])
    m2.metric("Payload fields", sum(1 for r in rows if r["kind"] == "leaf"))
    m3.metric("Rules (Section 2)", len(current.get("validations") or {}) if isinstance(current, dict) else 0)
    m4.metric("Errors", sum(1 for lvl, _ in issues if lvl == "error") + (1 if parse_error else 0))

    tab_names = ["✅ Two-section JSON", "🗺️ Field map"]
    if res["mode"] == "ai":
        tab_names += ["🧠 What the model understood", "📄 Extracted content", "🔎 Exact prompt sent"]
    tabs = st.tabs(tab_names)

    with tabs[0]:
        if parse_error:
            st.error(f"Edited JSON is invalid: {parse_error}")
        else:
            _show_issues(issues)
        for n in res["notes"]:
            st.caption(f"• {n}")
        if res["analysis"] and res["analysis"].get("type_mismatch_note"):
            st.warning(f"API type check: {res['analysis']['type_mismatch_note']}")
        st.text_area("Two-section JSON (edit freely — checks re-run on every change)", key="edited_json", height=560)
        name = _safe_name((current or {}).get("api_name", "api") if isinstance(current, dict) else "api")
        d1, d2 = st.columns(2)
        d1.download_button("⬇️ Download two-section JSON", data=st.session_state["edited_json"] if not parse_error else "",
                           file_name=f"{name}_{res['api_type']}_two_section.json", mime="application/json",
                           disabled=bool(parse_error), type="primary", **_FULL)
        if res["analysis"]:
            d2.download_button("⬇️ Download full analysis", mime="application/json",
                               data=json.dumps(res["analysis"], indent=2, ensure_ascii=False),
                               file_name=f"{name}_analysis.json", **_FULL)
        cov = res.get("coverage")
        if cov and (cov["in_sample_not_in_output"] or cov["in_output_not_in_sample"]):
            st.subheader("Coverage vs. sample request in the documents")
            cc1, cc2 = st.columns(2)
            cc1.write("**In sample request, missing from payload**")
            cc1.write(cov["in_sample_not_in_output"] or "— none —")
            cc2.write("**In payload, not in sample request** (from tables/text)")
            cc2.write(cov["in_output_not_in_sample"] or "— none —")

    with tabs[1]:
        st.caption("Every payload field, the Section 2 key that points to it, and its rule. "
                   "Fields without a rule are sent unchanged in every test case.")
        if rows:
            st.dataframe(pd.DataFrame(rows), hide_index=True, **_FULL)
        elif parse_error:
            st.info("Fix the JSON to see the field map.")

    if res["mode"] == "ai":
        analysis, meta = res["analysis"], res["meta"]
        with tabs[2]:
            st.markdown(f"**API:** {analysis.get('api_name', '—')}  \n"
                        f"**URL:** `{analysis.get('api_url') or '—'}`  ·  **Method:** `{analysis.get('method', '—')}`")
            if analysis.get("alternate_urls"):
                st.write("Other URLs found:", analysis["alternate_urls"])
            if analysis.get("api_description"):
                st.write(analysis["api_description"])
            st.subheader("Conventions / glossary applied")
            conv = analysis.get("conventions") or []
            st.dataframe(pd.DataFrame(conv) if conv else pd.DataFrame([{"term": "—", "meaning": "none found"}]),
                         hide_index=True, **_FULL)
            st.subheader("Request fields (with the evidence used)")
            st.dataframe(pd.DataFrame(fields_table(analysis.get("request_fields") or [])), hide_index=True, **_FULL)
            for key, label in [("assumptions", "Assumptions made"), ("missing_or_ambiguous", "Missing / ambiguous"),
                               ("conflicts", "Conflicts between sources")]:
                items = analysis.get(key) or []
                if items:
                    with st.expander(f"{label} ({len(items)})", expanded=key != "assumptions"):
                        for it in items:
                            st.write(f"- {it}")
            if analysis.get("response_notes"):
                with st.expander("Response / error codes (summary)"):
                    st.write(analysis["response_notes"])
            with st.expander("Raw analysis JSON"):
                st.json(analysis)
            st.caption(f"Model call: {meta.get('seconds')} s, attempt {meta.get('attempt')}, "
                       f"tokens in/out {meta.get('prompt_tokens')}/{meta.get('completion_tokens')}, "
                       f"finish_reason={meta.get('finish_reason')}")
        with tabs[3]:
            for d in res["docs"]:
                with st.expander(f"{d.filename} — {d.kind.upper()}"
                                 + (f" · {d.page_count} pages · {len(d.tables)} tables" if d.kind == "pdf" else "")
                                 + f" · {len(d.json_blocks)} JSON block(s)", expanded=len(res["docs"]) == 1):
                    for w in d.warnings:
                        st.warning(w)
                    for i, t in enumerate(d.tables, start=1):
                        span = f"pages {t.pages[0]}–{t.pages[-1]} (merged)" if len(t.pages) > 1 else f"page {t.page}"
                        st.caption(f"Table {i} · {span} · {len(t.rows)} rows")
                        st.dataframe(t.to_dataframe(), hide_index=True, **_FULL)
                    for jb in d.json_blocks:
                        st.json(jb, expanded=False)
                    st.text_area("text", d.text, height=300, key=f"txt_{d.filename}", label_visibility="collapsed")
        with tabs[4]:
            with st.expander("System prompt"):
                st.code(ANALYSIS_SYSTEM_PROMPT, language="markdown")
            st.text_area("User message", res["user_msg"], height=420)


if __name__ == "__main__":
    main()
