"""
api/utils/eis_request_tests.py

EIS request-level test cases — optional ("Include EIS request-level test cases").

Two kinds, both built in code (no AI), both NEGATIVE:

1. ENVELOPE cases — the business payload stays at its valid baseline; only the FINAL
   request sent to the EIS gateway is broken:
       headers {Content-Type, AccessToken}
       body    {DIGI_SIGN, REQUEST, REQUEST_REFERENCE_NUMBER}
   Each case carries a code in the "EIS_Request_Change" column. The change itself is
   applied at RUN time, because encryption and signing happen then:
     - RRN changes        → api_testcase_utils.apply_request_change_to_payload()
     - everything else    → eis_api_utils.prepare_eis_request(..., request_change=code)
   Server Run and the Desktop Agent's prepare step both go through these, so the two
   paths always send the same thing.

2. EXTRA-FIELD cases — an unexpected field (EXTRA_FIELD_NAME) is added at EACH object
   level of the payload (top level, every nested object, the first row of every array
   of objects; for EIS Channel also EIS_PAYLOAD / HEADERS / BODY). These are ordinary
   payload changes — visible and editable in Test Data. Expected: the API rejects with
   'UNEXPECTED FIELD <field name>'.
"""
from typing import Any, Dict, List, Optional

from api.utils.two_section_utils import RRN_FIELD, payload_paths, path_text

REQUEST_CHANGE_COLUMN = "EIS_Request_Change"
EXTRA_FIELD_NAME = "QA_EXTRA_FIELD"
EXTRA_FIELD_VALUE = "unexpected"
EXPECTED_EXTRA_FIELD_ERROR = f"UNEXPECTED FIELD {EXTRA_FIELD_NAME}"

# A different 32-byte AES key — for "encrypted with another key" cases.
OTHER_AES_KEY = b"QAPariksha-other-AES-key-32bytes"

# code → (needs an RRN inside the payload, description after "To verify <api> ")
ENVELOPE_CASES: List[tuple] = [
    # ── DIGI_SIGN ──
    ("DIGI_SIGN_MISSING",        False, "with DIGI_SIGN missing from the EIS request displays an error."),
    ("DIGI_SIGN_EMPTY",          False, "with DIGI_SIGN empty in the EIS request displays an error."),
    ("DIGI_SIGN_WRONG_PAYLOAD",  False, "with a DIGI_SIGN that does not match the request payload (tampered request) displays an error."),
    ("DIGI_SIGN_NOT_BASE64",     False, "with DIGI_SIGN not in Base64 format displays an error."),
    # ── REQUEST ──
    ("REQUEST_MISSING",          False, "with REQUEST missing from the EIS request displays an error."),
    ("REQUEST_EMPTY",            False, "with REQUEST empty in the EIS request displays an error."),
    ("REQUEST_BYTE_CHANGED",     False, "with the encrypted REQUEST altered in transit (one byte changed) displays an error."),
    ("REQUEST_WRONG_KEY",        False, "with REQUEST encrypted with a different key than the AccessToken carries displays an error."),
    ("REQUEST_PLAIN_JSON",       False, "with an unencrypted (plain JSON) REQUEST displays an error."),
    # ── REQUEST_REFERENCE_NUMBER ──
    ("RRN_MISSING",              False, "with REQUEST_REFERENCE_NUMBER missing from the EIS request displays an error."),
    ("RRN_WRONG_LENGTH",         False, "with REQUEST_REFERENCE_NUMBER of wrong length (24 characters) displays an error."),
    ("RRN_INNER_MISMATCH",       True,  "with the REQUEST_REFERENCE_NUMBER in the EIS request different from the one inside the payload displays an error."),
    ("RRN_DUPLICATE",            False, "with a duplicate REQUEST_REFERENCE_NUMBER (same request sent twice — second call) displays an error."),
    ("RRN_SOURCE_ID_MISMATCH",   False, "with REQUEST_REFERENCE_NUMBER built from a channel different from SOURCE_ID displays an error."),
    ("RRN_SOURCE_ID_MISMATCH_INNER", True, "with the REQUEST_REFERENCE_NUMBER inside the payload built from a channel different from SOURCE_ID displays an error."),
    ("RRN_NOT_SBI",              False, "with REQUEST_REFERENCE_NUMBER not starting with SBI displays an error."),
    ("RRN_NOT_SBI_INNER",        True,  "with the REQUEST_REFERENCE_NUMBER inside the payload not starting with SBI displays an error."),
    # ── Body ──
    ("BODY_EXTRA_FIELD",         False, f'with unexpected field {EXTRA_FIELD_NAME} in the EIS request body displays error "{EXPECTED_EXTRA_FIELD_ERROR}".'),
    ("BODY_EMPTY",               False, "with an empty EIS request body {} displays an error."),
    # ── Headers / method ──
    ("ACCESS_TOKEN_MISSING",     False, "with the AccessToken header missing displays an error."),
    ("ACCESS_TOKEN_INVALID",     False, "with an invalid AccessToken header displays an error."),
    ("ACCESS_TOKEN_WRONG_KEY",   False, "with an AccessToken carrying a different key than the one used to encrypt REQUEST displays an error."),
    ("CONTENT_TYPE_TEXT",        False, "with Content-Type text/plain instead of application/json displays an error."),
    ("METHOD_GET",               False, "called with HTTP GET instead of POST displays an error."),
]
ENVELOPE_CODES = {c[0] for c in ENVELOPE_CASES}


def extra_field_levels(payload: Dict[str, Any]) -> List[List[str]]:
    """Every object level of the payload, shallowest first: [] (top level), each nested
    object, and the first row ("name[]") of each array of objects."""
    levels: List[List[str]] = [[]]
    for segs, kind in payload_paths(payload):
        if kind == "object":
            levels.append(segs)
        elif kind == "array":
            row = segs[:-1] + [segs[-1] + "[]"]
            if any(p[:len(row)] == row for p, _ in payload_paths(payload)):
                levels.append(row)
    levels.sort(key=len)
    return levels


def _level_label(segs: List[str]) -> str:
    if not segs:
        return "the top level of the payload"
    text = path_text(segs)
    return f"{text} (first row)" if segs[-1].endswith("[]") else text


def build_request_level_specs(api_name: str, payload: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Case specs in the same shape generate_api_testcases_two_section() uses:
    {type, segs, action, value, description, request_change?}."""
    specs: List[Dict[str, Any]] = []

    # 1. Unexpected field at every object level of the payload.
    for level in extra_field_levels(payload):
        specs.append({
            "type": "Negative", "segs": level + [EXTRA_FIELD_NAME], "action": "set", "value": EXTRA_FIELD_VALUE,
            "description": (f'To verify {api_name} with unexpected field {EXTRA_FIELD_NAME} added at '
                            f'{_level_label(level)} displays error "{EXPECTED_EXTRA_FIELD_ERROR}".'),
        })

    # 2. Envelope cases — payload at baseline, change applied at run time.
    has_inner_rrn = RRN_FIELD in payload
    for code, needs_inner, text in ENVELOPE_CASES:
        if needs_inner and not has_inner_rrn:
            continue
        specs.append({
            "type": "Negative", "segs": None, "action": "baseline", "value": None,
            "description": f"To verify {api_name} {text}",
            "request_change": code,
        })
    return specs
