"""
api/utils/api_testcase_utils.py

Generates positive/negative API test cases from a TWO-SECTION input file
(api_name, api_url, method, payload{the real request}, validations{field: rule}).
See api/utils/two_section_utils.py for the file format and the checks.

Who builds what:
  - CODE builds every test case's "Test Data": a deep copy of the baseline payload
    with exactly ONE change applied. Arrays, nested objects and HEADERS/BODY are
    therefore always kept exactly as given.
  - CODE creates the cases that need no judgement:
        the baseline positive case,
        one positive case per extra entry in a field's valid_values,
        the "field missing" case (Negative if Mandatory, Positive if Optional).
  - The LLM only proposes INVALID VALUES that break each field's stated rule
    (plus, for a stated min/max range, the two valid boundary values marked
    "positive": true — exactly min and exactly max):
        [{"field": "<validations key>", "value": <invalid value>, "description": "..."}]
    Fields are sent in batches of 10 in JSON mode. Long strings come back as
    {"value": "<pattern>", "repeat_to_length": N} and are expanded in code.
    An unusable answer is logged, the batch is split, and a field that still fails
    only loses its invalid-value cases (reported in "warnings") — never the run.

RRN (REQUEST_REFERENCE_NUMBER), unchanged in behaviour:
  - EIS_CHANNEL / EIS_MICROSERVICES: every test case gets a fresh unique RRN in
    Test Data, always built from the BASELINE SOURCE_ID.
  - EIS (flat): if the payload carries an RRN, every test case gets a fresh one;
    otherwise none is added to Test Data and one is generated per call at run time
    (resolve_run_rrn) — also from the BASELINE SOURCE_ID.
  - The test case whose field under test IS the RRN keeps its deliberate value.
  - At RUN time every well-formed RRN is replaced by a fresh one (resolve_run_rrn),
    so saved test cases can be run again and again.
"""
import json
import re
import threading
from datetime import datetime
from zoneinfo import ZoneInfo
from typing import Dict, Any, List, Optional, Tuple
from api.utils.azure_utility import client, MODEL
from api.utils.eis_request_tests import REQUEST_CHANGE_COLUMN, build_request_level_specs
from api.utils.two_section_utils import (
    SOURCE_ID_FIELD,
    RRN_FIELD,
    DESTINATION_FIELD,
    TXN_TYPE_FIELD,
    TXN_SUB_TYPE_FIELD,
    EIS_PAYLOAD_FIELD,
    apply_change,
    same_value,
)


RRN_TOTAL_LENGTH = 25
RRN_PREFIX = "SBI"

# Running sequence number (NNNNNN) — process-local, thread-safe, wraps at 999999.
_rrn_sequence_lock = threading.Lock()
_rrn_sequence_counter = 0
_RRN_SEQUENCE_MULTIPLIER = 400223  # must stay coprime with 1_000_000 (not divisible by 2 or 5)


def _next_sequence_number() -> str:
    """Thread-safe running sequence number, 6 digits. Collision-free across a
    full 1,000,000-call cycle (same guarantee as a plain counter), but scrambled
    so consecutive calls don't look sequential."""
    global _rrn_sequence_counter
    with _rrn_sequence_lock:
        _rrn_sequence_counter = (_rrn_sequence_counter + 1) % 1_000_000
        counter = _rrn_sequence_counter
    scrambled = (counter * _RRN_SEQUENCE_MULTIPLIER) % 1_000_000
    return f"{scrambled:06d}"


def make_rrn(source_id: str) -> str:
    """
    Builds a REQUEST_REFERENCE_NUMBER in the bank-mandated format:

        SBI   XX   YYDDD   HHmmssSSS   NNNNNN
        (3)  (2)    (5)       (9)        (6)     = 25 characters total

    - SBI       : fixed literal prefix.
    - XX        : Channel Identifier, taken from SOURCE_ID (must be exactly 2 chars,
                  e.g. "LT" for the YONO channel).
    - YYDDD     : Julian date — 2-digit year + 3-digit day-of-year
                  (e.g. 26-Feb-2020 -> "20" + "057" = "20057").
    - HHmmssSSS : current time — hour, minute, second, millisecond.
    - NNNNNN    : 6-digit running sequence number (wraps at 999999).
    """
    channel_id = str(source_id).strip().upper()
    if len(channel_id) != 2:
        raise ValueError(
            f"SOURCE_ID '{source_id}' must be exactly 2 characters to be used as the "
            f"RRN Channel Identifier (XX), got {len(channel_id)} characters."
        )

    now = datetime.now(ZoneInfo("Asia/Kolkata"))  # bank-local (IST) timestamp

    julian_date = f"{now.strftime('%y')}{now.timetuple().tm_yday:03d}"        # YYDDD
    time_part   = f"{now.strftime('%H%M%S')}{now.microsecond // 1000:03d}"    # HHmmssSSS
    sequence    = _next_sequence_number()                                     # NNNNNN

    rrn = f"{RRN_PREFIX}{channel_id}{julian_date}{time_part}{sequence}"

    assert len(rrn) == RRN_TOTAL_LENGTH, f"Generated RRN is {len(rrn)} chars, expected {RRN_TOTAL_LENGTH}"
    return rrn



_RRN_RE = re.compile(r"^SBI[A-Za-z0-9]{2}\d{20}$")


def is_well_formed_rrn(value: Any) -> bool:
    """True for an RRN in the make_rrn format: SBI + 2-char channel + 20 digits."""
    return isinstance(value, str) and bool(_RRN_RE.match(value.strip()))


def _channel(source_id: Any) -> Optional[str]:
    """A usable 2-char RRN channel id, or None."""
    c = str(source_id or "").strip().upper()
    return c if len(c) == 2 else None


def _baseline_channel(generated_reference_number: Any) -> Optional[str]:
    """The 2-char channel id (baseline SOURCE_ID) inside an RRN made by make_rrn."""
    g = str(generated_reference_number or "").strip()
    if len(g) == RRN_TOTAL_LENGTH and g.startswith(RRN_PREFIX):
        return g[len(RRN_PREFIX):len(RRN_PREFIX) + 2]
    return None


def resolve_run_rrn(
    payload: Dict[str, Any],
    generated_reference_number: Optional[str],
    baseline_source_id: Optional[str] = None,
) -> Tuple[Any, Optional[str], Dict[str, Any]]:
    """
    RRN for ONE call at run time (server Run and Desktop Agent prepare-batch).
    Returns (rrn, error_text_or_None, payload_to_send).

    Channel id = the BASELINE SOURCE_ID: baseline_source_id if given, else the one
    inside generated_reference_number. The test case's own SOURCE_ID may be the field
    under test (wrong length, special characters, missing) — it must not stop the call
    reaching EIS.

      1. payload has a WELL-FORMED RRN (SBI + 2 chars + 20 digits) → replaced by a FRESH
         one on every run, inside the payload and in the envelope, so re-running saved
         test cases is never rejected as a duplicate reference number.
      2. payload has a MALFORMED RRN (an RRN negative test case) → sent exactly as is.
      3. payload has no RRN → a fresh one for the envelope only (not added to the payload).
      4. No baseline known (older results/files) → the test case's own SOURCE_ID.
    """
    payload = dict(payload) if isinstance(payload, dict) else {}
    channel = _channel(baseline_source_id) or _baseline_channel(generated_reference_number)

    supplied = payload.get(RRN_FIELD)
    if supplied not in (None, ""):
        if is_well_formed_rrn(supplied):
            fresh = make_rrn(channel or supplied.strip()[len(RRN_PREFIX):len(RRN_PREFIX) + 2])
            payload[RRN_FIELD] = fresh
            return fresh, None, payload
        return supplied, None, payload                     # deliberate RRN negative case

    if channel:
        return make_rrn(channel), None, payload

    source_id = payload.get(SOURCE_ID_FIELD)
    if source_id:
        try:
            return make_rrn(str(source_id)), None, payload
        except ValueError as e:
            return None, f"ERROR: {e}", payload
    return generated_reference_number or "", None, payload


def apply_request_change_to_payload(
    request_change: Optional[str],
    payload: Dict[str, Any],
    rrn: Any,
) -> Tuple[Dict[str, Any], Any]:
    """
    EIS request-level test cases (eis_request_tests.py) — the RRN changes, applied
    AFTER resolve_run_rrn() (so the fresh-RRN step never undoes them) and BEFORE
    encryption. "outer" = REQUEST_REFERENCE_NUMBER in the EIS request body;
    "inner" = REQUEST_REFERENCE_NUMBER inside the payload (EIS Channel, or a flat
    payload that carries one). Returns (payload_to_send, outer_rrn).
    Other codes are applied after encryption, in eis_api_utils.prepare_eis_request().
    """
    if not request_change:
        return payload, rrn
    payload = dict(payload)
    has_inner = RRN_FIELD in payload
    rrn_s = str(rrn or "")
    channel = rrn_s[len(RRN_PREFIX):len(RRN_PREFIX) + 2] if is_well_formed_rrn(rrn_s) else "XX"
    other = "ZZ" if channel.upper() != "ZZ" else "YY"

    def _set_both(value: str) -> Tuple[Dict[str, Any], Any]:
        if has_inner:
            payload[RRN_FIELD] = value
        return payload, value

    if request_change == "RRN_WRONG_LENGTH":
        return _set_both(rrn_s[:-1] if len(rrn_s) > 1 else "SBI")
    if request_change == "RRN_SOURCE_ID_MISMATCH":
        return _set_both(make_rrn(other))
    if request_change == "RRN_NOT_SBI":
        return _set_both("XYZ" + rrn_s[len(RRN_PREFIX):])
    if has_inner and request_change == "RRN_INNER_MISMATCH":
        payload[RRN_FIELD] = make_rrn(channel)                       # a second, different fresh RRN
    elif has_inner and request_change == "RRN_SOURCE_ID_MISMATCH_INNER":
        payload[RRN_FIELD] = make_rrn(other)
    elif has_inner and request_change == "RRN_NOT_SBI_INNER":
        payload[RRN_FIELD] = "XYZ" + str(payload[RRN_FIELD])[len(RRN_PREFIX):]
    return payload, rrn


# ============================================================================
# Test case generation — two-section input
# ============================================================================

API_TESTCASE_SYSTEM_PROMPT = """You are an expert API test analyst for a banking application (State Bank of India).
You write NEGATIVE test cases (plus the valid range-boundary cases of category E)
for ONE REST API. You do not build payloads: the caller
holds the real baseline request and applies each change you describe to a copy of it.

## WHAT YOU RECEIVE
- BASELINE PAYLOAD: the complete, valid request exactly as the API receives it.
  Context only — never repeat it in your output.
- FIELDS TO TEST: a JSON array. Each item has:
    "field"        : the field's id — copy it EXACTLY into your output
    "path"         : where the field sits in the payload ("[]" = inside an array row)
    "baseline"     : the field's valid value in the baseline payload
    "required"     : whether the field is mandatory
    "validation"   : the plain-English rule for the field
    "valid_values" : every value known to be VALID for the field

## THE CALLER ALREADY CREATES THESE — NEVER OUTPUT THEM
- The baseline positive test case.
- One positive test case per extra entry in "valid_values".
- The "key missing" test case for every field (Negative when required=true,
  Positive when required=false).
So never output a case that removes a field, and never output a positive test case
EXCEPT the two valid range-boundary cases of category E (marked "positive": true).

## STRICT RULES — FOLLOW EXACTLY
1. ONE CHANGE PER TEST CASE
   Each test case puts ONE invalid value into ONE field from FIELDS TO TEST.
   Never combine fields — every other field keeps its baseline value.

2. ONLY THE STATED RULE
   Each test case breaks exactly ONE distinct aspect of that field's "validation"
   (e.g. for "10 digit numeric": 9 digits, 11 digits, contains alphabets, contains
   special characters). Do not invent rules that were not stated.

3. THE VALUE MUST ACTUALLY BE INVALID
   - Never use the baseline or any entry of "valid_values".
   - Use the JSON type the violation needs: e.g. for "type should be string", send
     the number 9876543210 rather than the string "9876543210".
   - Change only what is needed to break the rule and keep the rest realistic
     (e.g. a 9-digit mobile number = the baseline without its last digit).
   - "value" must be a LITERAL JSON value. Never write code or expressions such as
     "A".repeat(101), "A" * 101 or "AB" + "CD", and never add comments.
   - LONG STRINGS: for a string longer than 30 characters, put a short pattern in
     "value" and the total length in "repeat_to_length". The caller repeats the
     pattern and cuts it to exactly that length, e.g.
       {"value": "A", "repeat_to_length": 101}    → 101 A's
       {"value": "AB1", "repeat_to_length": 256}  → "AB1AB1…" (256 characters)

4. NEGATIVE AND EDGE-CASE TEST CASES — ONE CATEGORY AT A TIME
   Every field in FIELDS TO TEST is in scope. General rules for every category:
   - Rule 1 applies: each test case changes EXACTLY ONE field.
   - Generate a category for a field ONLY when it is relevant to that field's
     stated "validation" (or its "required" flag for B/C). Never invent a
     boundary, length, format or accepted value that the validation text does
     not state or directly imply.
   - "Baseline value" below means the field's "baseline".
   - Every case below is a NEGATIVE case, except the two valid boundary cases
     of category E.

   B. VALUE NULL — key present, value is JSON null (not the string "null").
      - Always for required=true fields.
      - For required=false fields ONLY when the validation states a type, format,
        length or fixed values that null cannot satisfy.

   C. VALUE EMPTY — key present, value is the empty string "".
      Same applicability as B. This is a SEPARATE test case from B — never merge
      "null" and "empty" into one case.

   D. FIXED LENGTH — ONLY when the validation states ONE exact length or digit
      count N (e.g. "must be N characters", "N digit numeric").
      TWO negative cases:
      - length N - 1
      - length N + 1
      (Exactly N is the baseline itself — already tested.)

   E. RANGE — ONLY when the validation states a MINIMUM and/or a MAXIMUM, either
      for the LENGTH (e.g. "min X, max Y characters") or for a NUMERIC VALUE
      (e.g. "amount between X and Y").
      Up to FOUR cases:
      - min - 1  → NEGATIVE
      - min      → POSITIVE: add "positive": true   (skip if it equals the baseline)
      - max      → POSITIVE: add "positive": true   (skip if it equals the baseline)
      - max + 1  → NEGATIVE
      If only a minimum is stated, output only "min - 1" and "min".
      If only a maximum is stated, output only "max" and "max + 1".
      Never output any other value inside the range.

   A field gets D OR E, never both — pick by how its validation is worded.
   For D and E length cases, build the value by trimming / extending the baseline
   value with characters of the SAME kind (digits for numeric fields, letters for
   alphabetic fields), so that LENGTH is the only thing that changes. For E
   numeric-value cases, keep the baseline's JSON type (number stays number).

   F. BOOLEAN FORMAT VARIANTS — ONLY when the validation or the baseline /
      valid_values indicate a boolean / flag field (true/false, Y/N, 1/0, yes/no).
      - Candidate representations: for TRUE — "True", "true", "Y", "y", 1
                                    for FALSE — "False", "false", "N", "n", 0
        (strings in quotes are JSON strings; 1 and 0 are JSON numbers).
      - Skip any candidate that is IDENTICAL (same JSON type AND value) to the
        baseline or to an entry of "valid_values" — the caller already covers
        those as positive cases.
      - Every remaining candidate is a separate NEGATIVE test case, even if the
        validation text seems to accept it. Positive cases come only from
        "valid_values": a representation that should be accepted must be added
        to "valid_values" in the input file to be tested as positive.

   G. SPECIAL CHARACTERS — ONLY for fields whose validation restricts the allowed
      characters or format (numeric, alphanumeric, alphabetic, fixed allowed
      values, a date/time format, a code). Skip fields whose validation explicitly
      allows free text with special characters.
      ONE case: the baseline value with special characters injected, mixing
      symbols, an SQL-injection-style fragment and one non-ASCII character,
      e.g. "TIN2!@#$%^&'--;€".

   H. SPACES IN BETWEEN — ONLY for fields whose baseline value has no internal
      spaces and whose validation implies a contiguous value (numeric,
      alphanumeric, a code, an account / mobile / reference number, a fixed
      length).
      ONE case: insert one or more spaces in the middle of the baseline value,
      e.g. "991 234 5678". For a field whose baseline is a JSON number, send the
      spaced value as a string.

   I. LEADING / TRAILING SPACES — same applicability as H. TWO separate cases:
      - TRAILING: the baseline value followed by spaces, e.g. "TIN2 ".
      - LEADING: spaces followed by the baseline value, e.g. " TIN2".
      For a JSON-number baseline, send the value as a string.

   J. OTHER RULE VIOLATIONS — further negative cases, each breaking exactly ONE
      distinct aspect of the stated validation that B–I do not already cover
      (e.g. alphabets in a numeric field, wrong date format, a value outside the
      stated allowed values, wrong JSON type). Pick the most realistic and
      relevant ones — do not invent rules that were not stated.

   Do not produce two test cases with the same value for the same field.

5. TEST CASE DESCRIPTION — must state field + rule/category being verified
   General form: "To verify <api_name> with <field> <plain description of the
   violation> displays an error."
   <field> is the field id exactly as given in FIELDS TO TEST.
   For categories B–I the description MUST contain the category wording below
   (so each category is traceable in the report); put the actual test value in
   brackets where shown:
     B  "To verify <api_name> with <field> key present but value null displays an error."
     C  "To verify <api_name> with <field> key present but value empty displays an error."
     D  "To verify <api_name> with <field> shorter than the fixed length (<n> characters) displays an error."
        "To verify <api_name> with <field> longer than the fixed length (<n> characters) displays an error."
     E  length range:
        "To verify <api_name> with <field> below minimum length (<n> characters) displays an error."
        "To verify <api_name> with <field> at minimum length (<n> characters) processes the request successfully."
        "To verify <api_name> with <field> at maximum length (<n> characters) processes the request successfully."
        "To verify <api_name> with <field> above maximum length (<n> characters) displays an error."
        numeric value range:
        "To verify <api_name> with <field> below minimum value (<value>) displays an error."
        "To verify <api_name> with <field> at minimum value (<value>) processes the request successfully."
        "To verify <api_name> with <field> at maximum value (<value>) processes the request successfully."
        "To verify <api_name> with <field> above maximum value (<value>) displays an error."
     F  "To verify <api_name> with <field> in boolean format <literal> displays an error."
     G  "To verify <api_name> with <field> containing special characters (<value>) displays an error."
     H  "To verify <api_name> with <field> containing spaces in between (<value>) displays an error."
     I  "To verify <api_name> with <field> having trailing spaces displays an error."
        "To verify <api_name> with <field> having leading spaces displays an error."
   For J, use the general form, e.g.
     "To verify Mobile Enquiry API with mobile_number containing alphabets displays an error."
     "To verify Mobile Enquiry API with REQUEST_REFERENCE_NUMBER greater than 25 characters displays an error."

## OUTPUT FORMAT — ONE JSON OBJECT, NOTHING ELSE
Return ONLY a JSON object of the form {"test_cases": [ ... ]}. Each element has:
  "field": string — the field id, copied exactly from FIELDS TO TEST
  "value": any literal JSON value — the invalid value to put in that field
  "description": string — the test case description
  "repeat_to_length": integer — OPTIONAL, only for long strings (see rule 3)
  "positive": true — ONLY on the two valid boundary cases of category E (min, max);
                     leave it out everywhere else
No other keys, no markdown fences, no commentary. Return {"test_cases": []} if no
field needs a test case."""

LLM_FIELDS_PER_CALL = 10          # fields per LLM call — a bad answer only costs a few fields
LLM_MAX_OUTPUT_TOKENS = 16000
MAX_REPEAT_LENGTH = 100_000       # upper bound for "repeat_to_length"
RAW_ANSWER_LOG_CHARS = 2000       # how much of an unusable AI answer is printed to the log

# JSON mode (response_format=json_object) guarantees a syntactically valid answer.
# Switched off automatically if the deployment ever rejects the parameter.
_json_mode_supported = True


def _strip_json_fences(content: str) -> str:
    content = (content or "").strip()
    if content.startswith("```"):
        lines = content.split("\n")
        content = "\n".join(lines[1:-1]) if len(lines) > 2 else content
    return content.replace("```json", "").replace("```", "").strip()


def _show(v: Any, limit: int = 60) -> str:
    """A value as it should read inside a test case description."""
    s = v if isinstance(v, str) else json.dumps(v, ensure_ascii=False)
    return s if len(s) <= limit else s[: limit - 3] + "..."


def _build_llm_user_message(
    api_name: str, api_url: str, method: str, api_type: str, testcase_type: str,
    payload: Dict[str, Any], batch: List[Dict[str, Any]], user_prompt: Optional[str],
) -> str:
    fields_json = [
        {
            "field": f["field"],
            "path": f["path"],
            "baseline": f["baseline"],
            "required": f["required"],
            "validation": f["validation"],
            "valid_values": f["valid_values"],
        }
        for f in batch
    ]
    msg = (
        f"Write negative test cases for the following API.\n\n"
        f"API Name: {api_name}\n"
        f"API URL: {api_url}\n"
        f"HTTP Method: {method.upper()}\n"
        f"API Type: {api_type}\n"
        f"Test Environment: {testcase_type}\n\n"
        f"BASELINE PAYLOAD (valid request — context only):\n"
        f"{json.dumps(payload, indent=2, ensure_ascii=False)}\n\n"
        f"FIELDS TO TEST:\n"
        f"{json.dumps(fields_json, indent=2, ensure_ascii=False)}\n"
    )
    if user_prompt:
        msg += f"\nAdditional instructions from the user:\n{user_prompt}\n"
    msg += (
        "\nFollow all rules from the system prompt strictly. Change only ONE field per test case, "
        "use only values that break the stated rule, and cover all realistic violations and "
        "edge cases. Return the JSON object {\"test_cases\": [...]} only."
    )
    return msg


def _parse_llm_items(content: str) -> List[Dict[str, Any]]:
    parsed = json.loads(_strip_json_fences(content))
    if isinstance(parsed, dict):                      # {"test_cases": [...]} (JSON mode)
        if isinstance(parsed.get("test_cases"), list):
            parsed = parsed["test_cases"]
        else:
            lists = [v for v in parsed.values() if isinstance(v, list)]
            parsed = lists[0] if lists else ([] if not parsed else None)
    if not isinstance(parsed, list):
        raise ValueError("LLM response has no test_cases array")
    items = []
    for it in parsed:
        if isinstance(it, dict):
            items.append({str(k).strip().lower(): v for k, v in it.items()})
    return items


class _AnswerCutOff(Exception):
    """The AI answer stopped at the output-token limit."""


def _call_llm(user_message: str):
    """One chat completion, in JSON mode when the deployment supports it."""
    global _json_mode_supported
    kwargs = dict(
        model=MODEL,
        messages=[
            {"role": "system", "content": API_TESTCASE_SYSTEM_PROMPT},
            {"role": "user", "content": user_message},
        ],
        temperature=0.2,
        max_tokens=LLM_MAX_OUTPUT_TOKENS,
    )
    if _json_mode_supported:
        try:
            return client.chat.completions.create(**kwargs, response_format={"type": "json_object"})
        except Exception as e:
            if "response_format" not in str(e):
                raise
            print(f"    ⚠ JSON mode not accepted by this deployment — continuing without it ({e})")
            _json_mode_supported = False
    return client.chat.completions.create(**kwargs)


def _llm_negatives(
    api_name: str, api_url: str, method: str, api_type: str, testcase_type: str,
    payload: Dict[str, Any], batch: List[Dict[str, Any]], user_prompt: Optional[str],
    max_retries: int, warnings: List[str],
) -> List[Dict[str, Any]]:
    """
    Invalid values for a batch of fields.
      - Several fields: ONE attempt; if the answer is unusable (bad JSON, cut off,
        API error) the batch is split in half and each half is asked separately,
        so one bad field never costs the others.
      - One field: up to max_retries attempts; if all fail, that field gets no
        invalid-value cases and a warning is recorded — generation carries on.
    Unusable answers are printed to the log (first RAW_ANSWER_LOG_CHARS characters).
    """
    user_message = _build_llm_user_message(
        api_name, api_url, method, api_type, testcase_type, payload, batch, user_prompt,
    )
    names = ", ".join(f["field"] for f in batch)
    attempts = 1 if len(batch) > 1 else max_retries
    last_error: Optional[Exception] = None
    for attempt in range(1, attempts + 1):
        content: Optional[str] = None
        finish_reason = None
        try:
            print(f"    Generating negative values for [{names}] (attempt {attempt}/{attempts})…")
            response = _call_llm(user_message)
            choice = response.choices[0]
            content = choice.message.content
            finish_reason = getattr(choice, "finish_reason", None)
            if finish_reason == "length":
                raise _AnswerCutOff("answer cut off at the output-token limit")
            return _parse_llm_items(content)
        except Exception as e:
            last_error = e
            print(f"    ✗ Attempt {attempt} failed: {e}")
            if content:
                print(f"    ↳ raw AI answer (first {RAW_ANSWER_LOG_CHARS} chars, finish_reason={finish_reason}):\n"
                      f"{content[:RAW_ANSWER_LOG_CHARS]}")

    if len(batch) > 1:
        mid = len(batch) // 2
        print(f"    ↳ splitting {len(batch)} fields in two and asking again")
        return (
            _llm_negatives(api_name, api_url, method, api_type, testcase_type,
                           payload, batch[:mid], user_prompt, max_retries, warnings)
            + _llm_negatives(api_name, api_url, method, api_type, testcase_type,
                             payload, batch[mid:], user_prompt, max_retries, warnings)
        )

    field = batch[0]["field"]
    warnings.append(f'No invalid-value test cases for "{field}" — the AI answer could not be used '
                    f"after {attempts} attempt(s): {last_error}")
    print(f"    ⚠ {warnings[-1]}")
    return []


def _expand_value(item: Dict[str, Any]) -> Tuple[bool, Any]:
    """(ok, value) — applies "repeat_to_length" to a string pattern."""
    value = item.get("value")
    n = item.get("repeat_to_length")
    if n is None:
        return True, value
    try:
        n = int(n)
    except (TypeError, ValueError):
        return True, value                                 # unusable length → keep the literal value
    if not isinstance(value, str) or not value or n <= 0:
        return True, value
    if n > MAX_REPEAT_LENGTH:
        return False, None
    return True, (value * (n // len(value) + 1))[:n]


def _match_field(raw_id: Any, fields: List[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    """The field an LLM item refers to — by id, else by full path."""
    rid = str(raw_id or "").strip()
    for f in fields:
        if f["field"] == rid:
            return f
    for f in fields:
        if f["path"] == rid:
            return f
    low = rid.lower()
    hits = [f for f in fields if f["field"].lower() == low]
    return hits[0] if len(hits) == 1 else None


def _json_kind(v: Any) -> str:
    """JSON type name — bool is not a number here."""
    if isinstance(v, bool):
        return "boolean"
    if isinstance(v, (int, float)):
        return "number"
    if isinstance(v, str):
        return "string"
    return type(v).__name__


def _clean_llm_negatives(
    api_name: str, items: List[Dict[str, Any]], fields: List[Dict[str, Any]],
) -> Dict[str, List[Dict[str, Any]]]:
    """Keeps only usable items, grouped by field id: known field, has a value, the
    value is really different from every valid value, no duplicates.
    An item marked "positive": true (category E range boundary: exactly min / max)
    becomes a Positive case — only if its JSON type matches the baseline's."""
    by_field: Dict[str, List[Dict[str, Any]]] = {f["field"]: [] for f in fields}
    dropped = 0
    for it in items:
        f = _match_field(it.get("field"), fields)
        if f is None or "value" not in it or not f["validation"]:
            dropped += 1
            continue
        ok, value = _expand_value(it)
        if not ok:
            dropped += 1                                        # absurd length
            continue
        if any(same_value(value, v) for v in f["valid_values"]):
            dropped += 1                                        # not a negative at all
            continue
        if any(same_value(value, c["value"]) for c in by_field[f["field"]]):
            dropped += 1                                        # duplicate
            continue
        positive = it.get("positive") is True or str(it.get("positive", "")).strip().lower() == "true"
        if positive and _json_kind(value) != _json_kind(f["baseline"]):
            dropped += 1                                        # a "valid boundary" of the wrong type
            continue
        desc = str(it.get("description") or "").strip() or (
            f"To verify {api_name} with {f['field']} set to {_show(value)} "
            + ("processes the request successfully." if positive else "displays an error.")
        )
        by_field[f["field"]].append({"value": value, "description": desc,
                                     "type": "Positive" if positive else "Negative"})
    if dropped:
        print(f"    ⚠ Dropped {dropped} unusable LLM item(s) (unknown field / valid value / duplicate)")
    return by_field


def _with_rrn(test_data: Dict[str, Any], rrn: str) -> Dict[str, Any]:
    """Sets REQUEST_REFERENCE_NUMBER; when it is new, inserts it just before
    EIS_PAYLOAD so the envelope keeps its usual order."""
    if RRN_FIELD in test_data or EIS_PAYLOAD_FIELD not in test_data:
        test_data[RRN_FIELD] = rrn
        return test_data
    out: Dict[str, Any] = {}
    for k, v in test_data.items():
        if k == EIS_PAYLOAD_FIELD:
            out[RRN_FIELD] = rrn
        out[k] = v
    return out


def generate_api_testcases_two_section(
    api_name: str,
    api_url: str,
    method: str,
    api_type: str,
    wrapped: bool,
    prepared: Dict[str, Any],
    user_prompt: Optional[str] = None,
    testcase_type: str = "UAT",
    max_retries: int = 3,
    include_request_tests: bool = False,
) -> Tuple[List[Dict[str, Any]], List[str]]:
    """
    prepared = two_section_utils.prepare_two_section(...) output.
    include_request_tests → also the EIS request-level cases (eis_request_tests.py),
    appended after the field cases; envelope cases carry REQUEST_CHANGE_COLUMN.
    Returns (test cases in the usual output shape, warnings). A warning names a
    field whose invalid-value cases could not be generated; all other cases are kept.
    Raises only when the AI failed for EVERY field that needed it.
    """
    payload: Dict[str, Any] = prepared["payload"]
    fields: List[Dict[str, Any]] = prepared["fields"]
    source_id: str = prepared["source_id"]

    # ── 1. LLM: invalid values, in batches of fields ─────────────────────────
    to_ask = [f for f in fields if f["validation"]]
    items: List[Dict[str, Any]] = []
    warnings: List[str] = []
    for i in range(0, len(to_ask), LLM_FIELDS_PER_CALL):
        items += _llm_negatives(
            api_name, api_url, method, api_type, testcase_type,
            payload, to_ask[i:i + LLM_FIELDS_PER_CALL], user_prompt, max_retries, warnings,
        )
    if to_ask and len(warnings) == len(to_ask):
        raise RuntimeError(f"the AI could not generate invalid values for any field — {warnings[-1]}")
    negatives = _clean_llm_negatives(api_name, items, fields)

    # ── 2. Case list: baseline, then per field (valid values, missing, invalid) ─
    specs: List[Dict[str, Any]] = [{
        "type": "Positive", "segs": None, "action": "baseline", "value": None,
        "description": f"To verify {api_name} with correct payload fetches correct details from the API.",
    }]
    for f in fields:
        for v in f["valid_values"][1:]:
            specs.append({
                "type": "Positive", "segs": f["segs"], "action": "set", "value": v,
                "description": (f"To verify {api_name} accepts a valid {f['field']} ({_show(v)}) "
                                f"and processes the request successfully."),
            })
        if f["required"]:
            specs.append({
                "type": "Negative", "segs": f["segs"], "action": "remove", "value": None,
                "description": f"To verify {api_name} with mandatory field {f['field']} missing displays an error.",
            })
        else:
            specs.append({
                "type": "Positive", "segs": f["segs"], "action": "remove", "value": None,
                "description": f"To verify {api_name} accepts the request when optional field {f['field']} is not sent.",
            })
        for n in negatives.get(f["field"], []):
            specs.append({
                "type": n.get("type", "Negative"), "segs": f["segs"], "action": "set", "value": n["value"],
                "description": n["description"],
            })

    # ── 2b. Optional EIS request-level cases (envelope + unexpected fields) ──
    if include_request_tests:
        baseline_with_rrn = _with_rrn(dict(payload), "SBI" + source_id + "0" * 20) \
            if (wrapped or prepared["rrn_in_payload"]) else payload
        specs += build_request_level_specs(api_name, baseline_with_rrn)

    # ── 3. Test Data = baseline copy + one change; RRN per test case ─────────
    give_fresh_rrn = wrapped or prepared["rrn_in_payload"]
    testcases: List[Dict[str, Any]] = []
    for idx, s in enumerate(specs, start=1):
        td = apply_change(payload, s["segs"], s["action"], s["value"])
        rrn_under_test = s["segs"] == [RRN_FIELD]
        if give_fresh_rrn and not rrn_under_test:
            td = _with_rrn(td, make_rrn(source_id))           # always from the BASELINE SOURCE_ID
        tc = {
            "Function Description": api_name,
            "Test Case ID": f"TC_API_{idx:03d}",
            "Test Case Description": s["description"],
            "Test Case Type": s["type"],
            "API_URL": api_url,
            "API_METHOD": method.upper(),
            "Test Data": td,
        }
        if s.get("request_change"):
            tc[REQUEST_CHANGE_COLUMN] = s["request_change"]
        testcases.append(tc)

    pos = sum(1 for t in testcases if t["Test Case Type"] == "Positive")
    print(f"    ✓ Generated {len(testcases)} API test cases ({pos} positive, {len(testcases) - pos} negative)"
          + (f", {len(warnings)} warning(s)" if warnings else ""))
    return testcases, warnings


# ============================================================================
# Pass/Fail evaluation (post Run-Automation)
# ============================================================================
EVALUATE_TESTCASE_SYSTEM_PROMPT = """You are an expert API test analyst for a banking application (State Bank of India).
You are given a batch of already-executed API test cases. For each one you receive:
  - "Test Case Description": what the test case is supposed to verify
  - "Test Case Type": "Positive" or "Negative"
  - "Actual_Response": the real response text captured after actually calling the API

Decide whether each test case PASSED or FAILED, based ONLY on whether the actual
response matches what the description says should happen for that test type.

## READING THE ACTUAL_RESPONSE — TWO POSSIBLE SHAPES

Actual_Response is either a plain-text gateway/network error, or decrypted JSON
in ONE of these two shapes — figure out which one you're looking at first:

1. FLAT — the business result is directly in the top-level fields:
   RESPONSE_STATUS ("0" = accepted/success, "1" or "2" = rejected), ERROR_CODE /
   ERROR_DESCRIPTION (non-empty = rejected), or the whole response is a
   "GATEWAY ERROR [...]" string (always a rejection). This is what plain EIS
   calls return, and also what a gateway-level rejection looks like for any
   call type.

2. NESTED under "EIS_RESPONSE" — this is what EIS Channel / EIS Microservices
   calls return: the DOWNSTREAM service's own response sits inside an
   "EIS_RESPONSE" object, with its OWN "success" (true/false), "statusCode"
   (HTTP-style: 2xx = success, 4xx/5xx = rejection), and "errors" (non-null /
   non-empty = rejected) fields. Top-level RESPONSE_STATUS / ERROR_CODE /
   ERROR_DESCRIPTION sitting ALONGSIDE "EIS_RESPONSE" only report whether the
   EIS gateway itself successfully routed the request and got a reply — that
   is a SEPARATE concern from whether the downstream service accepted the
   payload, and it is very common (and NOT a bug) for RESPONSE_STATUS to be
   "0" (gateway worked fine) at the very same time "EIS_RESPONSE" shows
   "success": false / a 4xx-5xx "statusCode" / non-empty "errors" (the
   downstream service rejected the input). Whenever "EIS_RESPONSE" is present,
   you MUST judge PASS/FAIL from ITS fields, NOT from the top-level
   RESPONSE_STATUS / ERROR_CODE / ERROR_DESCRIPTION next to it. The exact field
   names inside the nested envelope may vary slightly by downstream service
   (e.g. "status" instead of "statusCode", errors as a list instead of an
   object) — use judgment on the equivalent business-outcome signal, but the
   core principle always holds: a nested envelope's OWN outcome wins over the
   outer gateway-level fields sitting alongside it.

## RULES

1. POSITIVE test cases PASS when the business result (per whichever shape
   above applies) indicates SUCCESS — e.g. flat RESPONSE_STATUS "0" with no
   ERROR_CODE/ERROR_DESCRIPTION, or (when EIS_RESPONSE is present)
   EIS_RESPONSE.success is true / statusCode is 2xx / errors is null or empty,
   with correct customer/business data returned.
   They FAIL when the business result shows an error/rejection instead of
   success.

2. NEGATIVE test cases PASS when the business result (per whichever shape
   above applies) indicates the API correctly REJECTED the invalid input —
   e.g. flat RESPONSE_STATUS "1"/"2" or a non-empty ERROR_CODE/ERROR_DESCRIPTION,
   any "GATEWAY ERROR [...]" message, or (when EIS_RESPONSE is present)
   EIS_RESPONSE.success is false / statusCode is 4xx-5xx / errors is non-empty.
   They FAIL when the business result indicates the API incorrectly ACCEPTED
   the bad input and returned success/business data anyway (this is a real
   bug — the validation that should have blocked it did not).

3. If the Actual_Response is empty, or begins with "ERROR:" describing a network,
   timeout, decryption, or key-loading failure (NOT a business/gateway rejection),
   mark it FAILED with a Remarks note that execution itself did not complete
   (this is inconclusive, not a validation success or failure — but for pass/fail
   purposes it must be treated as FAILED so it gets flagged for manual review).

4. Judge each test case independently. Do not let one test case's error code
   influence your judgment of another.

5. Be objective — do not assume test intent beyond what "Test Case Description"
   and "Test Case Type" literally state. If the actual response is ambiguous
   relative to the description, prefer FAILED with a Remarks note explaining the
   ambiguity, rather than guessing PASS.

6. EXPECTED ERROR TEXT — when a Negative test case's description says it
   'displays error "<text>"' (an exact message in double quotes), it PASSES only
   if the API rejected the request AND the actual response contains that text
   (ignore upper/lower case and extra spaces). A rejection with a different
   message FAILS — say in Remarks which message was expected and which came back.

## OUTPUT FORMAT — JSON ONLY, NOTHING ELSE
Return ONLY a JSON array, one element per input test case, in the SAME ORDER as
given, with EXACTLY these keys:
  "Test Case ID": string (copy from input, unchanged)
  "Pass_Fail": "Pass" or "Fail"
  "Remarks": string (ONE short sentence explaining the verdict, referencing what
             the actual response actually showed)
Do not add markdown fences or commentary. Do not omit any test case."""


def evaluate_api_testcases_via_llm(
    testcases: List[Dict[str, Any]],
    max_retries: int = 3,
) -> Dict[str, Dict[str, str]]:
    """
    Sends (Test Case ID, Test Case Description, Test Case Type, Actual_Response) for
    every test case in ONE batched LLM call and gets back a Pass/Fail verdict + short
    remark for each. Returns a dict keyed by Test Case ID for easy lookup by the
    caller: { "TC_API_001": {"Pass_Fail": "Pass", "Remarks": "..."} , ... }
    """
    slim_input = [
        {
            "Test Case ID": tc.get("Test Case ID", ""),
            "Test Case Description": tc.get("Test Case Description", ""),
            "Test Case Type": tc.get("Test Case Type", ""),
            "Actual_Response": str(tc.get("Actual_Response", "")),
        }
        for tc in testcases
    ]

    user_message = (
        "Evaluate the following executed API test cases and return a Pass/Fail "
        "verdict for each, following the system prompt rules strictly.\n\n"
        f"{json.dumps(slim_input, indent=2, ensure_ascii=False)}\n\n"
        "Return the JSON array only, same order, one entry per test case."
    )

    last_error = None
    for attempt in range(1, max_retries + 1):
        try:
            print(f"    Evaluating pass/fail (attempt {attempt}/{max_retries})…")
            response = client.chat.completions.create(
                model=MODEL,
                messages=[
                    {"role": "system", "content": EVALUATE_TESTCASE_SYSTEM_PROMPT},
                    {"role": "user", "content": user_message},
                ],
                temperature=0.1,
                max_tokens=16000,
            )
            content = _strip_json_fences(response.choices[0].message.content)
            parsed = json.loads(content)
            if not isinstance(parsed, list):
                raise ValueError("LLM response is not a JSON array")

            result: Dict[str, Dict[str, str]] = {}
            for item in parsed:
                if not isinstance(item, dict):
                    continue
                tc_id = str(item.get("Test Case ID", "")).strip()
                if not tc_id:
                    continue
                verdict = str(item.get("Pass_Fail", "")).strip().capitalize()
                if verdict not in ("Pass", "Fail"):
                    verdict = "Fail"
                result[tc_id] = {
                    "Pass_Fail": verdict,
                    "Remarks": str(item.get("Remarks", "")).strip(),
                }

            if not result:
                raise ValueError("No valid verdicts parsed from LLM response")

            print(f"    ✓ Evaluated {len(result)} test cases")
            return result

        except Exception as e:
            last_error = e
            print(f"    ✗ Attempt {attempt} failed: {e}")

    raise RuntimeError(f"Pass/Fail evaluation failed after {max_retries} attempts: {last_error}")


