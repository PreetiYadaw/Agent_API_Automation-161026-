"""
api/utils/two_section_utils.py

Reads and checks the TWO-SECTION input file used by QA Pariksha API test
generation, and applies one change to a copy of the payload.

    {
      "api_name": "...", "api_url": "...", "method": "POST",
      "payload":     { ...the real, valid request — exact nesting, arrays and types... },
      "validations": { "<key or path>": "<rule>", ... }
    }

payload      The baseline request exactly as the API receives it. Every positive
             and negative test case is a copy of it with ONE change applied.
validations  One entry per field to test.
    key    The field name when it is unique in the payload, otherwise the shortest
           path that makes it unique ("rpNexesusReq.pan", "BODY.pan").
           "[]" marks an array of objects: "related_party[].pan". A key may also be
           the full path; an exact full-path match always wins.
    value  "Mandatory. <rule>" / "Optional. <rule>"   — or an object
           {"required": true, "validation": "<rule>", "valid_values": [...]}
           valid_values = every value that is VALID for a positive test case
           (the payload's own value is always included, first).
Fields with no entry are sent unchanged and never tested (e.g. static HEADERS).

Path rules are identical to the Two-section Builder (streamlit_two_section.py), so
every file the builder produces is accepted as-is.

Array rows: a change to "rows[].pan" is applied to the FIRST row only — one bad row
is enough for the API to reject the request, and it keeps "one change per test case".
"""
import copy
import json
import re
from typing import Any, Dict, List, Optional, Tuple

ROW_MARK = "[]"

SOURCE_ID_FIELD = "SOURCE_ID"
RRN_FIELD = "REQUEST_REFERENCE_NUMBER"
DESTINATION_FIELD = "DESTINATION"
TXN_TYPE_FIELD = "TXN_TYPE"
TXN_SUB_TYPE_FIELD = "TXN_SUB_TYPE"
EIS_PAYLOAD_FIELD = "EIS_PAYLOAD"
ENVELOPE_FIELDS = [SOURCE_ID_FIELD, DESTINATION_FIELD, TXN_TYPE_FIELD, TXN_SUB_TYPE_FIELD]

# Nothing is ever added to the payload: Test Data holds only the fields of the
# input file, and only fields with a "validations" entry are tested. The single
# exception is the EIS Channel / EIS Microservices envelope — DESTINATION, TXN_TYPE
# and TXN_SUB_TYPE get a "Mandatory." rule (field-missing case only) when the file
# gives none (see prepare_two_section).
ENVELOPE_DEFAULT_RULE_FIELDS = [DESTINATION_FIELD, TXN_TYPE_FIELD, TXN_SUB_TYPE_FIELD]


class TwoSectionError(ValueError):
    """The input file is not a valid two-section file. Message lists every problem."""

    def __init__(self, problems: List[str]):
        self.problems = problems
        super().__init__(" | ".join(problems))


# ============================================================================
# Paths
# ============================================================================

def path_text(segs: List[str]) -> str:
    return ".".join(segs)


def payload_paths(node: Any, segs: Optional[List[str]] = None) -> List[Tuple[List[str], str]]:
    """Every addressable field of a payload: [(segments, kind)], containers included.
    kind: "object" | "array" | "leaf". Rows of an array of objects use "name[]"."""
    segs = segs or []
    out: List[Tuple[List[str], str]] = []
    if isinstance(node, dict):
        for k, v in node.items():
            p = segs + [str(k)]
            if isinstance(v, dict):
                out.append((p, "object"))
                out += payload_paths(v, p)
            elif isinstance(v, list) and v and all(isinstance(i, dict) for i in v):
                out.append((p, "array"))
                row = p[:-1] + [p[-1] + ROW_MARK]
                seen: Dict[str, Tuple[List[str], str]] = {}
                for item in v:                              # union of keys over all rows
                    for sp, kind in payload_paths(item, row):
                        seen.setdefault(path_text(sp), (sp, kind))
                out += list(seen.values())
            else:
                out.append((p, "array" if isinstance(v, list) else "leaf"))
    return out


def _is_suffix(key_segs: List[str], segs: List[str]) -> bool:
    return len(key_segs) <= len(segs) and segs[len(segs) - len(key_segs):] == key_segs


def resolve_key(key: str, all_paths: List[List[str]]) -> List[List[str]]:
    """Payload paths a validations key points to. An exact full-path match wins;
    otherwise every path ending with the key's segments (a valid key matches one)."""
    ks = [s for s in str(key).strip().split(".") if s]
    if not ks:
        return []
    exact = [p for p in all_paths if p == ks]
    if exact:
        return exact
    return [p for p in all_paths if _is_suffix(ks, p)]


def _step(node: Any, seg: str) -> Any:
    """One step down a path. "name[]" steps into the FIRST row of that array."""
    is_row = seg.endswith(ROW_MARK)
    k = seg[: -len(ROW_MARK)] if is_row else seg
    if not isinstance(node, dict) or k not in node:
        raise KeyError(seg)
    node = node[k]
    if is_row:
        if not isinstance(node, list) or not node:
            raise KeyError(seg)
        node = node[0]
    return node


def get_at(payload: Any, segs: List[str]) -> Any:
    node = payload
    for s in segs:
        node = _step(node, s)
    return node


def set_at(payload: Any, segs: List[str], value: Any) -> None:
    parent = get_at(payload, segs[:-1]) if len(segs) > 1 else payload
    parent[segs[-1]] = value


def remove_at(payload: Any, segs: List[str]) -> None:
    parent = get_at(payload, segs[:-1]) if len(segs) > 1 else payload
    parent.pop(segs[-1], None)


def apply_change(payload: Dict[str, Any], segs: Optional[List[str]], action: str, value: Any = None) -> Dict[str, Any]:
    """Deep copy of the payload with ONE change: action "baseline" | "set" | "remove"."""
    td = copy.deepcopy(payload)
    if action == "set":
        set_at(td, segs, copy.deepcopy(value))
    elif action == "remove":
        remove_at(td, segs)
    return td


def same_value(a: Any, b: Any) -> bool:
    """Type-aware equality ("10" != 10, True != 1)."""
    try:
        return json.dumps(a, sort_keys=True, ensure_ascii=False) == json.dumps(b, sort_keys=True, ensure_ascii=False)
    except Exception:
        return a == b


# ============================================================================
# Rules
# ============================================================================

_RULE_RE = re.compile(r"^\s*(mandatory|optional)\b[\s.:,;\-–]*(.*)$", re.IGNORECASE | re.DOTALL)


def parse_rule(key: str, raw: Any) -> Tuple[Optional[Dict[str, Any]], Optional[str]]:
    """Returns ({required, validation, valid_values}, None) or (None, problem)."""
    if isinstance(raw, str):
        m = _RULE_RE.match(raw)
        if not m:
            return None, (f'validations["{key}"]: the rule must start with "Mandatory." or '
                          f'"Optional." — got "{raw[:60]}".')
        return {"required": m.group(1).lower() == "mandatory",
                "validation": m.group(2).strip(), "valid_values": None}, None
    if isinstance(raw, dict):
        req = raw.get("required", True)
        if not isinstance(req, bool):
            return None, f'validations["{key}"].required must be true or false.'
        vv = raw.get("valid_values")
        if vv is not None and not isinstance(vv, list):
            return None, f'validations["{key}"].valid_values must be a list.'
        return {"required": req, "validation": str(raw.get("validation") or "").strip(),
                "valid_values": vv}, None
    return None, f'validations["{key}"] must be a text rule or an object.'


def _find_old_format(node: Any, segs: Optional[List[str]] = None) -> Optional[str]:
    """Path of the first {value, required/validation} object left inside the payload."""
    segs = segs or []
    if isinstance(node, dict):
        if "value" in node and ({"required", "validation"} & set(node.keys())) \
                and set(node.keys()) <= {"value", "required", "validation", "valid_values"}:
            return path_text(segs) or "payload"
        for k, v in node.items():
            hit = _find_old_format(v, segs + [str(k)])
            if hit:
                return hit
    elif isinstance(node, list):
        for i, v in enumerate(node):
            hit = _find_old_format(v, segs + [f"[{i}]"])
            if hit:
                return hit
    return None


def _blank(v: Any) -> bool:
    return v is None or (isinstance(v, str) and not v.strip())


# ============================================================================
# Prepare — check the file and list the fields to test
# ============================================================================

def prepare_two_section(
    payload: Any,
    validations: Any,
    api_type: str,
    wrapped: bool,
) -> Dict[str, Any]:
    """
    Checks the two-section file for the selected API type and returns:
      {
        "payload":   the baseline request, exactly as given in the file,
        "fields":    [{field, segs, path, baseline, required, validation, valid_values}],
        "source_id": baseline SOURCE_ID (upper-cased, 2 chars),
        "rrn_in_payload": True when the baseline carries REQUEST_REFERENCE_NUMBER at top level,
      }
    Raises TwoSectionError listing every problem found.
    """
    problems: List[str] = []

    if not isinstance(payload, dict) or not payload:
        raise TwoSectionError(['"payload" must be a non-empty JSON object — the real request.'])
    if not isinstance(validations, dict) or not validations:
        raise TwoSectionError(['"validations" must be a non-empty object — one entry per field to test.'])

    old = _find_old_format(payload)
    if old:
        raise TwoSectionError([
            f'"payload" still contains a {{value, required, validation}} object at "{old}". '
            "This is the old input format — convert the file with the Two-section Builder "
            "(Convert mode) and upload the result."
        ])

    payload = copy.deepcopy(payload)
    validations = dict(validations)

    # ── API-type structure ────────────────────────────────────────────────────
    if wrapped:
        for f in ENVELOPE_FIELDS:
            if f not in payload:
                problems.append(f'"{f}" is missing from the top level of "payload" (mandatory for {api_type}).')
            elif _blank(payload[f]):
                problems.append(f'"{f}" must have a value (mandatory for {api_type}).')
        eis = payload.get(EIS_PAYLOAD_FIELD)
        if EIS_PAYLOAD_FIELD not in payload:
            problems.append(f'"{EIS_PAYLOAD_FIELD}" is missing from the top level of "payload" (mandatory for {api_type}).')
        elif not isinstance(eis, dict) or not eis:
            problems.append(f'"{EIS_PAYLOAD_FIELD}" must be a non-empty object.')
    else:
        if SOURCE_ID_FIELD not in payload or _blank(payload.get(SOURCE_ID_FIELD)):
            problems.append(f'"{SOURCE_ID_FIELD}" is mandatory at the top level of "payload" for {api_type}.')

    sid = payload.get(SOURCE_ID_FIELD)
    source_id = str(sid).strip().upper() if not _blank(sid) else ""
    if source_id and len(source_id) != 2:
        problems.append(
            f'"{SOURCE_ID_FIELD}" in "payload" must be exactly 2 characters (it is the RRN channel '
            f'identifier) — got "{sid}". Put invalid SOURCE_ID values in test cases, not in the baseline.'
        )
    if problems:
        raise TwoSectionError(problems)

    # ── Default rules: EIS Channel envelope only ──────────────────────────────
    all_paths = [p for p, _ in payload_paths(payload)]

    def _has_rule_for(top_field: str) -> bool:
        return any(resolve_key(k, all_paths) == [[top_field]] for k in validations)

    if wrapped:
        defaults = {f: "Mandatory." for f in ENVELOPE_DEFAULT_RULE_FIELDS if not _has_rule_for(f)}
        validations = {**defaults, **validations}           # envelope fields first

    # ── Resolve every key ─────────────────────────────────────────────────────
    fields: List[Dict[str, Any]] = []
    seen_paths: Dict[str, str] = {}
    for key, raw in validations.items():
        hits = resolve_key(key, all_paths)
        if not hits:
            problems.append(
                f'validations key "{key}" does not match any field in "payload" '
                "(check spelling/case; arrays need at least one row)."
            )
            continue
        if len(hits) > 1:
            cands = ", ".join(f'"{path_text(h)}"' for h in hits[:5])
            problems.append(f'validations key "{key}" matches {len(hits)} fields ({cands}) — use a longer path.')
            continue
        segs = hits[0]
        ptxt = path_text(segs)
        if ptxt in seen_paths:
            problems.append(f'validations keys "{seen_paths[ptxt]}" and "{key}" point to the same field "{ptxt}".')
            continue
        rule, err = parse_rule(key, raw)
        if err:
            problems.append(err)
            continue
        seen_paths[ptxt] = key

        # Wrapped envelope fields are structurally mandatory whatever the file says.
        if wrapped and len(segs) == 1 and segs[0] in ENVELOPE_FIELDS + [EIS_PAYLOAD_FIELD]:
            rule["required"] = True

        baseline = get_at(payload, segs)
        valid_values = [baseline]
        for v in rule["valid_values"] or []:
            if not any(same_value(v, x) for x in valid_values):
                valid_values.append(v)

        fields.append({
            "field": str(key).strip(),
            "segs": segs,
            "path": ptxt,
            "baseline": baseline,
            "required": rule["required"],
            "validation": rule["validation"],
            "valid_values": valid_values,
        })

    if problems:
        raise TwoSectionError(problems)

    return {
        "payload": payload,
        "fields": fields,
        "source_id": source_id,
        "rrn_in_payload": RRN_FIELD in payload,
    }
