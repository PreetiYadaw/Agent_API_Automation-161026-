"""
api/utils/executors.py

Bounded thread pools used to keep blocking work OFF the asyncio event loop.
The app runs a single Uvicorn worker (ChromaDB PersistentClient cannot be
forked — see main.py), so any blocking call made directly in an async
endpoint would freeze the app for every user. Endpoints hand that work to
one of these pools via loop.run_in_executor(POOL, fn, *args).

  AUTH_POOL      — argon2 password hashing / verification (CPU + memory heavy)
  LLM_WORK_POOL  — page extraction, RAG retrieval, Azure OpenAI generation,
                   pass/fail evaluation (long-running, I/O + CPU)
  EIS_CALL_POOL  — outbound encrypted EIS API calls when running test cases

Sizes can be tuned from .env without code changes.

NOTE: reconstructed from how the pools are used in generate_tests_api.py and
user_management_api.py. If you still have your original executors.py, use
that one instead — the names above are what the rest of the code needs.
"""
import os
from concurrent.futures import ThreadPoolExecutor


def _size(env_name: str, default: int) -> int:
    try:
        return max(1, int(os.getenv(env_name, default)))
    except ValueError:
        return default


AUTH_POOL = ThreadPoolExecutor(
    max_workers=_size("AUTH_POOL_SIZE", 4),
    thread_name_prefix="auth",
)

LLM_WORK_POOL = ThreadPoolExecutor(
    max_workers=_size("LLM_WORK_POOL_SIZE", 8),
    thread_name_prefix="llm",
)

EIS_CALL_POOL = ThreadPoolExecutor(
    max_workers=_size("EIS_CALL_POOL_SIZE", 16),
    thread_name_prefix="eis",
)
