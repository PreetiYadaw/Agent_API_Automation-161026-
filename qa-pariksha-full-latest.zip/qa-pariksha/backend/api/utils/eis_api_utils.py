"""
api/utils/eis_api_utils.py

Executes generated API test case payloads against the real target API using the
EIS AES-GCM + RSA encrypted flow (adapted from EIS_API.py).
call_eis_api() always returns a dict (never raises) with three keys:
  - "encrypted_payload":  the exact {DIGI_SIGN, REQUEST, REQUEST_REFERENCE_NUMBER}
                          dict that was POSTed to the API (still AES/RSA encrypted).
  - "encrypted_response": the raw JSON the API returned, BEFORE decryption
                          (still encrypted) — or None if no response was ever
                          received (key-load failure, timeout, network error).
  - "actual_response":    the decrypted, pretty-printed response text — same
                          string contract as before (drops straight into the
                          "Actual_Response" column).

EIS request-level test cases (api/utils/eis_request_tests.py): prepare_eis_request()
and call_eis_api() take an optional request_change code and break the FINAL request
on purpose (signature, REQUEST, AccessToken, body, Content-Type, HTTP method, sending
the same request twice). For those cases an HTTP 4xx/5xx from the gateway IS the
expected rejection, so it is reported as "GATEWAY ERROR [HTTP <status>]: …".
"""
import base64
import json
import os
import requests
from Crypto.Cipher import AES, PKCS1_OAEP
from Crypto.PublicKey import RSA
from Crypto.Hash import SHA256
from Crypto.Signature import pkcs1_15

_PRIVATE_KEY_PATH    = os.getenv("EIS_PRIVATE_KEY_PATH", "./files/private_key.cer")
_EIS_PUBLIC_KEY_PATH = os.getenv("EIS_PUBLIC_KEY_PATH", "./files/ENC_EIS_UAT.cer")
_EIS_SECRET_KEY      = os.getenv("EIS_SECRET_KEY", "11111111111111111111111111111111").encode("utf-8")

_private_key = None
_eis_public_key = None


def _load_keys():
    global _private_key, _eis_public_key
    if _private_key is None:
        with open(_PRIVATE_KEY_PATH, "r") as f:
            _private_key = RSA.import_key(f.read())
    if _eis_public_key is None:
        with open(_EIS_PUBLIC_KEY_PATH, "r") as f:
            _eis_public_key = RSA.import_key(f.read())
    return _private_key, _eis_public_key


def _encrypt_aes_gcm_base64(plaintext: str, key: bytes) -> str:
    nonce = key[:12]
    cipher = AES.new(key, AES.MODE_GCM, nonce=nonce)
    ciphertext, tag = cipher.encrypt_and_digest(plaintext.encode("utf-8"))
    return base64.b64encode(ciphertext + tag).decode("utf-8")


def _decrypt_aes_gcm_base64(encrypted_data_b64: str, key: bytes) -> str:
    decoded = base64.b64decode(encrypted_data_b64)
    tag_len = 16
    nonce = key[:12]
    ciphertext, tag = decoded[:-tag_len], decoded[-tag_len:]
    cipher = AES.new(key, AES.MODE_GCM, nonce=nonce)
    return cipher.decrypt_and_verify(ciphertext, tag).decode("utf-8")


def _get_digital_signature(payload: str, private_key) -> str:
    h = SHA256.new(payload.encode("utf-8"))
    signature = pkcs1_15.new(private_key).sign(h)
    return base64.b64encode(signature).decode("utf-8")


def _get_access_token(eis_public_key, secret_key: bytes) -> str:
    cipher_rsa = PKCS1_OAEP.new(eis_public_key)
    encrypted = cipher_rsa.encrypt(secret_key)
    return base64.b64encode(encrypted).decode("utf-8")


# ============================================================================
# Building blocks — shared by call_eis_api() (server-side run) and by the
# desktop-agent endpoints in agent_api.py (/agent/eis/prepare-batch and
# /agent/eis/decode-batch), so both paths always produce identical output.
# ============================================================================

def prepare_eis_request(payload_json: str, rrn: str, request_change: str | None = None) -> dict:
    """Encrypts + signs one payload. Never raises. Returns:
      {"error": None, "method": "POST", "send_count": 1,
       "headers": {...}, "body": {DIGI_SIGN, REQUEST, REQUEST_REFERENCE_NUMBER}}
    or, on failure, {"error": "ERROR: ...", "headers": None, "body": None}.
    request_change: an EIS request-level test case code — breaks the request on purpose."""
    try:
        private_key, eis_public_key = _load_keys()
    except Exception as e:
        return {"error": f"ERROR: Could not load EIS keys — {e}", "headers": None, "body": None}

    secret_key = _EIS_SECRET_KEY
    try:
        encrypted_payload_b64 = _encrypt_aes_gcm_base64(payload_json, secret_key)
        digital_signature     = _get_digital_signature(payload_json, private_key)
        access_token          = _get_access_token(eis_public_key, secret_key)
    except Exception as e:
        return {"error": f"ERROR: Encryption/signing failed — {e}", "headers": None, "body": None}

    prepared = {
        "error": None,
        "method": "POST",
        "send_count": 1,
        "headers": {"Content-Type": "application/json", "AccessToken": access_token},
        "body": {
            "DIGI_SIGN": digital_signature,
            "REQUEST": encrypted_payload_b64,
            "REQUEST_REFERENCE_NUMBER": rrn,
        },
    }
    if request_change:
        try:
            _apply_request_change(prepared, request_change, payload_json, private_key, eis_public_key)
        except Exception as e:
            return {"error": f"ERROR: Could not apply request change {request_change} — {e}", "headers": None, "body": None}
    return prepared


def _apply_request_change(prepared: dict, code: str, payload_json: str, private_key, eis_public_key) -> None:
    """Breaks the already-built request for one EIS request-level test case.
    (RRN changes are made earlier — api_testcase_utils.apply_request_change_to_payload.)"""
    from api.utils.eis_request_tests import EXTRA_FIELD_NAME, EXTRA_FIELD_VALUE, OTHER_AES_KEY
    body, headers = prepared["body"], prepared["headers"]
    if code == "DIGI_SIGN_MISSING":
        body.pop("DIGI_SIGN", None)
    elif code == "DIGI_SIGN_EMPTY":
        body["DIGI_SIGN"] = ""
    elif code == "DIGI_SIGN_WRONG_PAYLOAD":
        body["DIGI_SIGN"] = _get_digital_signature(payload_json + " ", private_key)   # valid signature, other content
    elif code == "DIGI_SIGN_NOT_BASE64":
        body["DIGI_SIGN"] = "###not-base64-signature###"
    elif code == "REQUEST_MISSING":
        body.pop("REQUEST", None)
    elif code == "REQUEST_EMPTY":
        body["REQUEST"] = ""
    elif code == "REQUEST_BYTE_CHANGED":
        raw = bytearray(base64.b64decode(body["REQUEST"]))
        raw[0] ^= 0x01                                                             # GCM tag check must fail
        body["REQUEST"] = base64.b64encode(bytes(raw)).decode("utf-8")
    elif code == "REQUEST_WRONG_KEY":
        body["REQUEST"] = _encrypt_aes_gcm_base64(payload_json, OTHER_AES_KEY)
    elif code == "REQUEST_PLAIN_JSON":
        body["REQUEST"] = payload_json
    elif code == "RRN_MISSING":
        body.pop("REQUEST_REFERENCE_NUMBER", None)
    elif code == "RRN_DUPLICATE":
        prepared["send_count"] = 2                                                 # the 2nd call is the test
    elif code == "BODY_EXTRA_FIELD":
        body[EXTRA_FIELD_NAME] = EXTRA_FIELD_VALUE
    elif code == "BODY_EMPTY":
        prepared["body"] = {}
    elif code == "ACCESS_TOKEN_MISSING":
        headers.pop("AccessToken", None)
    elif code == "ACCESS_TOKEN_INVALID":
        headers["AccessToken"] = "###invalid-access-token###"
    elif code == "ACCESS_TOKEN_WRONG_KEY":
        headers["AccessToken"] = _get_access_token(eis_public_key, OTHER_AES_KEY)
    elif code == "CONTENT_TYPE_TEXT":
        headers["Content-Type"] = "text/plain"
    elif code == "METHOD_GET":
        prepared["method"] = "GET"
    # RRN_WRONG_LENGTH / RRN_INNER_MISMATCH / RRN_SOURCE_ID_MISMATCH(_INNER) / RRN_NOT_SBI(_INNER):
    # already applied to the payload and RRN before encryption.


def decode_eis_response(req_response) -> str:
    """Turns the raw JSON the EIS gateway returned into the "Actual_Response" text:
    plain gateway error, decrypt failure, or "[Signature: valid|invalid]\n<pretty JSON>".
    Never raises."""
    if not isinstance(req_response, dict):
        return f"GATEWAY ERROR: Unexpected response shape — {json.dumps(req_response, ensure_ascii=False)}"

    # ── Gateway-level rejection: SOURCE_ID missing/invalid, malformed request,
    #    etc. — the API returns a PLAIN, UNENCRYPTED error object with no
    #    "RESPONSE" / "DIGI_SIGN" keys at all. Surface it directly instead of
    #    trying (and failing) to decrypt something that isn't there.
    if "RESPONSE" not in req_response:
        error_code = req_response.get("ERROR_CODE", "")
        error_desc = req_response.get("ERROR_DESCRIPTION", "")
        if error_desc or error_code:
            return f"GATEWAY ERROR [{error_code}]: {error_desc}"
        # Unrecognized shape — fall back to showing the raw payload rather than
        # a confusing decrypt-failure message.
        return f"GATEWAY ERROR: Unexpected response shape — {json.dumps(req_response, ensure_ascii=False)}"

    try:
        _, eis_public_key = _load_keys()
    except Exception as e:
        return f"ERROR: Could not load EIS keys — {e}"

    try:
        decrypted_res_data = _decrypt_aes_gcm_base64(req_response["RESPONSE"], _EIS_SECRET_KEY)
    except Exception as e:
        return f"ERROR: Could not decrypt response — {e}"

    try:
        decoded_sign = base64.b64decode(req_response["DIGI_SIGN"])
        h = SHA256.new(decrypted_res_data.encode("utf-8"))
        pkcs1_15.new(eis_public_key).verify(h, decoded_sign)
        sig_status = "valid"
    except Exception:
        sig_status = "invalid"

    try:
        pretty = json.dumps(json.loads(decrypted_res_data), indent=2, ensure_ascii=False)
    except Exception:
        pretty = decrypted_res_data

    return f"[Signature: {sig_status}]\n{pretty}"


def call_eis_api(payload_json: str, rrn: str, url: str, timeout: int = 60, request_change: str | None = None) -> dict:
    """AES-GCM + RSA encrypted call. Returns a dict — see module docstring for the
    three keys. "actual_response" carries decrypted, pretty-printed response text,
    a plain-text gateway error (when the API short-circuits before encrypting a
    response — e.g. missing/invalid SOURCE_ID), or a readable 'ERROR: ...' string
    for genuine failures — never raises.
    (Unchanged behaviour — now built from prepare_eis_request + decode_eis_response.)"""
    prepared = prepare_eis_request(payload_json, rrn, request_change)
    if prepared["error"]:
        return {"encrypted_payload": None, "encrypted_response": None, "actual_response": prepared["error"]}

    # Captured regardless of what happens next — this IS what got sent on the wire.
    encrypted_payload = prepared["body"]

    try:
        method = prepared.get("method", "POST")
        body_text = None if method == "GET" else json.dumps(prepared["body"])
        response = None
        for _ in range(prepared.get("send_count", 1)):                # RRN_DUPLICATE sends twice; the last answer counts
            response = requests.request(method, url, headers=prepared["headers"], data=body_text,
                                        verify=False, timeout=timeout)
        if request_change and response.status_code >= 400:
            # For a request-level test case an HTTP rejection IS the expected outcome.
            return {
                "encrypted_payload": encrypted_payload,
                "encrypted_response": None,
                "actual_response": f"GATEWAY ERROR [HTTP {response.status_code}]: {response.reason or ''} {response.text[:300]}".strip(),
            }
        response.raise_for_status()
    except requests.exceptions.Timeout:
        return {
            "encrypted_payload": encrypted_payload,
            "encrypted_response": None,
            "actual_response": "ERROR: Request timed out",
        }
    except requests.exceptions.RequestException as e:
        return {
            "encrypted_payload": encrypted_payload,
            "encrypted_response": None,
            "actual_response": f"ERROR: {e}",
        }

    try:
        req_response = response.json()
    except Exception as e:
        if request_change:
            return {
                "encrypted_payload": encrypted_payload,
                "encrypted_response": None,
                "actual_response": f"GATEWAY ERROR: Non-JSON response — {response.text[:300]}",
            }
        return {
            "encrypted_payload": encrypted_payload,
            "encrypted_response": None,
            "actual_response": f"ERROR: Could not parse response as JSON — {e}",
        }

    # The raw response as received on the wire, BEFORE decryption — this is what
    # the "Encrypted_Response" column shows, whatever shape it turns out to be.
    return {
        "encrypted_payload": encrypted_payload,
        "encrypted_response": req_response,
        "actual_response": decode_eis_response(req_response),
    }
