# QA Pariksha — two-section input for API test generation

## Update 7 — EIS request-level test cases (checkbox "Include EIS request-level test cases")
When the box is ticked (web Generate panel / Desktop Agent input panel), generation adds:

**A. Envelope cases.** The payload stays at its baseline; only the FINAL request sent to EIS is broken. All are Negative, and each carries a code in the new `EIS_Request_Change` column:

| Group | Codes |
|---|---|
| DIGI_SIGN | DIGI_SIGN_MISSING, DIGI_SIGN_EMPTY, DIGI_SIGN_WRONG_PAYLOAD, DIGI_SIGN_NOT_BASE64 |
| REQUEST | REQUEST_MISSING, REQUEST_EMPTY, REQUEST_BYTE_CHANGED, REQUEST_WRONG_KEY, REQUEST_PLAIN_JSON |
| RRN | RRN_MISSING, RRN_WRONG_LENGTH, RRN_INNER_MISMATCH*, RRN_DUPLICATE (sent twice; the 2nd call counts), RRN_SOURCE_ID_MISMATCH, RRN_SOURCE_ID_MISMATCH_INNER*, RRN_NOT_SBI, RRN_NOT_SBI_INNER* |
| Body | BODY_EXTRA_FIELD, BODY_EMPTY |
| Headers / method | ACCESS_TOKEN_MISSING, ACCESS_TOKEN_INVALID, ACCESS_TOKEN_WRONG_KEY, CONTENT_TYPE_TEXT, METHOD_GET |

\* Only when the payload itself carries a REQUEST_REFERENCE_NUMBER: always for EIS Channel, and for flat EIS only if the file has one. So flat EIS gets 21 cases and EIS Channel gets 24.

**B. Unexpected-field cases.** `QA_EXTRA_FIELD: "unexpected"` is added at every object level of the payload: the top level, each nested object, the first row of each array of objects, and for EIS Channel also EIS_PAYLOAD / HEADERS / BODY. Expected result: rejection with **"UNEXPECTED FIELD QA_EXTRA_FIELD"**. These are ordinary payload changes, visible and editable in Test Data.

- **Numbering:** IDs continue the normal TC_API_ numbering after the field cases.
- **Run-time changes:** changes are applied when the case runs, in both the server Run and the Agent's prepare step. RRN changes are applied after the fresh-RRN step, so they are never undone.
- **HTTP rejections:** for these cases an HTTP 4xx/5xx is the expected outcome and shows as `GATEWAY ERROR [HTTP <status>]: …` rather than `ERROR:`.
- **Evaluator, new rule 6:** a Negative case whose description says `displays error "<text>"` passes only if the response contains that text.

| Where | Change |
|---|---|
| `api/utils/eis_request_tests.py` | **NEW**: the catalogue (`ENVELOPE_CASES`), `extra_field_levels`, and `build_request_level_specs`. |
| `api/utils/api_testcase_utils.py` | `apply_request_change_to_payload` (~line 177) for RRN changes. `generate_api_testcases_two_section(..., include_request_tests)` (~line 664, section 2b ~line 719) adds the cases and the column. Evaluator rule 6 (~line 829). |
| `api/utils/eis_api_utils.py` | Now the refactored version, as installed with the Desktop Agent. `prepare_eis_request(..., request_change)` + `_apply_request_change` (~line 122). `call_eis_api(..., request_change)` honours the method, sends twice when needed, and reports HTTP rejections as GATEWAY ERROR. |
| `api/endpoints/v1/generate_tests_api.py` | Passes `include_request_tests`. Run applies the change (~line 1260). |
| `api/endpoints/v1/agent_api.py` | Prepare applies the change and returns `method`, `send_count` and `request_change`. |
| `api/model.py` | `APITestCaseGenerateRequest.include_request_tests: bool = False`. |
| web `src/App.tsx` | Checkbox on the Generate panel. `EIS_Request_Change` column in the table, in both Excel downloads and on re-upload (hidden when unused). |
| Agent `src/App.tsx`, `SpecPanel.tsx`, `ResultsPanel.tsx`, `excel.ts`, `agent.d.ts`, `electron/main.js`, `preload.js`, `lib/qaClient.js`, `lib/runPipeline.js` | Checkbox; flag passed to generate; column; `runPipeline` honours `method` / `send_count` and reports HTTP rejections of these cases as GATEWAY ERROR. |

Diffs of just this update: `diffs/update_request_level_tests/`.

---


## Update 6 — run and evaluate test cases in batches (web app + Desktop Agent)
- **A checkbox on every test case row**, plus a header checkbox that selects or clears the current page. Nothing is selected by default.
- **Quick select:** All, Not run yet, Failed, Errors (response starts with ERROR / GATEWAY ERROR), Positive, Negative, and None.
- **Run Selected (n)** sends only the ticked rows to EIS. **Evaluate Selected (n)** evaluates the ticked rows that already have a response. Results are kept **per test case** and merged batch by batch. Rows not in the batch keep what they had.
- When a batch finishes, its rows are **removed from the selection but stay on screen**. A re-run row loses its old Pass/Fail, because it belonged to the previous response.
- **Run All / Run Automation** still work as before, on every row (or every row with a response).
- Counters show Run x/total, Evaluated y, Pass and Fail. Downloads always contain every row.
- Uploading an edited file, or discarding it, clears results and selection.
- No backend change.

| Where | Change |
|---|---|
| web `src/App.tsx` | `ApiResultsView`: `runById` / `evalById` / `selected` state replace `ranTestcases` / `evaluatedTestcases` / `evalSummary`. New `runBatch`, `evaluateBatch`, `QUICK_SELECT`. A selection toolbar sits above the tabs, with a checkbox column in the table (`SELECT_COL_WIDTH`). |
| Agent `src/App.tsx` | The same per-test-case state; `runBatch`, `evaluateBatch`, `runSelected`, `evaluateSelected`. |
| Agent `src/components/ResultsPanel.tsx` | Selection toolbar, checkbox column, Run x/total and Evaluated chips. New props: `selected`, `onSelectionChange`, `onRunSelected`, `onEvaluateSelected`, `runCount`, `evalCount`. |

Diffs of just this update: `diffs/update_batch_selection/`.

---


## Update 5 — prompt: categories B–J; D = fixed length, E = range with min/max positives
See `diffs/update_prompt_api_testcase_utils.py.diff` (api_testcase_utils.py).

---

## Update 4 — "Use existing test cases": start from saved test cases
In API mode the sidebar (web app) and the input panel (Desktop Agent) now offer a choice:
**Generate from JSON spec** (as before) or **Use / Open existing test cases**. Choose an
editable Excel, a results Excel or the JSON download — from the web app or the agent — and
go straight to Run → Evaluate → download.

- **Old results are dropped on load:** `Encrypted_*`, `Actual_Response`, `Pass_Fail` and `Remarks` are removed. Test Data must be valid JSON, and IDs must be unique.
- **Downloads record the API's details:** every Excel download gets a **Details** sheet with API name, URL, method, API type, generated reference number and baseline SOURCE_ID. The JSON download already has them.
- **Older files without Details** are inferred: the baseline SOURCE_ID comes from the "correct payload" row (otherwise the most common SOURCE_ID), and the API type from whether `EIS_PAYLOAD` is present. A warning is shown if no baseline SOURCE_ID can be found.
- **A fresh RRN on every run:** a well-formed RRN in Test Data (`SBI` + 2 chars + 20 digits) is replaced with a new one, built from the **baseline SOURCE_ID**, inside the payload and in the envelope. A malformed RRN (an RRN negative case) is sent as is. The returned Test Data shows what was actually sent.

| Where | Change |
|---|---|
| `api/utils/api_testcase_utils.py` | New `is_well_formed_rrn`, `_channel`. `resolve_run_rrn(payload, generated_reference_number, baseline_source_id)` (~line 130) now returns `(rrn, error, payload_to_send)` and refreshes well-formed RRNs. |
| `api/endpoints/v1/generate_tests_api.py` | Generate response gets `baseline_source_id` (~line 1192). `_run_one_api_testcase` (~line 1219) takes `baseline_source_id` and returns the Test Data actually sent; Run passes `request.baseline_source_id`. |
| `api/model.py` | `RunApiTestcasesRequest.baseline_source_id: Optional[str]` (optional, so older clients keep working). |
| `api/endpoints/v1/agent_api.py` | `PrepareBatchRequest.baseline_source_id`; `_prepare_one` uses the new `resolve_run_rrn` and returns `test_data` (what is sent). |
| web `src/App.tsx` | Saved-file helpers before `ApiResultsView` (~line 890): `appendDetailsSheet`, `readDetailsSheet`, `normaliseSavedRows`, `parseSavedTestcaseFile`, `inferBaselineSourceId`, `buildResultFromSavedFile`. `ApiJsonUpload` (~line 470) gets the two-way choice and the "Open Existing Test Cases" panel (`onLoadExisting`). `ApiResultsView` "Upload Edited Testcases" uses the same reader (now also accepts .json). It shows "Loaded from file" and the baseline SOURCE_ID, and both Excel downloads add the Details sheet. Run sends `baseline_source_id`. The app remounts the results view for each new result (`apiResultKey`). |
| Agent `src/excel.ts` | Details sheet in both workbooks; `parseSavedFile`, `inferBaselineSourceId`, `buildResultFromSavedFile`. `parseEditedWorkbook` now uses the same reader. |
| Agent `src/components/SpecPanel.tsx` | Two-way choice; "Open existing test cases" drop zone (`onOpenExisting`). |
| Agent `src/App.tsx` | `openExisting`; Run passes `baseline_source_id`; downloads pass the result for the Details sheet. |
| Agent `src/components/ResultsPanel.tsx`, `src/agent.d.ts` | "Loaded from file" and baseline SOURCE_ID shown; types. |
| Agent `electron/main.js`, `preload.js`, `lib/runPipeline.js`, `lib/qaClient.js` | `baselineSourceId` passed through to `/agent/eis/prepare-batch`; rows keep the Test Data actually sent. `generate` no longer sends the unused `mandatory_fields_to_include`. |

Note: a test case that deliberately reuses an already-used *well-formed* RRN (a "duplicate RRN"
test) also gets a fresh RRN now. Make such a case's RRN malformed if you need it sent unchanged.

Diffs of just this update: `diffs/update_open_existing/`.

---


## Update 3 — Test Data holds only the fields in the input file
- **Flat EIS:** REQUEST_AUTH_ID / REQUEST_TELLER_ID / BRANCH_CODE are no longer added to the payload, and get no test cases.
- **SOURCE_ID default rule removed (both API types):** SOURCE_ID is tested only if the file has a `validations` entry for it. It is still required at the top level, must be 2 characters, and is still used for the RRN.
- **Kept for EIS Channel / EIS Microservices:** DESTINATION / TXN_TYPE / TXN_SUB_TYPE get a "Mandatory." rule (missing-field case only) when the file has none.
- `mandatory_fields_to_include` in the request is still accepted but ignored, so older clients don't break.

| File | Change |
|---|---|
| `api/utils/two_section_utils.py` | Removed `MANDATORY_DEFAULT_FIELDS`, `DEFAULT_SOURCE_ID_RULE`, the injection step and the `mandatory_fields_to_include` parameter of `prepare_two_section`. New `ENVELOPE_DEFAULT_RULE_FIELDS`; the "Default rules" block (~line 275) now applies to EIS Channel only. |
| `api/utils/api_testcase_utils.py` | Removed the `MANDATORY_DEFAULT_FIELDS` import. |
| `api/endpoints/v1/generate_tests_api.py` | Endpoint description updated; `mandatory_fields_to_include` is no longer passed on. |
| `api/model.py` | Comment only: `mandatory_fields_to_include` is marked as no longer used. |
| web `src/App.tsx` | Removed `SHOW_MANDATORY_FIELD_CHECKBOXES`, `MANDATORY_FIELD_OPTIONS`, the `mandatoryFields` state and props, the hidden checkboxes, the "auto-filled" / "will NOT be added" messages and the now-unused `FormGroup` / `FormControlLabel` imports. The request no longer sends `mandatory_fields_to_include`. Generate-panel text updated. |

Diffs of just this update: `diffs/update_no_default_fields/`. Desktop Agent: no change.

---


## Update 2 — fix for "Expecting ',' delimiter … column 17" (500 on generate)
Cause: for "too long" cases the AI wrote code such as `"A".repeat(101)` instead of a
JSON value, so the whole answer for 30 fields failed to parse, 3 identical retries
failed the same way, and the run ended in a 500.

| # | Fix | Where |
|---|---|---|
| 1 | **JSON mode** — every AI call sends `response_format={"type": "json_object"}`, so the answer is always valid JSON. The answer is now `{"test_cases": [...]}`. If a deployment ever rejects the parameter, it is switched off once and generation continues. | `api_testcase_utils.py`: `_call_llm` (~line 295), `_json_mode_supported` (~line 220), prompt OUTPUT FORMAT, `_parse_llm_items` |
| 2 | **`repeat_to_length`** — the prompt forbids expressions and asks for long strings as `{"value": "A", "repeat_to_length": 101}`. Code expands the pattern to exactly that length; lengths over 100,000 are dropped. | prompt rule 3; `_expand_value` (~line 374), used in `_clean_llm_negatives` |
| 4 | **Smaller blast radius** — 10 fields per call (was 30). A batch whose answer is unusable (bad JSON, cut off, API error) is split in half straight away instead of retrying the same request. A single field gets 3 attempts; if they all fail, only that field loses its invalid-value cases and a **warning** is returned. Its code-made cases (baseline, valid values, missing) are kept. A 500 happens only if every field fails. | `LLM_FIELDS_PER_CALL` (~line 213), `_llm_negatives` (~line 318), `generate_api_testcases_two_section` now returns `(testcases, warnings)` |
| 5 | **Raw answer logged** — when an answer can't be used, its first 2,000 characters and `finish_reason` are printed to the server log. | `_llm_negatives` |
| — | Response gets `"warnings": [...]` (additive; nothing else changed). The web app and the Desktop Agent show them as a yellow box above the results. | `generate_tests_api.py` (`result_obj`), `App.tsx` (`ApiTestCaseResult.warnings`, results header), Agent `agent.d.ts` + `components/ResultsPanel.tsx` |

Files changed in this update: `api/utils/api_testcase_utils.py`, `api/endpoints/v1/generate_tests_api.py`,
web `src/App.tsx`, Agent `src/agent.d.ts` and `src/components/ResultsPanel.tsx`.
Line-by-line diffs of just this update are in `diffs/update_json_mode/`.

Tested with a mocked AI: your v2 file (JSON mode on every call, ≤10 fields per call, 101-character
strings expanded exactly); one field returning `"A".repeat(101)` → split, 3 retries for that field,
warning for it only, all other cases kept, raw answer in the log; every answer broken → clear 500;
deployment rejecting `response_format` → falls back and works; the full earlier suite still passes.

---


The input file is now `payload` (the real request) plus `validations` (field → rule)
for **EIS (flat)** and **EIS Channel / EIS Microservices**. The old
`{value, required, validation}` files are rejected with a message pointing to the
Two-section Builder. Run, Evaluate, Excel and the test case columns are unchanged.

## Files — copy each one to the same path in your project

| File in this zip | Where it goes | Status |
|---|---|---|
| `backend/api/utils/two_section_utils.py` | `api/utils/` | **NEW** |
| `backend/api/utils/api_testcase_utils.py` | `api/utils/` | replace |
| `backend/api/endpoints/v1/generate_tests_api.py` | `api/endpoints/v1/` | replace |
| `backend/api/model.py` | `api/` | replace (or patch — see below) |
| `backend/api/endpoints/v1/agent_api.py` | `api/endpoints/v1/` | replace — only if the Desktop Agent backend is installed |
| `backend/api/utils/eis_request_tests.py` | `api/utils/` | **NEW** (Update 7) |
| `backend/api/utils/eis_api_utils.py` | `api/utils/` | replace (Update 7) |
| `desktop-agent/src/agent.d.ts`, `desktop-agent/src/components/ResultsPanel.tsx` | agent `src/`, `src/components/` | replace (Update 2 — warnings; Update 4) |
| `desktop-agent/src/App.tsx`, `desktop-agent/src/excel.ts` | agent `src/` | replace (Update 4) |
| `desktop-agent/electron/main.js`, `preload.js`, `electron/lib/runPipeline.js`, `electron/lib/qaClient.js` | agent `electron/`, `electron/lib/` | replace (Update 4) |
| `frontend/src/App.tsx` | web app `src/` | replace |
| `desktop-agent/src/twoSection.ts` | agent `src/` | **NEW** |
| `desktop-agent/src/components/SpecPanel.tsx` | agent `src/components/` | replace |
| `desktop-agent/src/components/PayloadTree.tsx` | agent `src/components/` | replace |
| `samples/*.json` | — | new sample input files (flat EIS, EIS Channel flat, EIS Channel HEADERS/BODY) |
| `diffs/*.diff` | — | line-by-line diff of every changed file |

No new packages, no database change, no `.env` change.

## What changed, file by file

### `api/utils/two_section_utils.py` (NEW)
- `payload_paths`, `resolve_key`: key → field. Rules are the same as the Two-section Builder: a field name, or the shortest unique path; `name[]` means inside the rows of an array. An exact full path always wins.
- `get_at`, `set_at`, `remove_at`, `apply_change`: copy the payload and make ONE change. `name[]` changes the first row only.
- `parse_rule`: reads `"Mandatory. …"` / `"Optional. …"` or `{required, validation, valid_values}`.
- `prepare_two_section`: checks the whole file and lists every problem in one 422 message:
  - an old-format object is still left in the payload;
  - a key is unknown or ambiguous, or two keys point to the same field;
  - a rule is bad;
  - SOURCE_ID is missing or not 2 characters;
  - for EIS Channel, an envelope field or EIS_PAYLOAD is missing.

  It also adds defaults:
  - (Update 3) Nothing is added to the payload, and SOURCE_ID has no default rule.
  - EIS Channel: DESTINATION / TXN_TYPE / TXN_SUB_TYPE get "Mandatory." when the file has none. Envelope fields are always mandatory.

### `api/utils/api_testcase_utils.py`
- **Kept:** `make_rrn`, the RRN sequence logic, and the whole evaluation section (`EVALUATE_TESTCASE_SYSTEM_PROMPT`, `evaluate_api_testcases_via_llm`).
- **New `API_TESTCASE_SYSTEM_PROMPT`:** the AI returns only `[{field, value, description}]` invalid values.
- **New `generate_api_testcases_two_section`:**
  - Code makes the baseline case, one positive case per extra `valid_values` entry, and the field-missing case (Negative if Mandatory, Positive if Optional).
  - The AI makes the invalid-value cases.
  - Code builds every Test Data as the baseline plus one change.
  - The AI is called in batches of 30 fields (`LLM_FIELDS_PER_CALL`). An answer cut off by the token limit is split in half and asked again.
  - AI items are dropped when they name an unknown field, use a valid value, are duplicates, or have no value.
  - RRN: EIS Channel gets a fresh RRN per case placed before EIS_PAYLOAD. Flat EIS with an RRN in the payload gets a fresh one per case. The case testing the RRN itself keeps its value.
- **New `resolve_run_rrn`:** used by Run and the Agent. It uses the payload RRN if present; otherwise it builds a fresh RRN from the **baseline** SOURCE_ID (read from `generated_reference_number`).
- **Removed** (old format only): `apply_mandatory_fields`, `split_eis_payload_container`, `apply_wrapped_mandatory_fields`, `wrap_testcases_in_eis_container`, `build_eis_payload_baseline`, `_is_full_baseline`, `wrap_parent_field_testcases`, `_sanitize_positive_testcases`, `_assign_unique_rrns`, `generate_api_testcases_via_llm`, `generate_parent_field_testcases`, and `_field_values` / `_baseline_value`.

### `api/endpoints/v1/generate_tests_api.py`
- **Imports** (line ~1074): the new functions.
- **`generate_api_testcases_endpoint`** (line ~1090):
  - calls `prepare_two_section` (422 on problems);
  - creates `generated_reference_number` for flat EIS when the payload has no RRN;
  - makes one call to `generate_api_testcases_two_section`. The two batches for EIS Channel are now a single call.
  - `result_obj` is unchanged.
- **`_run_one_api_testcase`** (line ~1215):
  - the RRN comes from `resolve_run_rrn`. SOURCE_ID negative cases now reach EIS, and a missing or null SOURCE_ID no longer reuses one RRN.
  - Test Data sent as a JSON string is parsed before `dict()`.
- The Run and Evaluate endpoints themselves are unchanged.

### `api/model.py` (only the "API testcase generation models" section and one import)
- `from typing import …, Union`
- `APIFieldSpec` → **`APIValidationRule`** `{required, validation, valid_values}`
- `APITestCaseSpec.payload: Dict[str, Any]` and new **`validations: Dict[str, Union[str, APIValidationRule]]`**

This `model.py` was rebuilt from the copy you shared. If yours has changed since, apply just these lines from `diffs/model.py.diff`.

### `api/endpoints/v1/agent_api.py` (Desktop Agent backend)
- `_prepare_one` uses `resolve_run_rrn`, the same rule as the server Run. The import of `make_rrn` is replaced.

### `src/App.tsx` (web app)
- **Types:**
  - `ApiFieldSpec` is removed.
  - `ApiValidationRule` is new.
  - `ApiSpec` gets `validations`.
- **New helpers**, using the same rules as the backend:
  - `payloadPaths`, `resolveKey`, `getAtPath`, `setAtPath`, `coerceLikeOriginal`;
  - `findOldFormat`, `readValidations`, `specBlockingProblems`.
- **Samples** rewritten in two-section format (SOURCE_ID `"MB01"` → `"MB"`).
- **`ApiJsonUpload`:**
  - the upload check now requires `payload` + `validations` and rejects the old format;
  - the preview lists each field under test with its path, mandatory/optional, valid values and rule;
  - baseline values are editable (number and boolean types are kept);
  - one error box lists every problem.
- **`ApiGeneratePanel`:**
  - shows the counts (fields in payload / to test) and the new explanation text;
  - Generate is disabled while there are file problems.
- The results table, Run, Evaluate and Excel code are untouched.

### Desktop Agent (`src/twoSection.ts`, `SpecPanel.tsx`, `PayloadTree.tsx`)
- `twoSection.ts` (NEW) holds the same key and rule helpers.
- `SpecPanel` keeps `validations` (before, it dropped every key except payload, which would make generation fail), rejects the old format, shows problems, and disables Generate while there are any.
- `PayloadTree` renders the real payload (objects, rows of arrays) with each field's rule chips. Edits keep the original JSON type.

## Behaviour changes to know
1. A missing **optional** field is now a **Positive** case. A missing mandatory field is still Negative.
2. `Function Description` is always the API name.
3. A change inside an array is made in **row 1**. Other rows stay as uploaded.
4. A field with an empty rule gets only its missing case (plus any valid_values cases). The AI writes nothing for it.
5. Fields with no `validations` entry are never changed (e.g. HEADERS).
6. For EIS Channel, the envelope and EIS_PAYLOAD cases come from one AI call. The output is the same as before.

## Tested (mocked AI and EIS, real endpoint code)
- Flat EIS with a nested object and an array (30 cases): every case is the baseline plus exactly one change. Run sends 30/30 calls to EIS, each with a unique RRN from the baseline SOURCE_ID, including SOURCE_ID 1 char / 4 chars / null / missing.
- EIS Channel with HEADERS/BODY: fresh RRN per case placed before EIS_PAYLOAD, HEADERS never changed, envelope fields tested.
- Every 422 check listed above.
- 70 fields → batches of 30/30/14. A cut-off answer is split and retried.
- Files made by the Two-section Builder: Headers/Body, Payment, RPTA Analyse (117 cases), RPTA Callback (71) and your v2 file (130) all generate. The builder's mobile sample is rejected because of SOURCE_ID "MB01", as intended.
- Both frontends type-check, and the Agent's prepare step was tested with SOURCE_ID negative cases.
