import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  server: { port: 3000 },   // open the app at http://localhost:3000 (same host as API_BASE — see README)
});
